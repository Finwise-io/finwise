# Cash flow evidence — part 01 of 08: The Cash flow tab: This month, and Home's box for this month

21 cases. Read `moneykeel_audit_cf-evidence_brief_v01.md` first. Answer each case with one JSON line, in the format the brief gives.

## The cases

Each case: the figure and the tenet, what the first reviewer said it lacked, the figure's own record, the evidence (by the render's key in the next section), the decisions that name the figure (quoted at the end), our own tests and their results, and our status. Our status is not the answer.

```json
[
 {
  "case": "MK-CF-M-002#5",
  "figure": "MK-CF-M-002",
  "figure_label": "= Planned surplus",
  "tenet": 5,
  "tenet_words": "The person's word outranks the app's guess. What they confirmed, typed or chose is never overwritten by a rule, a sync or a sweep.",
  "first_review": {
   "date": "2026-10-25",
   "reviewer": "OpenAI",
   "audit_part": "18",
   "verdict": "FAIL",
   "kind": "evidence_gap",
   "what_it_said_it_lacked": "A figure declaration cannot establish that edits,sync,imports and recomputation preserve the person’s entered values for = Planned surplus. No code/test/app was inspected;this is an unclosed evidence requirement,not an observed overwrite."
  },
  "figure_record": {
   "label": "= Planned surplus",
   "unit": "money",
   "per": "month",
   "screens": [
    "/cashflow",
    "/home"
   ],
   "answers": "The surplus in the month if everything goes to plan.",
   "formula": "the inflow, less every debt payment due, less the budget, less each big-ticket item",
   "inputs": [
    "MK-XS-I-023 salary and other income",
    "MK-NW-I-002 your debts",
    "MK-CF-I-001 your logged expenses"
   ],
   "decisions": [
    "EVERY ROW SHOWN IS A ROW DEDUCTED (his rule under the approved design): nothing appears on This month without being in the sum."
   ],
   "refusal": "No planned surplus is shown, and the band reads —: when no budget is set (the sentence under the rows says so and offers \"Set your budget\"), or when a debt’s payment was never entered (\"Car loan’s payment is not entered, so there is no planned surplus — we won’t guess one.\", 2026-10-23). Income not entered — the month is not drawn: its two set-up steps stand in its place.",
   "ruled": "2026-09-27",
   "worked": {
    "given": "September 2026: $7,200 take-home; a $2,400 mortgage (on no property in Net worth) and a $250 car loan due; a $3,400 budget ($2,300 Rent / Mortgage, $700 groceries, $400 eating out) — the Rent / Mortgage line stands down, the mortgage in Debts counted once. Logged so far: $2,300 under Rent / Mortgage (the mortgage’s payment), $512 groceries, $186 eating out, and the $250 car loan paid. The Plan already promises $300/month to the emergency fund.",
    "answer": "$3,450/month"
   }
  },
  "evidence": {
   "render": "CF",
   "line_beside_the_figure": {
    "as_the_measurer_reads_it": "= Planned surplus",
    "found_at_render_line": 25
   },
   "printed_under": "MK-CF-M-002",
   "printed_texts": [
    "$3,450",
    "$3,450",
    "$3,450"
   ],
   "store": {
    "entered_keys_compared": 7,
    "entered": {
     "assetAccounts": "same",
     "liabilities": "same",
     "transactions": "same",
     "expenses": "same",
     "onboardingProfile": "same",
     "incomes": "same",
     "retirementAssumptions": "same"
    },
    "opening_changed_nothing_entered": true,
    "any_stored_value_changed": []
   },
   "sync": {
    "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
    "entered_keys_unchanged": 6,
    "of": 7,
    "what_the_sync_rewrote": {
     "onboardingProfile": {
      "grossWorkedBack": {
       "as_entered": null,
       "after_the_sync": true
      },
      "landsTypical": {
       "as_entered": null,
       "after_the_sync": "7200"
      },
      "salaryMode": {
       "as_entered": "takehome",
       "after_the_sync": "gross"
      }
     }
    },
    "figure_printed_after_the_sync": [
     "$3,450",
     "$3,450",
     "$3,450"
    ],
    "figure_same_after_the_sync": true,
    "whole_screen_same_after_the_sync": true
   }
  },
  "decisions": [
   "DEC-0200",
   "DEC-0260",
   "DEC-0292",
   "DEC-7682",
   "DEC-7937",
   "DEC-7939",
   "DEC-8084",
   "DEC-8152",
   "DEC-8153",
   "DEC-8362",
   "DEC-8387"
  ],
  "our_tests": [
   {
    "file": "src/screens/__tests__/outside_cashflow_openai_screens.test.tsx",
    "test": "MK-CF-M-002 = Planned surplus › T5 · reviewer FAIL (evidence_gap) · EVIDENCE GAP · what holds",
    "result": "passed",
    "what_it_checks": "opening the screen changes nothing entered, and the figure prints under its identifier"
   }
  ],
  "status": "FOR YOU TO SETTLE",
  "status_reason": "tenet 5 asks whether a rule replaced what the person entered — a judgement on the figure, not on the store alone. Our facts: opening the screen changed nothing entered; the figure prints under MK-CF-M-002; a sync of the same household left 6 of 7 entered values exactly as typed and rewrote onboardingProfile: grossWorkedBack, landsTypical, salaryMode; the figure prints the same after it. Edits on another screen are not shown."
 },
 {
  "case": "MK-CF-M-002#6",
  "figure": "MK-CF-M-002",
  "figure_label": "= Planned surplus",
  "tenet": 6,
  "tenet_words": "His decision is the design. The last approved drawing and the decision log say what the app does. A change of mine never stands against them. Every decision is recorded in his words and applied in every place it reaches.",
  "first_review": {
   "date": "2026-10-25",
   "reviewer": "OpenAI",
   "audit_part": "18",
   "verdict": "FAIL",
   "kind": "evidence_gap",
   "what_it_said_it_lacked": "The package supplies decision references and a ruled date 2026-09-27. Latest approved full drawing/rendered implementation for this exact figure was not independently supplied/inspected;do not infer designcompliance from registration alone."
  },
  "figure_record": {
   "label": "= Planned surplus",
   "unit": "money",
   "per": "month",
   "screens": [
    "/cashflow",
    "/home"
   ],
   "answers": "The surplus in the month if everything goes to plan.",
   "formula": "the inflow, less every debt payment due, less the budget, less each big-ticket item",
   "inputs": [
    "MK-XS-I-023 salary and other income",
    "MK-NW-I-002 your debts",
    "MK-CF-I-001 your logged expenses"
   ],
   "decisions": [
    "EVERY ROW SHOWN IS A ROW DEDUCTED (his rule under the approved design): nothing appears on This month without being in the sum."
   ],
   "refusal": "No planned surplus is shown, and the band reads —: when no budget is set (the sentence under the rows says so and offers \"Set your budget\"), or when a debt’s payment was never entered (\"Car loan’s payment is not entered, so there is no planned surplus — we won’t guess one.\", 2026-10-23). Income not entered — the month is not drawn: its two set-up steps stand in its place.",
   "ruled": "2026-09-27",
   "worked": {
    "given": "September 2026: $7,200 take-home; a $2,400 mortgage (on no property in Net worth) and a $250 car loan due; a $3,400 budget ($2,300 Rent / Mortgage, $700 groceries, $400 eating out) — the Rent / Mortgage line stands down, the mortgage in Debts counted once. Logged so far: $2,300 under Rent / Mortgage (the mortgage’s payment), $512 groceries, $186 eating out, and the $250 car loan paid. The Plan already promises $300/month to the emergency fund.",
    "answer": "$3,450/month"
   }
  },
  "evidence": {
   "render": "CF",
   "line_beside_the_figure": {
    "as_the_measurer_reads_it": "= Planned surplus",
    "found_at_render_line": 25
   },
   "printed_under": "MK-CF-M-002",
   "printed_texts": [
    "$3,450",
    "$3,450",
    "$3,450"
   ],
   "store": {
    "entered_keys_compared": 7,
    "entered": {
     "assetAccounts": "same",
     "liabilities": "same",
     "transactions": "same",
     "expenses": "same",
     "onboardingProfile": "same",
     "incomes": "same",
     "retirementAssumptions": "same"
    },
    "opening_changed_nothing_entered": true,
    "any_stored_value_changed": []
   },
   "sync": {
    "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
    "entered_keys_unchanged": 6,
    "of": 7,
    "what_the_sync_rewrote": {
     "onboardingProfile": {
      "grossWorkedBack": {
       "as_entered": null,
       "after_the_sync": true
      },
      "landsTypical": {
       "as_entered": null,
       "after_the_sync": "7200"
      },
      "salaryMode": {
       "as_entered": "takehome",
       "after_the_sync": "gross"
      }
     }
    },
    "figure_printed_after_the_sync": [
     "$3,450",
     "$3,450",
     "$3,450"
    ],
    "figure_same_after_the_sync": true,
    "whole_screen_same_after_the_sync": true
   },
   "drawing": {
    "file": "MoneyKeel/documents/cashflow/moneykeel_pres_mock_cash-flow_v01.html",
    "phones_read": "as the match test holds it (the drawn phone with each dated row and kept item applied by name)",
    "phones_that_hold_this_screen": [
     1,
     2
    ],
    "the_rendered_line": "= Planned surplus",
    "drawn_on_those_phones": [
     {
      "phone": 1,
      "line": 30,
      "text": "= Planned surplus"
     }
    ],
    "matched": "the whole rendered line, word for word",
    "drawn_elsewhere_on_the_drawing": [],
    "design_record_rows": [
     "Cash flow"
    ]
   },
   "match_tests": [
    {
     "file": "src/screens/__tests__/cashflow_matches_v01.test.tsx",
     "test": "A · This month, with data — Planned +$350 and Actual so far +$900, every row deducted, figure for figure",
     "kind": "test",
     "phones": [
      1
     ],
     "result": "passed",
     "lines": "55–59",
     "holds_the_phone_with_the_line": true
    },
    {
     "file": "src/screens/__tests__/cashflow_matches_v01.test.tsx",
     "test": "B · This month, a fresh account — no budget, so no planned surplus and no guess; Actual so far +$3,000",
     "kind": "test",
     "phones": [
      2
     ],
     "result": "passed",
     "lines": "61–65",
     "holds_the_phone_with_the_line": false
    }
   ]
  },
  "decisions": [
   "DEC-0200",
   "DEC-0260",
   "DEC-0292",
   "DEC-7682",
   "DEC-7937",
   "DEC-7939",
   "DEC-8084",
   "DEC-8152",
   "DEC-8153",
   "DEC-8362",
   "DEC-8387"
  ],
  "our_tests": [
   {
    "file": "src/screens/__tests__/outside_cashflow_openai_screens.test.tsx",
    "test": "MK-CF-M-002 = Planned surplus › T6 · reviewer FAIL (evidence_gap) · EVIDENCE GAP · what holds",
    "result": "passed",
    "what_it_checks": "the line beside the figure is on the rendered screen, and its drawing and match test exist"
   }
  ],
  "status": "SETTLED BY OUR TESTS — WORDS AND FIGURES",
  "status_reason": "the line is drawn on phone 1 (the whole rendered line, word for word), and every test that holds that phone word for word and figure for figure, in the drawing's own household, passes at this build: A · This month, with data — Planned +$350 and Actual so far +$900, every row deducted, figure for figure. Appearance (colour, size, spacing) is not tested here."
 },
 {
  "case": "MK-CF-M-003#5",
  "figure": "MK-CF-M-003",
  "figure_label": "= Actual surplus so far",
  "tenet": 5,
  "tenet_words": "The person's word outranks the app's guess. What they confirmed, typed or chose is never overwritten by a rule, a sync or a sweep.",
  "first_review": {
   "date": "2026-10-25",
   "reviewer": "OpenAI",
   "audit_part": "18",
   "verdict": "FAIL",
   "kind": "evidence_gap",
   "what_it_said_it_lacked": "A figure declaration cannot establish that edits,sync,imports and recomputation preserve the person’s entered values for = Actual surplus so far. No code/test/app was inspected;this is an unclosed evidence requirement,not an observed overwrite."
  },
  "figure_record": {
   "label": "= Actual surplus so far",
   "unit": "money",
   "per": "month",
   "screens": [
    "/cashflow"
   ],
   "answers": "What is actually left, on what has really happened so far this month.",
   "formula": "the month’s take-home (MK-CF-M-051), less each debt actually paid, less everything logged by hand and imported",
   "inputs": [
    "MK-NW-I-004 the activity records",
    "MK-CF-I-001 your logged expenses"
   ],
   "decisions": [
    "An unpaid debt shows $0 with its due date — never silently dropped, or the surplus would flatter the month.",
    "A card payment is counted ONCE: connected card → the imported purchases are the expense and the payment is a radar note; not connected → the payment IS the expense."
   ],
   "refusal": "Nothing logged and no card linked — it says so and offers the door.",
   "ruled": "2026-09-27",
   "worked": {
    "given": "September 2026: $7,200 take-home; a $2,400 mortgage (on no property in Net worth) and a $250 car loan due; a $3,400 budget ($2,300 Rent / Mortgage, $700 groceries, $400 eating out) — the Rent / Mortgage line stands down, the mortgage in Debts counted once. Logged so far: $2,300 under Rent / Mortgage (the mortgage’s payment), $512 groceries, $186 eating out, and the $250 car loan paid. The Plan already promises $300/month to the emergency fund.",
    "answer": "$3,952/month"
   }
  },
  "evidence": {
   "render": "CF",
   "line_beside_the_figure": {
    "as_the_measurer_reads_it": "= Actual surplus so far",
    "found_at_render_line": 43
   },
   "printed_under": "MK-CF-M-003",
   "printed_texts": [
    "$3,952",
    "$3,952",
    "$3,952"
   ],
   "store": {
    "entered_keys_compared": 7,
    "entered": {
     "assetAccounts": "same",
     "liabilities": "same",
     "transactions": "same",
     "expenses": "same",
     "onboardingProfile": "same",
     "incomes": "same",
     "retirementAssumptions": "same"
    },
    "opening_changed_nothing_entered": true,
    "any_stored_value_changed": []
   },
   "sync": {
    "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
    "entered_keys_unchanged": 6,
    "of": 7,
    "what_the_sync_rewrote": {
     "onboardingProfile": {
      "grossWorkedBack": {
       "as_entered": null,
       "after_the_sync": true
      },
      "landsTypical": {
       "as_entered": null,
       "after_the_sync": "7200"
      },
      "salaryMode": {
       "as_entered": "takehome",
       "after_the_sync": "gross"
      }
     }
    },
    "figure_printed_after_the_sync": [
     "$3,952",
     "$3,952",
     "$3,952"
    ],
    "figure_same_after_the_sync": true,
    "whole_screen_same_after_the_sync": true
   }
  },
  "decisions": [
   "DEC-0200",
   "DEC-7937",
   "DEC-8084",
   "DEC-8387"
  ],
  "our_tests": [
   {
    "file": "src/screens/__tests__/outside_cashflow_openai_screens.test.tsx",
    "test": "MK-CF-M-003 = Actual surplus so far › T5 · reviewer FAIL (evidence_gap) · EVIDENCE GAP · what holds",
    "result": "passed",
    "what_it_checks": "opening the screen changes nothing entered, and the figure prints under its identifier"
   }
  ],
  "status": "FOR YOU TO SETTLE",
  "status_reason": "tenet 5 asks whether a rule replaced what the person entered — a judgement on the figure, not on the store alone. Our facts: opening the screen changed nothing entered; the figure prints under MK-CF-M-003; a sync of the same household left 6 of 7 entered values exactly as typed and rewrote onboardingProfile: grossWorkedBack, landsTypical, salaryMode; the figure prints the same after it. Edits on another screen are not shown."
 },
 {
  "case": "MK-CF-M-003#6",
  "figure": "MK-CF-M-003",
  "figure_label": "= Actual surplus so far",
  "tenet": 6,
  "tenet_words": "His decision is the design. The last approved drawing and the decision log say what the app does. A change of mine never stands against them. Every decision is recorded in his words and applied in every place it reaches.",
  "first_review": {
   "date": "2026-10-25",
   "reviewer": "OpenAI",
   "audit_part": "18",
   "verdict": "FAIL",
   "kind": "evidence_gap",
   "what_it_said_it_lacked": "The package supplies decision references and a ruled date 2026-09-27. Latest approved full drawing/rendered implementation for this exact figure was not independently supplied/inspected;do not infer designcompliance from registration alone."
  },
  "figure_record": {
   "label": "= Actual surplus so far",
   "unit": "money",
   "per": "month",
   "screens": [
    "/cashflow"
   ],
   "answers": "What is actually left, on what has really happened so far this month.",
   "formula": "the month’s take-home (MK-CF-M-051), less each debt actually paid, less everything logged by hand and imported",
   "inputs": [
    "MK-NW-I-004 the activity records",
    "MK-CF-I-001 your logged expenses"
   ],
   "decisions": [
    "An unpaid debt shows $0 with its due date — never silently dropped, or the surplus would flatter the month.",
    "A card payment is counted ONCE: connected card → the imported purchases are the expense and the payment is a radar note; not connected → the payment IS the expense."
   ],
   "refusal": "Nothing logged and no card linked — it says so and offers the door.",
   "ruled": "2026-09-27",
   "worked": {
    "given": "September 2026: $7,200 take-home; a $2,400 mortgage (on no property in Net worth) and a $250 car loan due; a $3,400 budget ($2,300 Rent / Mortgage, $700 groceries, $400 eating out) — the Rent / Mortgage line stands down, the mortgage in Debts counted once. Logged so far: $2,300 under Rent / Mortgage (the mortgage’s payment), $512 groceries, $186 eating out, and the $250 car loan paid. The Plan already promises $300/month to the emergency fund.",
    "answer": "$3,952/month"
   }
  },
  "evidence": {
   "render": "CF",
   "line_beside_the_figure": {
    "as_the_measurer_reads_it": "= Actual surplus so far",
    "found_at_render_line": 43
   },
   "printed_under": "MK-CF-M-003",
   "printed_texts": [
    "$3,952",
    "$3,952",
    "$3,952"
   ],
   "store": {
    "entered_keys_compared": 7,
    "entered": {
     "assetAccounts": "same",
     "liabilities": "same",
     "transactions": "same",
     "expenses": "same",
     "onboardingProfile": "same",
     "incomes": "same",
     "retirementAssumptions": "same"
    },
    "opening_changed_nothing_entered": true,
    "any_stored_value_changed": []
   },
   "sync": {
    "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
    "entered_keys_unchanged": 6,
    "of": 7,
    "what_the_sync_rewrote": {
     "onboardingProfile": {
      "grossWorkedBack": {
       "as_entered": null,
       "after_the_sync": true
      },
      "landsTypical": {
       "as_entered": null,
       "after_the_sync": "7200"
      },
      "salaryMode": {
       "as_entered": "takehome",
       "after_the_sync": "gross"
      }
     }
    },
    "figure_printed_after_the_sync": [
     "$3,952",
     "$3,952",
     "$3,952"
    ],
    "figure_same_after_the_sync": true,
    "whole_screen_same_after_the_sync": true
   },
   "drawing": {
    "file": "MoneyKeel/documents/cashflow/moneykeel_pres_mock_cash-flow_v01.html",
    "phones_read": "as the match test holds it (the drawn phone with each dated row and kept item applied by name)",
    "phones_that_hold_this_screen": [
     1,
     2
    ],
    "the_rendered_line": "= Actual surplus so far",
    "drawn_on_those_phones": [
     {
      "phone": 1,
      "line": 53,
      "text": "= Actual surplus so far"
     },
     {
      "phone": 2,
      "line": 36,
      "text": "= Actual surplus so far"
     }
    ],
    "matched": "the whole rendered line, word for word",
    "drawn_elsewhere_on_the_drawing": [],
    "design_record_rows": [
     "Cash flow"
    ]
   },
   "match_tests": [
    {
     "file": "src/screens/__tests__/cashflow_matches_v01.test.tsx",
     "test": "A · This month, with data — Planned +$350 and Actual so far +$900, every row deducted, figure for figure",
     "kind": "test",
     "phones": [
      1
     ],
     "result": "passed",
     "lines": "55–59",
     "holds_the_phone_with_the_line": true
    },
    {
     "file": "src/screens/__tests__/cashflow_matches_v01.test.tsx",
     "test": "B · This month, a fresh account — no budget, so no planned surplus and no guess; Actual so far +$3,000",
     "kind": "test",
     "phones": [
      2
     ],
     "result": "passed",
     "lines": "61–65",
     "holds_the_phone_with_the_line": true
    }
   ]
  },
  "decisions": [
   "DEC-0200",
   "DEC-7937",
   "DEC-8084",
   "DEC-8387"
  ],
  "our_tests": [
   {
    "file": "src/screens/__tests__/outside_cashflow_openai_screens.test.tsx",
    "test": "MK-CF-M-003 = Actual surplus so far › T6 · reviewer FAIL (evidence_gap) · EVIDENCE GAP · what holds",
    "result": "passed",
    "what_it_checks": "the line beside the figure is on the rendered screen, and its drawing and match test exist"
   }
  ],
  "status": "SETTLED BY OUR TESTS — WORDS AND FIGURES",
  "status_reason": "the line is drawn on phone 1, 2 (the whole rendered line, word for word), and every test that holds that phone word for word and figure for figure, in the drawing's own household, passes at this build: A · This month, with data — Planned +$350 and Actual so far +$900, every row deducted, figure for figure; B · This month, a fresh account — no budget, so no planned surplus and no guess; Actual so far +$3,000. Appearance (colour, size, spacing) is not tested here."
 },
 {
  "case": "MK-CF-M-004#5",
  "figure": "MK-CF-M-004",
  "figure_label": "each row of the month — what it is and what it costs",
  "tenet": 5,
  "tenet_words": "The person's word outranks the app's guess. What they confirmed, typed or chose is never overwritten by a rule, a sync or a sweep.",
  "first_review": {
   "date": "2026-10-25",
   "reviewer": "OpenAI",
   "audit_part": "18",
   "verdict": "FAIL",
   "kind": "evidence_gap",
   "what_it_said_it_lacked": "A figure declaration cannot establish that edits,sync,imports and recomputation preserve the person’s entered values for each row of the month — what it is and what it costs. No code/test/app was inspected;this is an unclosed evidence requirement,not an observed overwrite."
  },
  "figure_record": {
   "label": "each row of the month — what it is and what it costs",
   "unit": "money",
   "grain": "one row",
   "screens": [
    "/cashflow"
   ],
   "answers": "One line per thing in or out this month, so the surplus can be checked by reading down the column — and, on Expenses, each line of its lists.",
   "formula": "one row per line of the month, each at its own amount. This month, planned: the inflow, each debt's payment due, the month's planned expenses, each big-ticket item. This month, actual: the inflow, each debt's payment made so far ($0 with its due day when nothing was), other debt payments, the expenses entered by hand and imported. Expenses: each debt that repeats every month at its payment, the total of the repeating debts, and each list's total of what was logged",
   "inputs": [
    "MK-XS-I-023 salary and other income",
    "MK-NW-I-002 your debts",
    "MK-CF-I-001 your logged expenses"
   ],
   "decisions": [
    "Drawn from the approved design (cash-flow_v01): the flow is SPELLED OUT, not summarised into three numbers."
   ],
   "refusal": "A row whose amount is not known says so where the amount would be: \"— not set\" for a budget not set, \"payment not entered\" for a debt whose payment was never entered (2026-10-23). A debt not paid yet shows $0 with its due day (\"not paid yet\" when no due day is recorded). Nothing logged: \"Expenses entered by hand\" stays at a real $0, with \"Nothing logged yet, and no card connected. …\" under the rows. On Expenses every section keeps its heading when empty, at a real $0.",
   "ruled": "2026-09-27",
   "worked": {
    "given": "September 2026: $7,200 take-home; a $2,400 mortgage (on no property in Net worth) and a $250 car loan due; a $3,400 budget ($2,300 Rent / Mortgage, $700 groceries, $400 eating out) — the Rent / Mortgage line stands down, the mortgage in Debts counted once. Logged so far: $2,300 under Rent / Mortgage (the mortgage’s payment), $512 groceries, $186 eating out, and the $250 car loan paid. The Plan already promises $300/month to the emergency fund.",
    "answer": "−$250"
   }
  },
  "evidence": {
   "render": "CF",
   "line_beside_the_figure": {
    "as_the_measurer_reads_it": "Car loan",
    "found_at_render_line": 18
   },
   "printed_under": "MK-CF-M-004",
   "printed_texts": [
    "$7,200",
    "$2,400",
    "$250",
    "$1,100",
    "$7,200",
    "$2,300",
    "$250",
    "$698"
   ],
   "store": {
    "entered_keys_compared": 7,
    "entered": {
     "assetAccounts": "same",
     "liabilities": "same",
     "transactions": "same",
     "expenses": "same",
     "onboardingProfile": "same",
     "incomes": "same",
     "retirementAssumptions": "same"
    },
    "opening_changed_nothing_entered": true,
    "any_stored_value_changed": []
   },
   "sync": {
    "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
    "entered_keys_unchanged": 6,
    "of": 7,
    "what_the_sync_rewrote": {
     "onboardingProfile": {
      "grossWorkedBack": {
       "as_entered": null,
       "after_the_sync": true
      },
      "landsTypical": {
       "as_entered": null,
       "after_the_sync": "7200"
      },
      "salaryMode": {
       "as_entered": "takehome",
       "after_the_sync": "gross"
      }
     }
    },
    "figure_printed_after_the_sync": [
     "$7,200",
     "$2,400",
     "$250",
     "$1,100",
     "$7,200",
     "$2,300",
     "$250",
     "$698"
    ],
    "figure_same_after_the_sync": true,
    "whole_screen_same_after_the_sync": true
   }
  },
  "decisions": [
   "DEC-0002",
   "DEC-0200",
   "DEC-0292",
   "DEC-0333",
   "DEC-7611",
   "DEC-7937",
   "DEC-8084",
   "DEC-8387"
  ],
  "our_tests": [
   {
    "file": "src/screens/__tests__/outside_cashflow_openai_screens.test.tsx",
    "test": "MK-CF-M-004 each row of the month — what it is and what it costs › T5 · reviewer FAIL (evidence_gap) · EVIDENCE GAP · what holds",
    "result": "passed",
    "what_it_checks": "opening the screen changes nothing entered, and the figure prints under its identifier"
   }
  ],
  "status": "FOR YOU TO SETTLE",
  "status_reason": "tenet 5 asks whether a rule replaced what the person entered — a judgement on the figure, not on the store alone. Our facts: opening the screen changed nothing entered; the figure prints under MK-CF-M-004; a sync of the same household left 6 of 7 entered values exactly as typed and rewrote onboardingProfile: grossWorkedBack, landsTypical, salaryMode; the figure prints the same after it. Edits on another screen are not shown."
 },
 {
  "case": "MK-CF-M-004#6",
  "figure": "MK-CF-M-004",
  "figure_label": "each row of the month — what it is and what it costs",
  "tenet": 6,
  "tenet_words": "His decision is the design. The last approved drawing and the decision log say what the app does. A change of mine never stands against them. Every decision is recorded in his words and applied in every place it reaches.",
  "first_review": {
   "date": "2026-10-25",
   "reviewer": "OpenAI",
   "audit_part": "18",
   "verdict": "FAIL",
   "kind": "evidence_gap",
   "what_it_said_it_lacked": "The package supplies decision references and a ruled date 2026-09-27. Latest approved full drawing/rendered implementation for this exact figure was not independently supplied/inspected;do not infer designcompliance from registration alone."
  },
  "figure_record": {
   "label": "each row of the month — what it is and what it costs",
   "unit": "money",
   "grain": "one row",
   "screens": [
    "/cashflow"
   ],
   "answers": "One line per thing in or out this month, so the surplus can be checked by reading down the column — and, on Expenses, each line of its lists.",
   "formula": "one row per line of the month, each at its own amount. This month, planned: the inflow, each debt's payment due, the month's planned expenses, each big-ticket item. This month, actual: the inflow, each debt's payment made so far ($0 with its due day when nothing was), other debt payments, the expenses entered by hand and imported. Expenses: each debt that repeats every month at its payment, the total of the repeating debts, and each list's total of what was logged",
   "inputs": [
    "MK-XS-I-023 salary and other income",
    "MK-NW-I-002 your debts",
    "MK-CF-I-001 your logged expenses"
   ],
   "decisions": [
    "Drawn from the approved design (cash-flow_v01): the flow is SPELLED OUT, not summarised into three numbers."
   ],
   "refusal": "A row whose amount is not known says so where the amount would be: \"— not set\" for a budget not set, \"payment not entered\" for a debt whose payment was never entered (2026-10-23). A debt not paid yet shows $0 with its due day (\"not paid yet\" when no due day is recorded). Nothing logged: \"Expenses entered by hand\" stays at a real $0, with \"Nothing logged yet, and no card connected. …\" under the rows. On Expenses every section keeps its heading when empty, at a real $0.",
   "ruled": "2026-09-27",
   "worked": {
    "given": "September 2026: $7,200 take-home; a $2,400 mortgage (on no property in Net worth) and a $250 car loan due; a $3,400 budget ($2,300 Rent / Mortgage, $700 groceries, $400 eating out) — the Rent / Mortgage line stands down, the mortgage in Debts counted once. Logged so far: $2,300 under Rent / Mortgage (the mortgage’s payment), $512 groceries, $186 eating out, and the $250 car loan paid. The Plan already promises $300/month to the emergency fund.",
    "answer": "−$250"
   }
  },
  "evidence": {
   "render": "CF",
   "line_beside_the_figure": {
    "as_the_measurer_reads_it": "Car loan",
    "found_at_render_line": 18
   },
   "printed_under": "MK-CF-M-004",
   "printed_texts": [
    "$7,200",
    "$2,400",
    "$250",
    "$1,100",
    "$7,200",
    "$2,300",
    "$250",
    "$698"
   ],
   "store": {
    "entered_keys_compared": 7,
    "entered": {
     "assetAccounts": "same",
     "liabilities": "same",
     "transactions": "same",
     "expenses": "same",
     "onboardingProfile": "same",
     "incomes": "same",
     "retirementAssumptions": "same"
    },
    "opening_changed_nothing_entered": true,
    "any_stored_value_changed": []
   },
   "sync": {
    "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
    "entered_keys_unchanged": 6,
    "of": 7,
    "what_the_sync_rewrote": {
     "onboardingProfile": {
      "grossWorkedBack": {
       "as_entered": null,
       "after_the_sync": true
      },
      "landsTypical": {
       "as_entered": null,
       "after_the_sync": "7200"
      },
      "salaryMode": {
       "as_entered": "takehome",
       "after_the_sync": "gross"
      }
     }
    },
    "figure_printed_after_the_sync": [
     "$7,200",
     "$2,400",
     "$250",
     "$1,100",
     "$7,200",
     "$2,300",
     "$250",
     "$698"
    ],
    "figure_same_after_the_sync": true,
    "whole_screen_same_after_the_sync": true
   },
   "drawing": {
    "file": "MoneyKeel/documents/cashflow/moneykeel_pres_mock_cash-flow_v01.html",
    "phones_read": "as the match test holds it (the drawn phone with each dated row and kept item applied by name)",
    "phones_that_hold_this_screen": [
     1,
     2
    ],
    "the_rendered_line": "Car loan",
    "drawn_on_those_phones": [
     {
      "phone": 1,
      "line": 18,
      "text": "Car loan"
     },
     {
      "phone": 1,
      "line": 39,
      "text": "Car loan"
     },
     {
      "phone": 2,
      "line": 17,
      "text": "Car loan"
     },
     {
      "phone": 2,
      "line": 31,
      "text": "Car loan"
     }
    ],
    "matched": "the whole rendered line, word for word",
    "drawn_elsewhere_on_the_drawing": [
     {
      "phone": 3,
      "line": 15,
      "text": "Car loan"
     },
     {
      "phone": 4,
      "line": 14,
      "text": "Car loan"
     },
     {
      "phone": 6,
      "line": 30,
      "text": "Car loan"
     }
    ],
    "design_record_rows": [
     "Cash flow"
    ]
   },
   "match_tests": [
    {
     "file": "src/screens/__tests__/cashflow_matches_v01.test.tsx",
     "test": "A · This month, with data — Planned +$350 and Actual so far +$900, every row deducted, figure for figure",
     "kind": "test",
     "phones": [
      1
     ],
     "result": "passed",
     "lines": "55–59",
     "holds_the_phone_with_the_line": true
    },
    {
     "file": "src/screens/__tests__/cashflow_matches_v01.test.tsx",
     "test": "B · This month, a fresh account — no budget, so no planned surplus and no guess; Actual so far +$3,000",
     "kind": "test",
     "phones": [
      2
     ],
     "result": "passed",
     "lines": "61–65",
     "holds_the_phone_with_the_line": true
    }
   ]
  },
  "decisions": [
   "DEC-0002",
   "DEC-0200",
   "DEC-0292",
   "DEC-0333",
   "DEC-7611",
   "DEC-7937",
   "DEC-8084",
   "DEC-8387"
  ],
  "our_tests": [
   {
    "file": "src/screens/__tests__/outside_cashflow_openai_screens.test.tsx",
    "test": "MK-CF-M-004 each row of the month — what it is and what it costs › T6 · reviewer FAIL (evidence_gap) · EVIDENCE GAP · what holds",
    "result": "passed",
    "what_it_checks": "the line beside the figure is on the rendered screen, and its drawing and match test exist"
   }
  ],
  "status": "SETTLED BY OUR TESTS — WORDS AND FIGURES",
  "status_reason": "the line is drawn on phone 1, 2 (the whole rendered line, word for word), and every test that holds that phone word for word and figure for figure, in the drawing's own household, passes at this build: A · This month, with data — Planned +$350 and Actual so far +$900, every row deducted, figure for figure; B · This month, a fresh account — no budget, so no planned surplus and no guess; Actual so far +$3,000. Appearance (colour, size, spacing) is not tested here."
 },
 {
  "case": "MK-CF-M-020#5",
  "figure": "MK-CF-M-020",
  "figure_label": "THIS MONTH — free to use",
  "tenet": 5,
  "tenet_words": "The person's word outranks the app's guess. What they confirmed, typed or chose is never overwritten by a rule, a sync or a sweep.",
  "first_review": {
   "date": "2026-10-25",
   "reviewer": "OpenAI",
   "audit_part": "18",
   "verdict": "FAIL",
   "kind": "evidence_gap",
   "what_it_said_it_lacked": "A figure declaration cannot establish that edits,sync,imports and recomputation preserve the person’s entered values for THIS MONTH — free to use. No code/test/app was inspected;this is an unclosed evidence requirement,not an observed overwrite."
  },
  "figure_record": {
   "label": "THIS MONTH — free to use",
   "unit": "money",
   "screens": [
    "/cashflow"
   ],
   "answers": "The planned surplus, less what the Plan has already promised to goals this month — what is genuinely free.",
   "formula": "= Planned surplus (MK-CF-M-002) − the goals’ commitments (MK-CF-M-021)",
   "inputs": [
    "MK-XS-I-023 salary and other income",
    "MK-NW-I-002 your debts",
    "MK-CF-I-012 planned expenses",
    "MK-XS-I-027 goals (target, saved, date)"
   ],
   "decisions": [
    "A PROMISE TO A GOAL IS MONEY ALREADY SPOKEN FOR — it never reads as free."
   ],
   "refusal": "No budget set, or a debt’s payment never entered (2026-10-23) — no line: nothing is called free until there is a plan to be free of.",
   "ruled": "2026-10-02",
   "worked": {
    "given": "September 2026: $7,200 take-home; a $2,400 mortgage (on no property in Net worth) and a $250 car loan due; a $3,400 budget ($2,300 Rent / Mortgage, $700 groceries, $400 eating out) — the Rent / Mortgage line stands down, the mortgage in Debts counted once. Logged so far: $2,300 under Rent / Mortgage (the mortgage’s payment), $512 groceries, $186 eating out, and the $250 car loan paid. The Plan already promises $300/month to the emergency fund.",
    "answer": "$3,150"
   }
  },
  "evidence": {
   "render": "CF",
   "line_beside_the_figure": {
    "as_the_measurer_reads_it": "Surplus after your budget",
    "found_at_render_line": 29
   },
   "printed_under": "MK-CF-M-020",
   "printed_texts": [
    "$3,150"
   ],
   "store": {
    "entered_keys_compared": 7,
    "entered": {
     "assetAccounts": "same",
     "liabilities": "same",
     "transactions": "same",
     "expenses": "same",
     "onboardingProfile": "same",
     "incomes": "same",
     "retirementAssumptions": "same"
    },
    "opening_changed_nothing_entered": true,
    "any_stored_value_changed": []
   },
   "sync": {
    "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
    "entered_keys_unchanged": 6,
    "of": 7,
    "what_the_sync_rewrote": {
     "onboardingProfile": {
      "grossWorkedBack": {
       "as_entered": null,
       "after_the_sync": true
      },
      "landsTypical": {
       "as_entered": null,
       "after_the_sync": "7200"
      },
      "salaryMode": {
       "as_entered": "takehome",
       "after_the_sync": "gross"
      }
     }
    },
    "figure_printed_after_the_sync": [
     "$3,150"
    ],
    "figure_same_after_the_sync": true,
    "whole_screen_same_after_the_sync": true
   }
  },
  "decisions": [
   "DEC-0200",
   "DEC-8387"
  ],
  "our_tests": [
   {
    "file": "src/screens/__tests__/outside_cashflow_openai_screens.test.tsx",
    "test": "MK-CF-M-020 THIS MONTH — free to use › T5 · reviewer FAIL (evidence_gap) · EVIDENCE GAP · what holds",
    "result": "passed",
    "what_it_checks": "opening the screen changes nothing entered, and the figure prints under its identifier"
   }
  ],
  "status": "FOR YOU TO SETTLE",
  "status_reason": "tenet 5 asks whether a rule replaced what the person entered — a judgement on the figure, not on the store alone. Our facts: opening the screen changed nothing entered; the figure prints under MK-CF-M-020; a sync of the same household left 6 of 7 entered values exactly as typed and rewrote onboardingProfile: grossWorkedBack, landsTypical, salaryMode; the figure prints the same after it. Edits on another screen are not shown."
 },
 {
  "case": "MK-CF-M-020#6",
  "figure": "MK-CF-M-020",
  "figure_label": "THIS MONTH — free to use",
  "tenet": 6,
  "tenet_words": "His decision is the design. The last approved drawing and the decision log say what the app does. A change of mine never stands against them. Every decision is recorded in his words and applied in every place it reaches.",
  "first_review": {
   "date": "2026-10-25",
   "reviewer": "OpenAI",
   "audit_part": "18",
   "verdict": "FAIL",
   "kind": "evidence_gap",
   "what_it_said_it_lacked": "The package supplies decision references and a ruled date 2026-10-02. Latest approved full drawing/rendered implementation for this exact figure was not independently supplied/inspected;do not infer designcompliance from registration alone."
  },
  "figure_record": {
   "label": "THIS MONTH — free to use",
   "unit": "money",
   "screens": [
    "/cashflow"
   ],
   "answers": "The planned surplus, less what the Plan has already promised to goals this month — what is genuinely free.",
   "formula": "= Planned surplus (MK-CF-M-002) − the goals’ commitments (MK-CF-M-021)",
   "inputs": [
    "MK-XS-I-023 salary and other income",
    "MK-NW-I-002 your debts",
    "MK-CF-I-012 planned expenses",
    "MK-XS-I-027 goals (target, saved, date)"
   ],
   "decisions": [
    "A PROMISE TO A GOAL IS MONEY ALREADY SPOKEN FOR — it never reads as free."
   ],
   "refusal": "No budget set, or a debt’s payment never entered (2026-10-23) — no line: nothing is called free until there is a plan to be free of.",
   "ruled": "2026-10-02",
   "worked": {
    "given": "September 2026: $7,200 take-home; a $2,400 mortgage (on no property in Net worth) and a $250 car loan due; a $3,400 budget ($2,300 Rent / Mortgage, $700 groceries, $400 eating out) — the Rent / Mortgage line stands down, the mortgage in Debts counted once. Logged so far: $2,300 under Rent / Mortgage (the mortgage’s payment), $512 groceries, $186 eating out, and the $250 car loan paid. The Plan already promises $300/month to the emergency fund.",
    "answer": "$3,150"
   }
  },
  "evidence": {
   "render": "CF",
   "line_beside_the_figure": {
    "as_the_measurer_reads_it": "Surplus after your budget",
    "found_at_render_line": 29
   },
   "printed_under": "MK-CF-M-020",
   "printed_texts": [
    "$3,150"
   ],
   "store": {
    "entered_keys_compared": 7,
    "entered": {
     "assetAccounts": "same",
     "liabilities": "same",
     "transactions": "same",
     "expenses": "same",
     "onboardingProfile": "same",
     "incomes": "same",
     "retirementAssumptions": "same"
    },
    "opening_changed_nothing_entered": true,
    "any_stored_value_changed": []
   },
   "sync": {
    "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
    "entered_keys_unchanged": 6,
    "of": 7,
    "what_the_sync_rewrote": {
     "onboardingProfile": {
      "grossWorkedBack": {
       "as_entered": null,
       "after_the_sync": true
      },
      "landsTypical": {
       "as_entered": null,
       "after_the_sync": "7200"
      },
      "salaryMode": {
       "as_entered": "takehome",
       "after_the_sync": "gross"
      }
     }
    },
    "figure_printed_after_the_sync": [
     "$3,150"
    ],
    "figure_same_after_the_sync": true,
    "whole_screen_same_after_the_sync": true
   },
   "drawing": {
    "file": "MoneyKeel/documents/cashflow/moneykeel_pres_mock_cash-flow_v01.html",
    "phones_read": "as the match test holds it (the drawn phone with each dated row and kept item applied by name)",
    "phones_that_hold_this_screen": [
     1,
     2
    ],
    "the_rendered_line": "Surplus after your budget",
    "drawn_on_those_phones": [],
    "matched": null,
    "drawn_elsewhere_on_the_drawing": [],
    "design_record_rows": [
     "Cash flow"
    ]
   },
   "match_tests": [
    {
     "file": "src/screens/__tests__/cashflow_matches_v01.test.tsx",
     "test": "A · This month, with data — Planned +$350 and Actual so far +$900, every row deducted, figure for figure",
     "kind": "test",
     "phones": [
      1
     ],
     "result": "passed",
     "lines": "55–59",
     "holds_the_phone_with_the_line": false
    },
    {
     "file": "src/screens/__tests__/cashflow_matches_v01.test.tsx",
     "test": "B · This month, a fresh account — no budget, so no planned surplus and no guess; Actual so far +$3,000",
     "kind": "test",
     "phones": [
      2
     ],
     "result": "passed",
     "lines": "61–65",
     "holds_the_phone_with_the_line": false
    }
   ]
  },
  "decisions": [
   "DEC-0200",
   "DEC-8387"
  ],
  "our_tests": [
   {
    "file": "src/screens/__tests__/outside_cashflow_openai_screens.test.tsx",
    "test": "MK-CF-M-020 THIS MONTH — free to use › T6 · reviewer FAIL (evidence_gap) · EVIDENCE GAP · what holds",
    "result": "passed",
    "what_it_checks": "the line beside the figure is on the rendered screen, and its drawing and match test exist"
   }
  ],
  "status": "FOR YOU TO SETTLE",
  "status_reason": "the line is not on the phones that hold this screen (1, 2) — judge whether a dated row or a decision (DEC-1560 keeps twelve named items) allows it"
 },
 {
  "case": "MK-CF-M-021#5",
  "figure": "MK-CF-M-021",
  "figure_label": "<goal> · from your Plan",
  "tenet": 5,
  "tenet_words": "The person's word outranks the app's guess. What they confirmed, typed or chose is never overwritten by a rule, a sync or a sweep.",
  "first_review": {
   "date": "2026-10-25",
   "reviewer": "OpenAI",
   "audit_part": "18",
   "verdict": "FAIL",
   "kind": "evidence_gap",
   "what_it_said_it_lacked": "A figure declaration cannot establish that edits,sync,imports and recomputation preserve the person’s entered values for <goal> · from your Plan. No code/test/app was inspected;this is an unclosed evidence requirement,not an observed overwrite."
  },
  "figure_record": {
   "label": "<goal> · from your Plan",
   "unit": "money",
   "per": "month",
   "grain": "one goal",
   "screens": [
    "/cashflow"
   ],
   "answers": "What the Plan sends to one goal each month, shown on This month as a line already spoken for.",
   "formula": "the goal’s monthly amount, as the Plan set it",
   "inputs": [
    "MK-XS-I-027 goals (target, saved, date)"
   ],
   "refusal": "No goal with a monthly amount — no line.",
   "ruled": "2026-10-02",
   "worked": {
    "given": "September 2026: $7,200 take-home; a $2,400 mortgage (on no property in Net worth) and a $250 car loan due; a $3,400 budget ($2,300 Rent / Mortgage, $700 groceries, $400 eating out) — the Rent / Mortgage line stands down, the mortgage in Debts counted once. Logged so far: $2,300 under Rent / Mortgage (the mortgage’s payment), $512 groceries, $186 eating out, and the $250 car loan paid. The Plan already promises $300/month to the emergency fund.",
    "answer": "$300/month"
   }
  },
  "evidence": {
   "render": "CF",
   "line_beside_the_figure": {
    "as_the_measurer_reads_it": "Emergency fund · from your Plan",
    "found_at_render_line": 27
   },
   "printed_under": "MK-CF-M-021",
   "printed_texts": [
    "$300"
   ],
   "store": {
    "entered_keys_compared": 7,
    "entered": {
     "assetAccounts": "same",
     "liabilities": "same",
     "transactions": "same",
     "expenses": "same",
     "onboardingProfile": "same",
     "incomes": "same",
     "retirementAssumptions": "same"
    },
    "opening_changed_nothing_entered": true,
    "any_stored_value_changed": []
   },
   "sync": {
    "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
    "entered_keys_unchanged": 6,
    "of": 7,
    "what_the_sync_rewrote": {
     "onboardingProfile": {
      "grossWorkedBack": {
       "as_entered": null,
       "after_the_sync": true
      },
      "landsTypical": {
       "as_entered": null,
       "after_the_sync": "7200"
      },
      "salaryMode": {
       "as_entered": "takehome",
       "after_the_sync": "gross"
      }
     }
    },
    "figure_printed_after_the_sync": [
     "$300"
    ],
    "figure_same_after_the_sync": true,
    "whole_screen_same_after_the_sync": true
   }
  },
  "decisions": [
   "DEC-0200",
   "DEC-8387"
  ],
  "our_tests": [
   {
    "file": "src/screens/__tests__/outside_cashflow_openai_screens.test.tsx",
    "test": "MK-CF-M-021 <goal> · from your Plan › T5 · reviewer FAIL (evidence_gap) · EVIDENCE GAP · what holds",
    "result": "passed",
    "what_it_checks": "opening the screen changes nothing entered, and the figure prints under its identifier"
   }
  ],
  "status": "FOR YOU TO SETTLE",
  "status_reason": "tenet 5 asks whether a rule replaced what the person entered — a judgement on the figure, not on the store alone. Our facts: opening the screen changed nothing entered; the figure prints under MK-CF-M-021; a sync of the same household left 6 of 7 entered values exactly as typed and rewrote onboardingProfile: grossWorkedBack, landsTypical, salaryMode; the figure prints the same after it. Edits on another screen are not shown."
 },
 {
  "case": "MK-CF-M-021#6",
  "figure": "MK-CF-M-021",
  "figure_label": "<goal> · from your Plan",
  "tenet": 6,
  "tenet_words": "His decision is the design. The last approved drawing and the decision log say what the app does. A change of mine never stands against them. Every decision is recorded in his words and applied in every place it reaches.",
  "first_review": {
   "date": "2026-10-25",
   "reviewer": "OpenAI",
   "audit_part": "18",
   "verdict": "FAIL",
   "kind": "evidence_gap",
   "what_it_said_it_lacked": "The package supplies decision references and a ruled date 2026-10-02. Latest approved full drawing/rendered implementation for this exact figure was not independently supplied/inspected;do not infer designcompliance from registration alone."
  },
  "figure_record": {
   "label": "<goal> · from your Plan",
   "unit": "money",
   "per": "month",
   "grain": "one goal",
   "screens": [
    "/cashflow"
   ],
   "answers": "What the Plan sends to one goal each month, shown on This month as a line already spoken for.",
   "formula": "the goal’s monthly amount, as the Plan set it",
   "inputs": [
    "MK-XS-I-027 goals (target, saved, date)"
   ],
   "refusal": "No goal with a monthly amount — no line.",
   "ruled": "2026-10-02",
   "worked": {
    "given": "September 2026: $7,200 take-home; a $2,400 mortgage (on no property in Net worth) and a $250 car loan due; a $3,400 budget ($2,300 Rent / Mortgage, $700 groceries, $400 eating out) — the Rent / Mortgage line stands down, the mortgage in Debts counted once. Logged so far: $2,300 under Rent / Mortgage (the mortgage’s payment), $512 groceries, $186 eating out, and the $250 car loan paid. The Plan already promises $300/month to the emergency fund.",
    "answer": "$300/month"
   }
  },
  "evidence": {
   "render": "CF",
   "line_beside_the_figure": {
    "as_the_measurer_reads_it": "Emergency fund · from your Plan",
    "found_at_render_line": 27
   },
   "printed_under": "MK-CF-M-021",
   "printed_texts": [
    "$300"
   ],
   "store": {
    "entered_keys_compared": 7,
    "entered": {
     "assetAccounts": "same",
     "liabilities": "same",
     "transactions": "same",
     "expenses": "same",
     "onboardingProfile": "same",
     "incomes": "same",
     "retirementAssumptions": "same"
    },
    "opening_changed_nothing_entered": true,
    "any_stored_value_changed": []
   },
   "sync": {
    "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
    "entered_keys_unchanged": 6,
    "of": 7,
    "what_the_sync_rewrote": {
     "onboardingProfile": {
      "grossWorkedBack": {
       "as_entered": null,
       "after_the_sync": true
      },
      "landsTypical": {
       "as_entered": null,
       "after_the_sync": "7200"
      },
      "salaryMode": {
       "as_entered": "takehome",
       "after_the_sync": "gross"
      }
     }
    },
    "figure_printed_after_the_sync": [
     "$300"
    ],
    "figure_same_after_the_sync": true,
    "whole_screen_same_after_the_sync": true
   },
   "drawing": {
    "file": "MoneyKeel/documents/cashflow/moneykeel_pres_mock_cash-flow_v01.html",
    "phones_read": "as the match test holds it (the drawn phone with each dated row and kept item applied by name)",
    "phones_that_hold_this_screen": [
     1,
     2
    ],
    "the_rendered_line": "Emergency fund · from your Plan",
    "drawn_on_those_phones": [],
    "matched": null,
    "drawn_elsewhere_on_the_drawing": [],
    "design_record_rows": [
     "Cash flow"
    ]
   },
   "match_tests": [
    {
     "file": "src/screens/__tests__/cashflow_matches_v01.test.tsx",
     "test": "A · This month, with data — Planned +$350 and Actual so far +$900, every row deducted, figure for figure",
     "kind": "test",
     "phones": [
      1
     ],
     "result": "passed",
     "lines": "55–59",
     "holds_the_phone_with_the_line": false
    },
    {
     "file": "src/screens/__tests__/cashflow_matches_v01.test.tsx",
     "test": "B · This month, a fresh account — no budget, so no planned surplus and no guess; Actual so far +$3,000",
     "kind": "test",
     "phones": [
      2
     ],
     "result": "passed",
     "lines": "61–65",
     "holds_the_phone_with_the_line": false
    }
   ]
  },
  "decisions": [
   "DEC-0200",
   "DEC-8387"
  ],
  "our_tests": [
   {
    "file": "src/screens/__tests__/outside_cashflow_openai_screens.test.tsx",
    "test": "MK-CF-M-021 <goal> · from your Plan › T6 · reviewer FAIL (evidence_gap) · EVIDENCE GAP · what holds",
    "result": "passed",
    "what_it_checks": "the line beside the figure is on the rendered screen, and its drawing and match test exist"
   }
  ],
  "status": "FOR YOU TO SETTLE",
  "status_reason": "the line is not on the phones that hold this screen (1, 2) — judge whether a dated row or a decision (DEC-1560 keeps twelve named items) allows it"
 },
 {
  "case": "MK-CF-M-048#5",
  "figure": "MK-CF-M-048",
  "figure_label": "Planned outflow (expenses + debt)",
  "tenet": 5,
  "tenet_words": "The person's word outranks the app's guess. What they confirmed, typed or chose is never overwritten by a rule, a sync or a sweep.",
  "first_review": {
   "date": "2026-10-25",
   "reviewer": "OpenAI",
   "audit_part": "18",
   "verdict": "FAIL",
   "kind": "evidence_gap",
   "what_it_said_it_lacked": "A figure declaration cannot establish that edits,sync,imports and recomputation preserve the person’s entered values for Planned outflow (expenses + debt). No code/test/app was inspected;this is an unclosed evidence requirement,not an observed overwrite."
  },
  "figure_record": {
   "label": "Planned outflow (expenses + debt)",
   "unit": "money",
   "per": "month",
   "grain": "one figure per household per month",
   "screens": [
    "/cashflow"
   ],
   "answers": "What the plan says goes out during a month after this one — printed on that month’s plan card: the budget, the debt payments that fall in that month, and any big bill that falls in it.",
   "formula": "planned outflow = the dated grid’s outflow for that month: the month’s planned expenses (a bill with its own month in that month only) + each debt payment that falls in that month (from its first payment to its payoff; a balance due in full once, in its month)",
   "inputs": [
    "MK-CF-I-012 planned expenses",
    "MK-CF-I-013 debt payment",
    "MK-CF-I-014 big bill"
   ],
   "decisions": [
    "A debt payment is counted as an outflow, not as saving (founder, 2026-06-21).",
    "A bill that falls once a year is shown in its own month, never spread.",
    "A debt counts in a month only if a payment falls in that month — the rule This month’s planned surplus (MK-CF-M-002) reads too (2026-10-24)."
   ],
   "refusal": "Shows $0 until expenses or debts are entered.",
   "note": "Printed by the plan card of a later month only, from the dated grid’s cell for that month.",
   "worked": {
    "given": "On 15 Sep 2026, October’s plan card: $7,200/month take-home; a $3,400/month budget, $2,300 of it the Rent / Mortgage line, which stands down for the $2,400 mortgage in Debts (on no property); and a $250 car loan.",
    "answer": "$3,750/month"
   }
  },
  "evidence": {
   "render": "CF_OCT",
   "line_beside_the_figure": {
    "as_the_measurer_reads_it": "/^Planned outflow \\(expenses \\+ debt\\)/",
    "found_at_render_line": 14
   },
   "printed_under": "MK-CF-M-048",
   "printed_texts": [
    "$3,750"
   ],
   "store": {
    "entered_keys_compared": 7,
    "entered": {
     "assetAccounts": "same",
     "liabilities": "same",
     "transactions": "same",
     "expenses": "same",
     "onboardingProfile": "same",
     "incomes": "same",
     "retirementAssumptions": "same"
    },
    "opening_changed_nothing_entered": true,
    "any_stored_value_changed": []
   },
   "sync": {
    "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
    "entered_keys_unchanged": 6,
    "of": 7,
    "what_the_sync_rewrote": {
     "onboardingProfile": {
      "grossWorkedBack": {
       "as_entered": null,
       "after_the_sync": true
      },
      "landsTypical": {
       "as_entered": null,
       "after_the_sync": "7200"
      },
      "salaryMode": {
       "as_entered": "takehome",
       "after_the_sync": "gross"
      }
     }
    },
    "figure_printed_after_the_sync": [
     "$3,750"
    ],
    "figure_same_after_the_sync": true,
    "whole_screen_same_after_the_sync": true
   }
  },
  "decisions": [
   "DEC-0002",
   "DEC-0200",
   "DEC-0292",
   "DEC-7946",
   "DEC-8084",
   "DEC-8153",
   "DEC-8387",
   "DEC-8459"
  ],
  "our_tests": [
   {
    "file": "src/screens/__tests__/outside_cashflow_openai_screens.test.tsx",
    "test": "MK-CF-M-048 Planned outflow (expenses + debt) › T5 · reviewer FAIL (evidence_gap) · EVIDENCE GAP · what holds",
    "result": "passed",
    "what_it_checks": "opening the screen changes nothing entered, and the figure prints under its identifier"
   }
  ],
  "status": "FOR YOU TO SETTLE",
  "status_reason": "tenet 5 asks whether a rule replaced what the person entered — a judgement on the figure, not on the store alone. Our facts: opening the screen changed nothing entered; the figure prints under MK-CF-M-048; a sync of the same household left 6 of 7 entered values exactly as typed and rewrote onboardingProfile: grossWorkedBack, landsTypical, salaryMode; the figure prints the same after it. Edits on another screen are not shown."
 },
 {
  "case": "MK-CF-M-048#6",
  "figure": "MK-CF-M-048",
  "figure_label": "Planned outflow (expenses + debt)",
  "tenet": 6,
  "tenet_words": "His decision is the design. The last approved drawing and the decision log say what the app does. A change of mine never stands against them. Every decision is recorded in his words and applied in every place it reaches.",
  "first_review": {
   "date": "2026-10-25",
   "reviewer": "OpenAI",
   "audit_part": "18",
   "verdict": "FAIL",
   "kind": "evidence_gap",
   "what_it_said_it_lacked": "The package supplies decision references,but this row has no ruleddate. Latest approved full drawing/rendered implementation for this exact figure was not independently supplied/inspected;do not infer designcompliance from registration alone."
  },
  "figure_record": {
   "label": "Planned outflow (expenses + debt)",
   "unit": "money",
   "per": "month",
   "grain": "one figure per household per month",
   "screens": [
    "/cashflow"
   ],
   "answers": "What the plan says goes out during a month after this one — printed on that month’s plan card: the budget, the debt payments that fall in that month, and any big bill that falls in it.",
   "formula": "planned outflow = the dated grid’s outflow for that month: the month’s planned expenses (a bill with its own month in that month only) + each debt payment that falls in that month (from its first payment to its payoff; a balance due in full once, in its month)",
   "inputs": [
    "MK-CF-I-012 planned expenses",
    "MK-CF-I-013 debt payment",
    "MK-CF-I-014 big bill"
   ],
   "decisions": [
    "A debt payment is counted as an outflow, not as saving (founder, 2026-06-21).",
    "A bill that falls once a year is shown in its own month, never spread.",
    "A debt counts in a month only if a payment falls in that month — the rule This month’s planned surplus (MK-CF-M-002) reads too (2026-10-24)."
   ],
   "refusal": "Shows $0 until expenses or debts are entered.",
   "note": "Printed by the plan card of a later month only, from the dated grid’s cell for that month.",
   "worked": {
    "given": "On 15 Sep 2026, October’s plan card: $7,200/month take-home; a $3,400/month budget, $2,300 of it the Rent / Mortgage line, which stands down for the $2,400 mortgage in Debts (on no property); and a $250 car loan.",
    "answer": "$3,750/month"
   }
  },
  "evidence": {
   "render": "CF_OCT",
   "line_beside_the_figure": {
    "as_the_measurer_reads_it": "/^Planned outflow \\(expenses \\+ debt\\)/",
    "found_at_render_line": 14
   },
   "printed_under": "MK-CF-M-048",
   "printed_texts": [
    "$3,750"
   ],
   "store": {
    "entered_keys_compared": 7,
    "entered": {
     "assetAccounts": "same",
     "liabilities": "same",
     "transactions": "same",
     "expenses": "same",
     "onboardingProfile": "same",
     "incomes": "same",
     "retirementAssumptions": "same"
    },
    "opening_changed_nothing_entered": true,
    "any_stored_value_changed": []
   },
   "sync": {
    "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
    "entered_keys_unchanged": 6,
    "of": 7,
    "what_the_sync_rewrote": {
     "onboardingProfile": {
      "grossWorkedBack": {
       "as_entered": null,
       "after_the_sync": true
      },
      "landsTypical": {
       "as_entered": null,
       "after_the_sync": "7200"
      },
      "salaryMode": {
       "as_entered": "takehome",
       "after_the_sync": "gross"
      }
     }
    },
    "figure_printed_after_the_sync": [
     "$3,750"
    ],
    "figure_same_after_the_sync": true,
    "whole_screen_same_after_the_sync": true
   },
   "drawing": {
    "file": "MoneyKeel/documents/cashflow/moneykeel_pres_mock_cash-flow_v01.html",
    "phones_read": "as the match test holds it (the drawn phone with each dated row and kept item applied by name)",
    "phones_that_hold_this_screen": [
     1,
     2
    ],
    "the_rendered_line": "Planned outflow (expenses + debt)",
    "drawn_on_those_phones": [],
    "matched": null,
    "drawn_elsewhere_on_the_drawing": [],
    "design_record_rows": [
     "Cash flow"
    ]
   },
   "match_tests": [
    {
     "file": "src/screens/__tests__/cashflow_matches_v01.test.tsx",
     "test": "A · This month, with data — Planned +$350 and Actual so far +$900, every row deducted, figure for figure",
     "kind": "test",
     "phones": [
      1
     ],
     "result": "passed",
     "lines": "55–59",
     "holds_the_phone_with_the_line": false
    },
    {
     "file": "src/screens/__tests__/cashflow_matches_v01.test.tsx",
     "test": "B · This month, a fresh account — no budget, so no planned surplus and no guess; Actual so far +$3,000",
     "kind": "test",
     "phones": [
      2
     ],
     "result": "passed",
     "lines": "61–65",
     "holds_the_phone_with_the_line": false
    }
   ]
  },
  "decisions": [
   "DEC-0002",
   "DEC-0200",
   "DEC-0292",
   "DEC-7946",
   "DEC-8084",
   "DEC-8153",
   "DEC-8387",
   "DEC-8459"
  ],
  "our_tests": [
   {
    "file": "src/screens/__tests__/outside_cashflow_openai_screens.test.tsx",
    "test": "MK-CF-M-048 Planned outflow (expenses + debt) › T6 · reviewer FAIL (evidence_gap) · EVIDENCE GAP · what holds",
    "result": "passed",
    "what_it_checks": "the line beside the figure is on the rendered screen, and its drawing and match test exist"
   }
  ],
  "status": "FOR YOU TO SETTLE",
  "status_reason": "the line is not on the phones that hold this screen (1, 2) — judge whether a dated row or a decision (DEC-1560 keeps twelve named items) allows it"
 },
 {
  "case": "MK-CF-M-049#5",
  "figure": "MK-CF-M-049",
  "figure_label": "= Planned surplus",
  "tenet": 5,
  "tenet_words": "The person's word outranks the app's guess. What they confirmed, typed or chose is never overwritten by a rule, a sync or a sweep.",
  "first_review": {
   "date": "2026-10-25",
   "reviewer": "OpenAI",
   "audit_part": "18",
   "verdict": "FAIL",
   "kind": "evidence_gap",
   "what_it_said_it_lacked": "A figure declaration cannot establish that edits,sync,imports and recomputation preserve the person’s entered values for = Planned surplus. No code/test/app was inspected;this is an unclosed evidence requirement,not an observed overwrite."
  },
  "figure_record": {
   "label": "= Planned surplus",
   "unit": "money",
   "per": "month",
   "grain": "one figure per household per month",
   "screens": [
    "/cashflow"
   ],
   "answers": "What the plan leaves over in a month after this one — printed on that month’s plan card.",
   "formula": "planned surplus = planned inflow − planned outflow, as the card prints them (the dated grid’s cell for that month)",
   "inputs": [
    "MK-CF-M-047 planned inflow",
    "MK-CF-M-048 planned outflow"
   ],
   "refusal": "Shows $0 until both sides are entered.",
   "note": "Printed by the plan card of a later month only. This month’s planned surplus is MK-CF-M-002; the retired view’s “Spent $X of $Y surplus” line prints MK-CF-M-078 (until 2026-10-24 it was printed under this number).",
   "worked": {
    "given": "On 15 Sep 2026, October’s plan card: $7,200/month take-home; a $3,400/month budget, $2,300 of it the Rent / Mortgage line, which stands down for the $2,400 mortgage in Debts (on no property); and a $250 car loan.",
    "answer": "$3,450/month"
   }
  },
  "evidence": {
   "render": "CF_OCT",
   "line_beside_the_figure": {
    "as_the_measurer_reads_it": "= Planned surplus",
    "found_at_render_line": 16
   },
   "printed_under": "MK-CF-M-049",
   "printed_texts": [
    "$3,450"
   ],
   "store": {
    "entered_keys_compared": 7,
    "entered": {
     "assetAccounts": "same",
     "liabilities": "same",
     "transactions": "same",
     "expenses": "same",
     "onboardingProfile": "same",
     "incomes": "same",
     "retirementAssumptions": "same"
    },
    "opening_changed_nothing_entered": true,
    "any_stored_value_changed": []
   },
   "sync": {
    "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
    "entered_keys_unchanged": 6,
    "of": 7,
    "what_the_sync_rewrote": {
     "onboardingProfile": {
      "grossWorkedBack": {
       "as_entered": null,
       "after_the_sync": true
      },
      "landsTypical": {
       "as_entered": null,
       "after_the_sync": "7200"
      },
      "salaryMode": {
       "as_entered": "takehome",
       "after_the_sync": "gross"
      }
     }
    },
    "figure_printed_after_the_sync": [
     "$3,450"
    ],
    "figure_same_after_the_sync": true,
    "whole_screen_same_after_the_sync": true
   }
  },
  "decisions": [
   "DEC-0200",
   "DEC-0512",
   "DEC-8084",
   "DEC-8153",
   "DEC-8366",
   "DEC-8387"
  ],
  "our_tests": [
   {
    "file": "src/screens/__tests__/outside_cashflow_openai_screens.test.tsx",
    "test": "MK-CF-M-049 = Planned surplus › T5 · reviewer FAIL (evidence_gap) · EVIDENCE GAP · what holds",
    "result": "passed",
    "what_it_checks": "opening the screen changes nothing entered, and the figure prints under its identifier"
   }
  ],
  "status": "FOR YOU TO SETTLE",
  "status_reason": "tenet 5 asks whether a rule replaced what the person entered — a judgement on the figure, not on the store alone. Our facts: opening the screen changed nothing entered; the figure prints under MK-CF-M-049; a sync of the same household left 6 of 7 entered values exactly as typed and rewrote onboardingProfile: grossWorkedBack, landsTypical, salaryMode; the figure prints the same after it. Edits on another screen are not shown."
 },
 {
  "case": "MK-CF-M-049#6",
  "figure": "MK-CF-M-049",
  "figure_label": "= Planned surplus",
  "tenet": 6,
  "tenet_words": "His decision is the design. The last approved drawing and the decision log say what the app does. A change of mine never stands against them. Every decision is recorded in his words and applied in every place it reaches.",
  "first_review": {
   "date": "2026-10-25",
   "reviewer": "OpenAI",
   "audit_part": "18",
   "verdict": "FAIL",
   "kind": "evidence_gap",
   "what_it_said_it_lacked": "The package supplies decision references,but this row has no ruleddate. Latest approved full drawing/rendered implementation for this exact figure was not independently supplied/inspected;do not infer designcompliance from registration alone."
  },
  "figure_record": {
   "label": "= Planned surplus",
   "unit": "money",
   "per": "month",
   "grain": "one figure per household per month",
   "screens": [
    "/cashflow"
   ],
   "answers": "What the plan leaves over in a month after this one — printed on that month’s plan card.",
   "formula": "planned surplus = planned inflow − planned outflow, as the card prints them (the dated grid’s cell for that month)",
   "inputs": [
    "MK-CF-M-047 planned inflow",
    "MK-CF-M-048 planned outflow"
   ],
   "refusal": "Shows $0 until both sides are entered.",
   "note": "Printed by the plan card of a later month only. This month’s planned surplus is MK-CF-M-002; the retired view’s “Spent $X of $Y surplus” line prints MK-CF-M-078 (until 2026-10-24 it was printed under this number).",
   "worked": {
    "given": "On 15 Sep 2026, October’s plan card: $7,200/month take-home; a $3,400/month budget, $2,300 of it the Rent / Mortgage line, which stands down for the $2,400 mortgage in Debts (on no property); and a $250 car loan.",
    "answer": "$3,450/month"
   }
  },
  "evidence": {
   "render": "CF_OCT",
   "line_beside_the_figure": {
    "as_the_measurer_reads_it": "= Planned surplus",
    "found_at_render_line": 16
   },
   "printed_under": "MK-CF-M-049",
   "printed_texts": [
    "$3,450"
   ],
   "store": {
    "entered_keys_compared": 7,
    "entered": {
     "assetAccounts": "same",
     "liabilities": "same",
     "transactions": "same",
     "expenses": "same",
     "onboardingProfile": "same",
     "incomes": "same",
     "retirementAssumptions": "same"
    },
    "opening_changed_nothing_entered": true,
    "any_stored_value_changed": []
   },
   "sync": {
    "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
    "entered_keys_unchanged": 6,
    "of": 7,
    "what_the_sync_rewrote": {
     "onboardingProfile": {
      "grossWorkedBack": {
       "as_entered": null,
       "after_the_sync": true
      },
      "landsTypical": {
       "as_entered": null,
       "after_the_sync": "7200"
      },
      "salaryMode": {
       "as_entered": "takehome",
       "after_the_sync": "gross"
      }
     }
    },
    "figure_printed_after_the_sync": [
     "$3,450"
    ],
    "figure_same_after_the_sync": true,
    "whole_screen_same_after_the_sync": true
   },
   "drawing": {
    "file": "MoneyKeel/documents/cashflow/moneykeel_pres_mock_cash-flow_v01.html",
    "phones_read": "as the match test holds it (the drawn phone with each dated row and kept item applied by name)",
    "phones_that_hold_this_screen": [
     1,
     2
    ],
    "the_rendered_line": "= Planned surplus",
    "drawn_on_those_phones": [
     {
      "phone": 1,
      "line": 30,
      "text": "= Planned surplus"
     }
    ],
    "matched": "the whole rendered line, word for word",
    "drawn_elsewhere_on_the_drawing": [],
    "design_record_rows": [
     "Cash flow"
    ]
   },
   "match_tests": [
    {
     "file": "src/screens/__tests__/cashflow_matches_v01.test.tsx",
     "test": "A · This month, with data — Planned +$350 and Actual so far +$900, every row deducted, figure for figure",
     "kind": "test",
     "phones": [
      1
     ],
     "result": "passed",
     "lines": "55–59",
     "holds_the_phone_with_the_line": true
    },
    {
     "file": "src/screens/__tests__/cashflow_matches_v01.test.tsx",
     "test": "B · This month, a fresh account — no budget, so no planned surplus and no guess; Actual so far +$3,000",
     "kind": "test",
     "phones": [
      2
     ],
     "result": "passed",
     "lines": "61–65",
     "holds_the_phone_with_the_line": false
    }
   ]
  },
  "decisions": [
   "DEC-0200",
   "DEC-0512",
   "DEC-8084",
   "DEC-8153",
   "DEC-8366",
   "DEC-8387"
  ],
  "our_tests": [
   {
    "file": "src/screens/__tests__/outside_cashflow_openai_screens.test.tsx",
    "test": "MK-CF-M-049 = Planned surplus › T6 · reviewer FAIL (evidence_gap) · EVIDENCE GAP · what holds",
    "result": "passed",
    "what_it_checks": "the line beside the figure is on the rendered screen, and its drawing and match test exist"
   }
  ],
  "status": "SETTLED BY OUR TESTS — WORDS AND FIGURES",
  "status_reason": "the line is drawn on phone 1 (the whole rendered line, word for word), and every test that holds that phone word for word and figure for figure, in the drawing's own household, passes at this build: A · This month, with data — Planned +$350 and Actual so far +$900, every row deducted, figure for figure. Appearance (colour, size, spacing) is not tested here."
 },
 {
  "case": "MK-CF-M-050#5",
  "figure": "MK-CF-M-050",
  "figure_label": "each planned line",
  "tenet": 5,
  "tenet_words": "The person's word outranks the app's guess. What they confirmed, typed or chose is never overwritten by a rule, a sync or a sweep.",
  "first_review": {
   "date": "2026-10-25",
   "reviewer": "OpenAI",
   "audit_part": "18",
   "verdict": "FAIL",
   "kind": "evidence_gap",
   "what_it_said_it_lacked": "A figure declaration cannot establish that edits,sync,imports and recomputation preserve the person’s entered values for each planned line. No code/test/app was inspected;this is an unclosed evidence requirement,not an observed overwrite."
  },
  "figure_record": {
   "label": "each planned line",
   "unit": "money",
   "per": "month",
   "grain": "one figure per line per month",
   "screens": [
    "/cashflow"
   ],
   "answers": "Each thing the plan says comes in or goes out this month, named, so the two totals can be checked by hand.",
   "formula": "one line per source or commitment that falls in this month, at its amount for this month",
   "inputs": [
    "MK-CF-M-047 expected inflow",
    "MK-CF-M-048 planned outflow"
   ],
   "refusal": "The list is replaced by the door to enter income or expenses when nothing is entered.",
   "worked": {
    "given": "September 2026: $7,200 take-home; a $2,400 mortgage (on no property in Net worth) and a $250 car loan due; a $3,400 budget, $2,300 of it the Rent / Mortgage line, which stands down for the mortgage in Debts. Logged so far: $2,300 under Rent / Mortgage (the mortgage’s payment), $512 groceries, $186 eating out, and the $250 car loan paid.",
    "answer": "−$2,400/month"
   }
  },
  "evidence": {
   "render": "CF",
   "line_beside_the_figure": {
    "as_the_measurer_reads_it": "/^PLANNED · SEPTEMBER$/",
    "found_at_render_line": 10
   },
   "printed_under": "MK-CF-M-004",
   "printed_texts": [
    "$7,200",
    "$2,400",
    "$250",
    "$1,100",
    "$7,200",
    "$2,300",
    "$250",
    "$698"
   ],
   "store": {
    "entered_keys_compared": 7,
    "entered": {
     "assetAccounts": "same",
     "liabilities": "same",
     "transactions": "same",
     "expenses": "same",
     "onboardingProfile": "same",
     "incomes": "same",
     "retirementAssumptions": "same"
    },
    "opening_changed_nothing_entered": true,
    "any_stored_value_changed": []
   },
   "sync": {
    "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
    "entered_keys_unchanged": 6,
    "of": 7,
    "what_the_sync_rewrote": {
     "onboardingProfile": {
      "grossWorkedBack": {
       "as_entered": null,
       "after_the_sync": true
      },
      "landsTypical": {
       "as_entered": null,
       "after_the_sync": "7200"
      },
      "salaryMode": {
       "as_entered": "takehome",
       "after_the_sync": "gross"
      }
     }
    },
    "figure_printed_after_the_sync": [
     "$7,200",
     "$2,400",
     "$250",
     "$1,100",
     "$7,200",
     "$2,300",
     "$250",
     "$698"
    ],
    "figure_same_after_the_sync": true,
    "whole_screen_same_after_the_sync": true
   }
  },
  "decisions": [
   "DEC-0200",
   "DEC-8387"
  ],
  "our_tests": [
   {
    "file": "src/screens/__tests__/outside_cashflow_openai_screens.test.tsx",
    "test": "MK-CF-M-050 each planned line › T5 · reviewer FAIL (evidence_gap) · EVIDENCE GAP · what holds",
    "result": "passed",
    "what_it_checks": "opening the screen changes nothing entered, and the figure prints under its identifier"
   }
  ],
  "status": "FOR YOU TO SETTLE",
  "status_reason": "tenet 5 asks whether a rule replaced what the person entered — a judgement on the figure, not on the store alone. Our facts: opening the screen changed nothing entered; the figure prints under MK-CF-M-004; a sync of the same household left 6 of 7 entered values exactly as typed and rewrote onboardingProfile: grossWorkedBack, landsTypical, salaryMode; the figure prints the same after it. Edits on another screen are not shown."
 },
 {
  "case": "MK-CF-M-050#6",
  "figure": "MK-CF-M-050",
  "figure_label": "each planned line",
  "tenet": 6,
  "tenet_words": "His decision is the design. The last approved drawing and the decision log say what the app does. A change of mine never stands against them. Every decision is recorded in his words and applied in every place it reaches.",
  "first_review": {
   "date": "2026-10-25",
   "reviewer": "OpenAI",
   "audit_part": "18",
   "verdict": "FAIL",
   "kind": "evidence_gap",
   "what_it_said_it_lacked": "The package supplies decision references,but this row has no ruleddate. Latest approved full drawing/rendered implementation for this exact figure was not independently supplied/inspected;do not infer designcompliance from registration alone."
  },
  "figure_record": {
   "label": "each planned line",
   "unit": "money",
   "per": "month",
   "grain": "one figure per line per month",
   "screens": [
    "/cashflow"
   ],
   "answers": "Each thing the plan says comes in or goes out this month, named, so the two totals can be checked by hand.",
   "formula": "one line per source or commitment that falls in this month, at its amount for this month",
   "inputs": [
    "MK-CF-M-047 expected inflow",
    "MK-CF-M-048 planned outflow"
   ],
   "refusal": "The list is replaced by the door to enter income or expenses when nothing is entered.",
   "worked": {
    "given": "September 2026: $7,200 take-home; a $2,400 mortgage (on no property in Net worth) and a $250 car loan due; a $3,400 budget, $2,300 of it the Rent / Mortgage line, which stands down for the mortgage in Debts. Logged so far: $2,300 under Rent / Mortgage (the mortgage’s payment), $512 groceries, $186 eating out, and the $250 car loan paid.",
    "answer": "−$2,400/month"
   }
  },
  "evidence": {
   "render": "CF",
   "line_beside_the_figure": {
    "as_the_measurer_reads_it": "/^PLANNED · SEPTEMBER$/",
    "found_at_render_line": 10
   },
   "printed_under": "MK-CF-M-004",
   "printed_texts": [
    "$7,200",
    "$2,400",
    "$250",
    "$1,100",
    "$7,200",
    "$2,300",
    "$250",
    "$698"
   ],
   "store": {
    "entered_keys_compared": 7,
    "entered": {
     "assetAccounts": "same",
     "liabilities": "same",
     "transactions": "same",
     "expenses": "same",
     "onboardingProfile": "same",
     "incomes": "same",
     "retirementAssumptions": "same"
    },
    "opening_changed_nothing_entered": true,
    "any_stored_value_changed": []
   },
   "sync": {
    "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
    "entered_keys_unchanged": 6,
    "of": 7,
    "what_the_sync_rewrote": {
     "onboardingProfile": {
      "grossWorkedBack": {
       "as_entered": null,
       "after_the_sync": true
      },
      "landsTypical": {
       "as_entered": null,
       "after_the_sync": "7200"
      },
      "salaryMode": {
       "as_entered": "takehome",
       "after_the_sync": "gross"
      }
     }
    },
    "figure_printed_after_the_sync": [
     "$7,200",
     "$2,400",
     "$250",
     "$1,100",
     "$7,200",
     "$2,300",
     "$250",
     "$698"
    ],
    "figure_same_after_the_sync": true,
    "whole_screen_same_after_the_sync": true
   },
   "drawing": {
    "file": "MoneyKeel/documents/cashflow/moneykeel_pres_mock_cash-flow_v01.html",
    "phones_read": "as the match test holds it (the drawn phone with each dated row and kept item applied by name)",
    "phones_that_hold_this_screen": [
     1,
     2
    ],
    "the_rendered_line": "PLANNED · SEPTEMBER",
    "drawn_on_those_phones": [
     {
      "phone": 1,
      "line": 10,
      "text": "Planned · August"
     },
     {
      "phone": 2,
      "line": 10,
      "text": "Planned · August"
     }
    ],
    "matched": "the same words, with the drawing's own figures and dates",
    "drawn_elsewhere_on_the_drawing": [],
    "design_record_rows": [
     "Cash flow"
    ]
   },
   "match_tests": [
    {
     "file": "src/screens/__tests__/cashflow_matches_v01.test.tsx",
     "test": "A · This month, with data — Planned +$350 and Actual so far +$900, every row deducted, figure for figure",
     "kind": "test",
     "phones": [
      1
     ],
     "result": "passed",
     "lines": "55–59",
     "holds_the_phone_with_the_line": true
    },
    {
     "file": "src/screens/__tests__/cashflow_matches_v01.test.tsx",
     "test": "B · This month, a fresh account — no budget, so no planned surplus and no guess; Actual so far +$3,000",
     "kind": "test",
     "phones": [
      2
     ],
     "result": "passed",
     "lines": "61–65",
     "holds_the_phone_with_the_line": true
    }
   ]
  },
  "decisions": [
   "DEC-0200",
   "DEC-8387"
  ],
  "our_tests": [
   {
    "file": "src/screens/__tests__/outside_cashflow_openai_screens.test.tsx",
    "test": "MK-CF-M-050 each planned line › T6 · reviewer FAIL (evidence_gap) · EVIDENCE GAP · what holds",
    "result": "passed",
    "what_it_checks": "the line beside the figure is on the rendered screen, and its drawing and match test exist"
   }
  ],
  "status": "SETTLED BY OUR TESTS — WORDS AND FIGURES",
  "status_reason": "the line is drawn on phone 1, 2 (the same words, with the drawing's own figures and dates), and every test that holds that phone word for word and figure for figure, in the drawing's own household, passes at this build: A · This month, with data — Planned +$350 and Actual so far +$900, every row deducted, figure for figure; B · This month, a fresh account — no budget, so no planned surplus and no guess; Actual so far +$3,000. Appearance (colour, size, spacing) is not tested here."
 },
 {
  "case": "MK-CF-M-051#6",
  "figure": "MK-CF-M-051",
  "figure_label": "Inflow",
  "tenet": 6,
  "tenet_words": "His decision is the design. The last approved drawing and the decision log say what the app does. A change of mine never stands against them. Every decision is recorded in his words and applied in every place it reaches.",
  "first_review": {
   "date": "2026-10-25",
   "reviewer": "OpenAI",
   "audit_part": "18",
   "verdict": "FAIL",
   "kind": "evidence_gap",
   "what_it_said_it_lacked": "The package supplies decision references,but this row has no ruleddate. Latest approved full drawing/rendered implementation for this exact figure was not independently supplied/inspected;do not infer designcompliance from registration alone."
  },
  "figure_record": {
   "label": "Inflow",
   "unit": "money",
   "per": "month",
   "grain": "one figure per household per month",
   "screens": [
    "/cashflow",
    "/home"
   ],
   "answers": "What has come in this month on the actual side: the month’s take-home, as the approved drawing draws it — before any paycheck is recorded as received.",
   "formula": "inflow = the month’s take-home — this month’s cell of the dated grid: every source that lands in this month, after tax and 401(k); a payment recorded as received is listed under RECEIVED on the Income tab (MK-CF-M-012) and is not added to it",
   "inputs": [
    "MK-CF-M-037 take-home each month"
   ],
   "decisions": [
    "THE APPROVED DRAWING WINS (2026-10-23, under his rules DEC-3523 tenet 6 and \"the newest approval wins\", 2026-09-27): cash-flow_v01, approved 2026-09-28 (DEC-0440), draws the month’s take-home as Actual inflow with nothing recorded. The words this row carried — \"nothing is assumed to have arrived; a source counts only once it is recorded\" (2026-08-28) — are older and stand down. To reverse: count only recorded payments here, and Cash flow and Home move together.",
    "Home prints this same figure, from the same rows (2026-10-23): it added any income recorded as received on top of the take-home, which Cash flow does not."
   ],
   "refusal": "Income not entered: $0, and under it the one line \"Nothing entered yet. Add your income ›\" on Home (Q48); Cash flow draws no month until income is entered — its two set-up steps stand in its place.",
   "note": "The words beside it name what is inside it — \"Inflow (income (take-home) + rent)\" — his cluster 5 ruling of 2026-09-10.",
   "worked": {
    "given": "September 2026: $7,200 take-home; a $2,400 mortgage (on no property in Net worth) and a $250 car loan due; a $3,400 budget, $2,300 of it the Rent / Mortgage line, which stands down for the mortgage in Debts. Logged so far: $2,300 under Rent / Mortgage (the mortgage’s payment), $512 groceries, $186 eating out, and the $250 car loan paid.",
    "answer": "$7,200/month"
   }
  },
  "evidence": {
   "render": "HOME",
   "line_beside_the_figure": {
    "as_the_measurer_reads_it": "Income",
    "found_at_render_line": 34
   },
   "printed_under": "MK-CF-M-051",
   "printed_texts": [
    "$7,200"
   ],
   "store": {
    "entered_keys_compared": 7,
    "entered": {
     "assetAccounts": "same",
     "liabilities": "same",
     "transactions": "same",
     "expenses": "same",
     "onboardingProfile": "same",
     "incomes": "same",
     "retirementAssumptions": "same"
    },
    "opening_changed_nothing_entered": true,
    "any_stored_value_changed": [
     "monthlySnapshots",
     "nwDaily",
     "invDaily",
     "snapshotDays",
     "lastRetireChance",
     "milestoneHighSeen"
    ]
   },
   "sync": {
    "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
    "entered_keys_unchanged": 6,
    "of": 7,
    "what_the_sync_rewrote": {
     "onboardingProfile": {
      "grossWorkedBack": {
       "as_entered": null,
       "after_the_sync": true
      },
      "landsTypical": {
       "as_entered": null,
       "after_the_sync": "7200"
      },
      "salaryMode": {
       "as_entered": "takehome",
       "after_the_sync": "gross"
      }
     }
    },
    "figure_printed_after_the_sync": [
     "$7,200"
    ],
    "figure_same_after_the_sync": true,
    "whole_screen_same_after_the_sync": true
   },
   "drawing": {
    "file": "MoneyKeel/documents/cashflow/moneykeel_pres_mock_cash-flow_v01.html",
    "phones_read": "as the match test holds it (the drawn phone with each dated row and kept item applied by name)",
    "phones_that_hold_this_screen": [],
    "the_rendered_line": "Income",
    "drawn_on_those_phones": [],
    "matched": null,
    "drawn_elsewhere_on_the_drawing": [
     {
      "phone": 1,
      "line": 7,
      "text": "Income"
     },
     {
      "phone": 2,
      "line": 7,
      "text": "Income"
     },
     {
      "phone": 3,
      "line": 7,
      "text": "Income"
     },
     {
      "phone": 4,
      "line": 7,
      "text": "Income"
     },
     {
      "phone": 5,
      "line": 7,
      "text": "Income"
     },
     {
      "phone": 6,
      "line": 7,
      "text": "Income"
     }
    ],
    "design_record_rows": []
   },
   "match_tests": []
  },
  "decisions": [
   "DEC-0199",
   "DEC-0200",
   "DEC-0440",
   "DEC-3523",
   "DEC-7607",
   "DEC-7937",
   "DEC-7938",
   "DEC-8387"
  ],
  "our_tests": [
   {
    "file": "src/screens/__tests__/outside_cashflow_openai_screens.test.tsx",
    "test": "MK-CF-M-051 Inflow › T6 · reviewer FAIL (evidence_gap) · EVIDENCE GAP · what holds",
    "result": "passed",
    "what_it_checks": "the line beside the figure is on the rendered screen, and its drawing and match test exist"
   }
  ],
  "status": "FOR YOU TO SETTLE",
  "status_reason": "no test holds this screen to a phone of the drawing"
 },
 {
  "case": "MK-CF-M-052#5",
  "figure": "MK-CF-M-052",
  "figure_label": "Outflow (expenses + debt)",
  "tenet": 5,
  "tenet_words": "The person's word outranks the app's guess. What they confirmed, typed or chose is never overwritten by a rule, a sync or a sweep.",
  "first_review": {
   "date": "2026-10-25",
   "reviewer": "OpenAI",
   "audit_part": "18",
   "verdict": "FAIL",
   "kind": "evidence_gap",
   "what_it_said_it_lacked": "A figure declaration cannot establish that edits,sync,imports and recomputation preserve the person’s entered values for Outflow (expenses + debt). No code/test/app was inspected;this is an unclosed evidence requirement,not an observed overwrite."
  },
  "figure_record": {
   "label": "Outflow (expenses + debt)",
   "unit": "money",
   "per": "month",
   "grain": "one figure per household per month",
   "screens": [
    "/cashflow",
    "/home"
   ],
   "answers": "What has actually gone out so far this month: the expenses logged and the debt payments made.",
   "formula": "Outflow (expenses + debt) so far = MK-CF-F-194 monthOutflow of the expenses logged so far this month and the debt payments made so far; an unpaid debt shows $0 with its due day",
   "inputs": [
    "MK-CF-I-016 logged expense",
    "MK-CF-I-013 debt payment"
   ],
   "decisions": [
    "A debt payment counts once it is made — logged as a debt payment — and an unpaid debt shows $0 with its due day, never left off (the approved drawing, DEC-0440).",
    "Home prints this same figure, from the same rows (2026-10-23): it used to count the expenses only, without the debt paid."
   ],
   "refusal": "A real $0 when nothing is logged and no debt is paid. Cash flow draws no month until income is entered (its two set-up steps); a past month with no record reads \"Nothing recorded for this month — it predates your tracking.\"",
   "worked": {
    "given": "September 2026: $7,200 take-home; a $2,400 mortgage (on no property in Net worth) and a $250 car loan due; a $3,400 budget, $2,300 of it the Rent / Mortgage line, which stands down for the mortgage in Debts. Logged so far: $2,300 under Rent / Mortgage (the mortgage’s payment), $512 groceries, $186 eating out, and the $250 car loan paid.",
    "answer": "−$3,248/month"
   }
  },
  "evidence": {
   "render": "HOME",
   "line_beside_the_figure": {
    "as_the_measurer_reads_it": "Outflow (expenses + debt)",
    "found_at_render_line": 36
   },
   "printed_under": "MK-CF-M-052",
   "printed_texts": [
    "$3,248"
   ],
   "store": {
    "entered_keys_compared": 7,
    "entered": {
     "assetAccounts": "same",
     "liabilities": "same",
     "transactions": "same",
     "expenses": "same",
     "onboardingProfile": "same",
     "incomes": "same",
     "retirementAssumptions": "same"
    },
    "opening_changed_nothing_entered": true,
    "any_stored_value_changed": [
     "monthlySnapshots",
     "nwDaily",
     "invDaily",
     "snapshotDays",
     "lastRetireChance",
     "milestoneHighSeen"
    ]
   },
   "sync": {
    "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
    "entered_keys_unchanged": 6,
    "of": 7,
    "what_the_sync_rewrote": {
     "onboardingProfile": {
      "grossWorkedBack": {
       "as_entered": null,
       "after_the_sync": true
      },
      "landsTypical": {
       "as_entered": null,
       "after_the_sync": "7200"
      },
      "salaryMode": {
       "as_entered": "takehome",
       "after_the_sync": "gross"
      }
     }
    },
    "figure_printed_after_the_sync": [
     "$3,248"
    ],
    "figure_same_after_the_sync": true,
    "whole_screen_same_after_the_sync": true
   }
  },
  "decisions": [
   "DEC-0200",
   "DEC-0260",
   "DEC-0292",
   "DEC-0333",
   "DEC-0440",
   "DEC-7609",
   "DEC-7937",
   "DEC-7949",
   "DEC-8084",
   "DEC-8085",
   "DEC-8152",
   "DEC-8362",
   "DEC-8387",
   "DEC-8459"
  ],
  "our_tests": [
   {
    "file": "src/screens/__tests__/outside_cashflow_openai_screens.test.tsx",
    "test": "MK-CF-M-052 Outflow (expenses + debt) › T5 · reviewer FAIL (evidence_gap) · EVIDENCE GAP · what holds",
    "result": "passed",
    "what_it_checks": "opening the screen changes nothing entered, and the figure prints under its identifier"
   }
  ],
  "status": "FOR YOU TO SETTLE",
  "status_reason": "tenet 5 asks whether a rule replaced what the person entered — a judgement on the figure, not on the store alone. Our facts: opening the screen changed nothing entered; the figure prints under MK-CF-M-052; a sync of the same household left 6 of 7 entered values exactly as typed and rewrote onboardingProfile: grossWorkedBack, landsTypical, salaryMode; the figure prints the same after it. Edits on another screen are not shown."
 },
 {
  "case": "MK-CF-M-053#6",
  "figure": "MK-CF-M-053",
  "figure_label": "= Surplus",
  "tenet": 6,
  "tenet_words": "His decision is the design. The last approved drawing and the decision log say what the app does. A change of mine never stands against them. Every decision is recorded in his words and applied in every place it reaches.",
  "first_review": {
   "date": "2026-10-25",
   "reviewer": "OpenAI",
   "audit_part": "18",
   "verdict": "FAIL",
   "kind": "evidence_gap",
   "what_it_said_it_lacked": "The package supplies decision references,but this row has no ruleddate. Latest approved full drawing/rendered implementation for this exact figure was not independently supplied/inspected;do not infer designcompliance from registration alone."
  },
  "figure_record": {
   "label": "= Surplus",
   "unit": "money",
   "per": "month",
   "grain": "one figure per household per month",
   "screens": [
    "/cashflow",
    "/home"
   ],
   "answers": "What is actually left this month so far — not what the plan said, what has happened.",
   "formula": "surplus so far = inflow so far − outflow so far",
   "inputs": [
    "MK-CF-M-051 inflow so far",
    "MK-CF-M-052 outflow so far"
   ],
   "decisions": [
    "ONE FIGURE ON TWO SCREENS (2026-10-23, DEC-0345 and tenet 4): Home's \"Left\" is the Cash flow tab's \"= Actual surplus so far\", read from the same rows — Home showed $4,202 against Cash flow's $3,952 for one month because it left out the $250 car loan paid."
   ],
   "refusal": "Income not entered: no surplus — Cash flow shows its two set-up steps, and Home's box reads — beside Left, with \"Nothing entered yet. Add your income ›\" under Income and no pace word. A past month with no record: $0 and \"Nothing recorded for this month — it predates your tracking.\"",
   "note": "The Cash flow screen used to subtract this itself (rule 5). It is the door’s figure now.",
   "worked": {
    "given": "September 2026: $7,200 take-home; a $2,400 mortgage (on no property in Net worth) and a $250 car loan due; a $3,400 budget, $2,300 of it the Rent / Mortgage line, which stands down for the mortgage in Debts. Logged so far: $2,300 under Rent / Mortgage (the mortgage’s payment), $512 groceries, $186 eating out, and the $250 car loan paid.",
    "answer": "$3,952/month"
   }
  },
  "evidence": {
   "render": "HOME",
   "line_beside_the_figure": {
    "as_the_measurer_reads_it": "Left",
    "found_at_render_line": 38
   },
   "printed_under": "MK-CF-M-053",
   "printed_texts": [
    "$3,952"
   ],
   "store": {
    "entered_keys_compared": 7,
    "entered": {
     "assetAccounts": "same",
     "liabilities": "same",
     "transactions": "same",
     "expenses": "same",
     "onboardingProfile": "same",
     "incomes": "same",
     "retirementAssumptions": "same"
    },
    "opening_changed_nothing_entered": true,
    "any_stored_value_changed": [
     "monthlySnapshots",
     "nwDaily",
     "invDaily",
     "snapshotDays",
     "lastRetireChance",
     "milestoneHighSeen"
    ]
   },
   "sync": {
    "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
    "entered_keys_unchanged": 6,
    "of": 7,
    "what_the_sync_rewrote": {
     "onboardingProfile": {
      "grossWorkedBack": {
       "as_entered": null,
       "after_the_sync": true
      },
      "landsTypical": {
       "as_entered": null,
       "after_the_sync": "7200"
      },
      "salaryMode": {
       "as_entered": "takehome",
       "after_the_sync": "gross"
      }
     }
    },
    "figure_printed_after_the_sync": [
     "$3,952"
    ],
    "figure_same_after_the_sync": true,
    "whole_screen_same_after_the_sync": true
   },
   "drawing": {
    "file": "MoneyKeel/documents/cashflow/moneykeel_pres_mock_cash-flow_v01.html",
    "phones_read": "as the match test holds it (the drawn phone with each dated row and kept item applied by name)",
    "phones_that_hold_this_screen": [],
    "the_rendered_line": "Left",
    "drawn_on_those_phones": [],
    "matched": null,
    "drawn_elsewhere_on_the_drawing": [],
    "design_record_rows": []
   },
   "match_tests": []
  },
  "decisions": [
   "DEC-0200",
   "DEC-0345",
   "DEC-0512",
   "DEC-7606",
   "DEC-7609",
   "DEC-7937",
   "DEC-7946",
   "DEC-8152",
   "DEC-8387"
  ],
  "our_tests": [
   {
    "file": "src/screens/__tests__/outside_cashflow_openai_screens.test.tsx",
    "test": "MK-CF-M-053 = Surplus › T6 · reviewer FAIL (evidence_gap) · EVIDENCE GAP · what holds",
    "result": "passed",
    "what_it_checks": "the line beside the figure is on the rendered screen, and its drawing and match test exist"
   }
  ],
  "status": "FOR YOU TO SETTLE",
  "status_reason": "no test holds this screen to a phone of the drawing"
 },
 {
  "case": "MK-CF-M-054#5",
  "figure": "MK-CF-M-054",
  "figure_label": "each line of what has happened so far",
  "tenet": 5,
  "tenet_words": "The person's word outranks the app's guess. What they confirmed, typed or chose is never overwritten by a rule, a sync or a sweep.",
  "first_review": {
   "date": "2026-10-25",
   "reviewer": "OpenAI",
   "audit_part": "18",
   "verdict": "FAIL",
   "kind": "evidence_gap",
   "what_it_said_it_lacked": "A figure declaration cannot establish that edits,sync,imports and recomputation preserve the person’s entered values for each received line. No code/test/app was inspected;this is an unclosed evidence requirement,not an observed overwrite."
  },
  "figure_record": {
   "label": "each line of what has happened so far",
   "unit": "money",
   "per": "month",
   "grain": "one figure per line",
   "screens": [
    "/cashflow"
   ],
   "answers": "Each line of the actual side of the month, named — the inflow, each debt paid or still due, the expenses — so the actual surplus can be checked by hand.",
   "formula": "one line per row of the actual block, at its amount so far: the inflow; each debt, minus what was paid against it this month ($0 with its due day when nothing was); other debt payments; the expenses entered by hand and imported",
   "inputs": [
    "MK-CF-M-037 take-home each month",
    "MK-CF-I-013 debt payment",
    "MK-CF-I-016 logged expense"
   ],
   "refusal": "A real $0 on a line with nothing in it — a debt not paid yet reads $0 with its due day, and \"Expenses entered by hand\" stays at $0; Cash flow draws no month until income is entered.",
   "worked": {
    "given": "September 2026: $7,200 take-home; a $2,400 mortgage (on no property in Net worth) and a $250 car loan due; a $3,400 budget, $2,300 of it the Rent / Mortgage line, which stands down for the mortgage in Debts. Logged so far: $2,300 under Rent / Mortgage (the mortgage’s payment), $512 groceries, $186 eating out, and the $250 car loan paid.",
    "answer": "−$250/month"
   }
  },
  "evidence": {
   "render": "CF",
   "line_beside_the_figure": {
    "as_the_measurer_reads_it": "ACTUAL · SO FAR",
    "found_at_render_line": 31
   },
   "printed_under": "MK-CF-M-004",
   "printed_texts": [
    "$7,200",
    "$2,400",
    "$250",
    "$1,100",
    "$7,200",
    "$2,300",
    "$250",
    "$698"
   ],
   "store": {
    "entered_keys_compared": 7,
    "entered": {
     "assetAccounts": "same",
     "liabilities": "same",
     "transactions": "same",
     "expenses": "same",
     "onboardingProfile": "same",
     "incomes": "same",
     "retirementAssumptions": "same"
    },
    "opening_changed_nothing_entered": true,
    "any_stored_value_changed": []
   },
   "sync": {
    "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
    "entered_keys_unchanged": 6,
    "of": 7,
    "what_the_sync_rewrote": {
     "onboardingProfile": {
      "grossWorkedBack": {
       "as_entered": null,
       "after_the_sync": true
      },
      "landsTypical": {
       "as_entered": null,
       "after_the_sync": "7200"
      },
      "salaryMode": {
       "as_entered": "takehome",
       "after_the_sync": "gross"
      }
     }
    },
    "figure_printed_after_the_sync": [
     "$7,200",
     "$2,400",
     "$250",
     "$1,100",
     "$7,200",
     "$2,300",
     "$250",
     "$698"
    ],
    "figure_same_after_the_sync": true,
    "whole_screen_same_after_the_sync": true
   }
  },
  "decisions": [
   "DEC-0200",
   "DEC-8387",
   "DEC-8771"
  ],
  "our_tests": [
   {
    "file": "src/screens/__tests__/outside_cashflow_openai_screens.test.tsx",
    "test": "MK-CF-M-054 each line of what has happened so far › T5 · reviewer FAIL (evidence_gap) · EVIDENCE GAP · what holds",
    "result": "passed",
    "what_it_checks": "opening the screen changes nothing entered, and the figure prints under its identifier"
   }
  ],
  "status": "FOR YOU TO SETTLE",
  "status_reason": "tenet 5 asks whether a rule replaced what the person entered — a judgement on the figure, not on the store alone. Our facts: opening the screen changed nothing entered; the figure prints under MK-CF-M-004; a sync of the same household left 6 of 7 entered values exactly as typed and rewrote onboardingProfile: grossWorkedBack, landsTypical, salaryMode; the figure prints the same after it. Edits on another screen are not shown."
 },
 {
  "case": "MK-CF-M-054#6",
  "figure": "MK-CF-M-054",
  "figure_label": "each line of what has happened so far",
  "tenet": 6,
  "tenet_words": "His decision is the design. The last approved drawing and the decision log say what the app does. A change of mine never stands against them. Every decision is recorded in his words and applied in every place it reaches.",
  "first_review": {
   "date": "2026-10-25",
   "reviewer": "OpenAI",
   "audit_part": "18",
   "verdict": "FAIL",
   "kind": "evidence_gap",
   "what_it_said_it_lacked": "The package supplies decision references,but this row has no ruleddate. Latest approved full drawing/rendered implementation for this exact figure was not independently supplied/inspected;do not infer designcompliance from registration alone."
  },
  "figure_record": {
   "label": "each line of what has happened so far",
   "unit": "money",
   "per": "month",
   "grain": "one figure per line",
   "screens": [
    "/cashflow"
   ],
   "answers": "Each line of the actual side of the month, named — the inflow, each debt paid or still due, the expenses — so the actual surplus can be checked by hand.",
   "formula": "one line per row of the actual block, at its amount so far: the inflow; each debt, minus what was paid against it this month ($0 with its due day when nothing was); other debt payments; the expenses entered by hand and imported",
   "inputs": [
    "MK-CF-M-037 take-home each month",
    "MK-CF-I-013 debt payment",
    "MK-CF-I-016 logged expense"
   ],
   "refusal": "A real $0 on a line with nothing in it — a debt not paid yet reads $0 with its due day, and \"Expenses entered by hand\" stays at $0; Cash flow draws no month until income is entered.",
   "worked": {
    "given": "September 2026: $7,200 take-home; a $2,400 mortgage (on no property in Net worth) and a $250 car loan due; a $3,400 budget, $2,300 of it the Rent / Mortgage line, which stands down for the mortgage in Debts. Logged so far: $2,300 under Rent / Mortgage (the mortgage’s payment), $512 groceries, $186 eating out, and the $250 car loan paid.",
    "answer": "−$250/month"
   }
  },
  "evidence": {
   "render": "CF",
   "line_beside_the_figure": {
    "as_the_measurer_reads_it": "ACTUAL · SO FAR",
    "found_at_render_line": 31
   },
   "printed_under": "MK-CF-M-004",
   "printed_texts": [
    "$7,200",
    "$2,400",
    "$250",
    "$1,100",
    "$7,200",
    "$2,300",
    "$250",
    "$698"
   ],
   "store": {
    "entered_keys_compared": 7,
    "entered": {
     "assetAccounts": "same",
     "liabilities": "same",
     "transactions": "same",
     "expenses": "same",
     "onboardingProfile": "same",
     "incomes": "same",
     "retirementAssumptions": "same"
    },
    "opening_changed_nothing_entered": true,
    "any_stored_value_changed": []
   },
   "sync": {
    "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
    "entered_keys_unchanged": 6,
    "of": 7,
    "what_the_sync_rewrote": {
     "onboardingProfile": {
      "grossWorkedBack": {
       "as_entered": null,
       "after_the_sync": true
      },
      "landsTypical": {
       "as_entered": null,
       "after_the_sync": "7200"
      },
      "salaryMode": {
       "as_entered": "takehome",
       "after_the_sync": "gross"
      }
     }
    },
    "figure_printed_after_the_sync": [
     "$7,200",
     "$2,400",
     "$250",
     "$1,100",
     "$7,200",
     "$2,300",
     "$250",
     "$698"
    ],
    "figure_same_after_the_sync": true,
    "whole_screen_same_after_the_sync": true
   },
   "drawing": {
    "file": "MoneyKeel/documents/cashflow/moneykeel_pres_mock_cash-flow_v01.html",
    "phones_read": "as the match test holds it (the drawn phone with each dated row and kept item applied by name)",
    "phones_that_hold_this_screen": [
     1,
     2
    ],
    "the_rendered_line": "ACTUAL · SO FAR",
    "drawn_on_those_phones": [
     {
      "phone": 1,
      "line": 32,
      "text": "Actual · so far"
     },
     {
      "phone": 2,
      "line": 24,
      "text": "Actual · so far"
     }
    ],
    "matched": "the whole rendered line, word for word",
    "drawn_elsewhere_on_the_drawing": [],
    "design_record_rows": [
     "Cash flow"
    ]
   },
   "match_tests": [
    {
     "file": "src/screens/__tests__/cashflow_matches_v01.test.tsx",
     "test": "A · This month, with data — Planned +$350 and Actual so far +$900, every row deducted, figure for figure",
     "kind": "test",
     "phones": [
      1
     ],
     "result": "passed",
     "lines": "55–59",
     "holds_the_phone_with_the_line": true
    },
    {
     "file": "src/screens/__tests__/cashflow_matches_v01.test.tsx",
     "test": "B · This month, a fresh account — no budget, so no planned surplus and no guess; Actual so far +$3,000",
     "kind": "test",
     "phones": [
      2
     ],
     "result": "passed",
     "lines": "61–65",
     "holds_the_phone_with_the_line": true
    }
   ]
  },
  "decisions": [
   "DEC-0200",
   "DEC-8387",
   "DEC-8771"
  ],
  "our_tests": [
   {
    "file": "src/screens/__tests__/outside_cashflow_openai_screens.test.tsx",
    "test": "MK-CF-M-054 each line of what has happened so far › T6 · reviewer FAIL (evidence_gap) · EVIDENCE GAP · what holds",
    "result": "passed",
    "what_it_checks": "the line beside the figure is on the rendered screen, and its drawing and match test exist"
   }
  ],
  "status": "SETTLED BY OUR TESTS — WORDS AND FIGURES",
  "status_reason": "the line is drawn on phone 1, 2 (the whole rendered line, word for word), and every test that holds that phone word for word and figure for figure, in the drawing's own household, passes at this build: A · This month, with data — Planned +$350 and Actual so far +$900, every row deducted, figure for figure; B · This month, a fresh account — no budget, so no planned surplus and no guess; Actual so far +$3,000. Appearance (colour, size, spacing) is not tested here."
 }
]
```

## The renders — each screen as it rendered, with the store before and after

Every line in order (`[icon]` is an icon); every figure printed under its identifier; every value the person entered, before the screen opened and after; and the same household arriving by a cloud sync.

```json
{
 "CF": {
  "screen": "CashFlowScreen",
  "day": "2026-09-28",
  "taps": "none — the screen as it opens",
  "screen_parameters": {},
  "how_the_measurer_rendered_it": "shoot('cashflow', H_CF, '2026-09-28')",
  "stored_before_opening": {
   "assetAccounts": [
    {
     "asset_id": "a1",
     "label": "Checking",
     "kind": "checking",
     "tax_bucket": "TAXABLE",
     "balance": 5000,
     "asset_class": "cash"
    }
   ],
   "liabilities": [
    {
     "debt_id": "d1",
     "label": "Mortgage",
     "debt_type": "MORTGAGE",
     "remaining_balance": 228000,
     "interest_rate_apr": 0.0625,
     "minimum_monthly_payment": 2400,
     "payment_type": "installment"
    },
    {
     "debt_id": "d2",
     "label": "Car loan",
     "debt_type": "AUTO",
     "remaining_balance": 14000,
     "interest_rate_apr": 0.069,
     "minimum_monthly_payment": 250,
     "payment_type": "installment"
    }
   ],
   "transactions": [],
   "expenses": [
    {
     "id": "e1",
     "amount": 2300,
     "category": "Rent / Mortgage",
     "store": "Rent",
     "date": "2026-09-01",
     "createdAt": "2026-09-01"
    },
    {
     "id": "e2",
     "amount": 512,
     "category": "Groceries",
     "store": "Grocer",
     "date": "2026-09-07",
     "createdAt": "2026-09-07"
    },
    {
     "id": "e3",
     "amount": 186,
     "category": "Eating out",
     "store": "Diner",
     "date": "2026-09-12",
     "createdAt": "2026-09-12"
    },
    {
     "id": "e4",
     "amount": 250,
     "category": "Debt payment",
     "store": "Car loan",
     "date": "2026-09-12",
     "createdAt": "2026-09-12"
    }
   ],
   "onboardingProfile": {
    "status": "employed",
    "incomeSources": [
     "employment"
    ],
    "birthYear": "1975",
    "baseSalary": "7200",
    "salaryMode": "takehome",
    "salaryFreq": "monthly",
    "taxMode": "manual",
    "manualTaxRate": "0",
    "monthlySpending": "3400",
    "spendCats": [
     {
      "id": "rent",
      "label": "Rent / Mortgage",
      "amount": 2300,
      "bucket": "fixed",
      "tier": "need"
     },
     {
      "id": "groceries",
      "label": "Groceries",
      "amount": 700,
      "bucket": "flexible",
      "tier": "need"
     },
     {
      "id": "dining",
      "label": "Eating out",
      "amount": 400,
      "bucket": "flexible",
      "tier": "flex"
     }
    ]
   },
   "incomes": [],
   "retirementAssumptions": {
    "commitments": [
     {
      "label": "Emergency fund",
      "monthlyAmount": 300
     }
    ]
   }
  },
  "other_stored_values_the_household_sets": {
   "nwSetupChoice": "self"
  },
  "stored_after": {
   "assetAccounts": "the same as before",
   "liabilities": "the same as before",
   "transactions": "the same as before",
   "expenses": "the same as before",
   "onboardingProfile": "the same as before",
   "incomes": "the same as before",
   "retirementAssumptions": "the same as before"
  },
  "any_stored_value_changed_by_opening": [],
  "lines": [
   "001  Cash flow",
   "002  September 2026",
   "003  ‹",
   "004  September 2026",
   "005  ›",
   "006  This month",
   "007  Income",
   "008  Expenses",
   "009  Debts",
   "010  PLANNED · SEPTEMBER",
   "011  +$3,450",
   "012  Inflow (income (take-home))",
   "013  after tax and 401(k)",
   "014  $7,200",
   "015  Mortgage",
   "016  DEBT",
   "017  −$2,400",
   "018  Car loan",
   "019  DEBT",
   "020  −$250",
   "021  Expenses",
   "022  your budget",
   "023  −$1,100",
   "024  Your Rent / Mortgage budget line is not counted here: your mortgage, Mortgage, is in Debts and is counted from there. Place it on your home in Net worth, so we know they are the same.",
   "025  = Planned surplus",
   "026  +$3,450",
   "027  Emergency fund · from your Plan",
   "028  −$300",
   "029  Surplus after your budget",
   "030  +$3,150",
   "031  ACTUAL · SO FAR",
   "032  +$3,952",
   "033  Actual inflow (income (take-home))",
   "034  $7,200",
   "035  Mortgage",
   "036  PAID",
   "037  −$2,300",
   "038  Car loan",
   "039  PAID",
   "040  −$250",
   "041  Expenses entered by hand",
   "042  −$698",
   "043  = Actual surplus so far",
   "044  +$3,952",
   "045  YOUR FUTURE PAYCHECK",
   "046  PROJECTION — an estimate, not a promise",
   "047  At 65 (ours until you change it): ~$10/month",
   "048  In today’s dollars · assumes a 0.50%/year return and 2.50%/year inflation",
   "049  Draw from savings",
   "050  ~$10",
   "051  Based on your plan’s 0% odds of lasting to age 90 · see Plan ›",
   "052  ＋ Expense"
  ],
  "figures_printed_by_identifier": [
   "MK-CF-M-002  $3,450",
   "MK-CF-M-002  $3,450",
   "MK-CF-M-002  $3,450",
   "MK-CF-M-021  $300",
   "MK-CF-M-020  $3,150",
   "MK-CF-M-003  $3,952",
   "MK-CF-M-003  $3,952",
   "MK-CF-M-003  $3,952",
   "MK-CF-M-022  $10",
   "MK-CF-M-082  0.50%/year",
   "MK-CF-M-083  2.50%",
   "MK-CF-M-055  $10",
   "MK-CF-M-004  $7,200",
   "MK-CF-M-004  $2,400",
   "MK-CF-M-004  $250",
   "MK-CF-M-004  $1,100",
   "MK-CF-M-004  $7,200",
   "MK-CF-M-004  $2,300",
   "MK-CF-M-004  $250",
   "MK-CF-M-004  $698",
   "MK-CF-M-070  $5,000"
  ],
  "after_a_cloud_sync": {
   "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
   "entered_unchanged": {
    "assetAccounts": true,
    "liabilities": true,
    "transactions": true,
    "expenses": true,
    "onboardingProfile": false,
    "incomes": true,
    "retirementAssumptions": true
   },
   "figures_printed_by_identifier": [
    "MK-CF-M-002  $3,450",
    "MK-CF-M-002  $3,450",
    "MK-CF-M-002  $3,450",
    "MK-CF-M-021  $300",
    "MK-CF-M-020  $3,150",
    "MK-CF-M-003  $3,952",
    "MK-CF-M-003  $3,952",
    "MK-CF-M-003  $3,952",
    "MK-CF-M-022  $10",
    "MK-CF-M-082  0.50%/year",
    "MK-CF-M-083  2.50%",
    "MK-CF-M-055  $10",
    "MK-CF-M-004  $7,200",
    "MK-CF-M-004  $2,400",
    "MK-CF-M-004  $250",
    "MK-CF-M-004  $1,100",
    "MK-CF-M-004  $7,200",
    "MK-CF-M-004  $2,300",
    "MK-CF-M-004  $250",
    "MK-CF-M-004  $698",
    "MK-CF-M-070  $5,000"
   ],
   "whole_screen_the_same": true
  }
 },
 "CF_OCT": {
  "screen": "CashFlowScreen",
  "day": "2026-09-15",
  "taps": "pressed \"Next month\" 1 time",
  "screen_parameters": {},
  "how_the_measurer_rendered_it": "shoot('cashflow', H_CF, '2026-09-15', {}, next(1))",
  "stored_before_opening": {
   "assetAccounts": [
    {
     "asset_id": "a1",
     "label": "Checking",
     "kind": "checking",
     "tax_bucket": "TAXABLE",
     "balance": 5000,
     "asset_class": "cash"
    }
   ],
   "liabilities": [
    {
     "debt_id": "d1",
     "label": "Mortgage",
     "debt_type": "MORTGAGE",
     "remaining_balance": 228000,
     "interest_rate_apr": 0.0625,
     "minimum_monthly_payment": 2400,
     "payment_type": "installment"
    },
    {
     "debt_id": "d2",
     "label": "Car loan",
     "debt_type": "AUTO",
     "remaining_balance": 14000,
     "interest_rate_apr": 0.069,
     "minimum_monthly_payment": 250,
     "payment_type": "installment"
    }
   ],
   "transactions": [],
   "expenses": [
    {
     "id": "e1",
     "amount": 2300,
     "category": "Rent / Mortgage",
     "store": "Rent",
     "date": "2026-09-01",
     "createdAt": "2026-09-01"
    },
    {
     "id": "e2",
     "amount": 512,
     "category": "Groceries",
     "store": "Grocer",
     "date": "2026-09-07",
     "createdAt": "2026-09-07"
    },
    {
     "id": "e3",
     "amount": 186,
     "category": "Eating out",
     "store": "Diner",
     "date": "2026-09-12",
     "createdAt": "2026-09-12"
    },
    {
     "id": "e4",
     "amount": 250,
     "category": "Debt payment",
     "store": "Car loan",
     "date": "2026-09-12",
     "createdAt": "2026-09-12"
    }
   ],
   "onboardingProfile": {
    "status": "employed",
    "incomeSources": [
     "employment"
    ],
    "birthYear": "1975",
    "baseSalary": "7200",
    "salaryMode": "takehome",
    "salaryFreq": "monthly",
    "taxMode": "manual",
    "manualTaxRate": "0",
    "monthlySpending": "3400",
    "spendCats": [
     {
      "id": "rent",
      "label": "Rent / Mortgage",
      "amount": 2300,
      "bucket": "fixed",
      "tier": "need"
     },
     {
      "id": "groceries",
      "label": "Groceries",
      "amount": 700,
      "bucket": "flexible",
      "tier": "need"
     },
     {
      "id": "dining",
      "label": "Eating out",
      "amount": 400,
      "bucket": "flexible",
      "tier": "flex"
     }
    ]
   },
   "incomes": [],
   "retirementAssumptions": {
    "commitments": [
     {
      "label": "Emergency fund",
      "monthlyAmount": 300
     }
    ]
   }
  },
  "other_stored_values_the_household_sets": {
   "nwSetupChoice": "self"
  },
  "stored_after": {
   "assetAccounts": "the same as before",
   "liabilities": "the same as before",
   "transactions": "the same as before",
   "expenses": "the same as before",
   "onboardingProfile": "the same as before",
   "incomes": "the same as before",
   "retirementAssumptions": "the same as before"
  },
  "any_stored_value_changed_by_opening": [],
  "lines": [
   "001  Cash flow",
   "002  September 2026",
   "003  ‹",
   "004  October 2026 — planned",
   "005  ›",
   "006  today ›",
   "007  This month",
   "008  Income",
   "009  Expenses",
   "010  Debts",
   "011  OCTOBER 2026 — THE PLAN (AN ESTIMATE)",
   "012  Planned inflow",
   "013  $7,200",
   "014  Planned outflow (expenses + debt)",
   "015  $3,750",
   "016  = Planned surplus",
   "017  +$3,450",
   "018  Every figure is planned — an estimate, never dressed as fact.",
   "019  ＋ Expense"
  ],
  "figures_printed_by_identifier": [
   "MK-CF-M-047  $7,200",
   "MK-CF-M-048  $3,750",
   "MK-CF-M-049  $3,450",
   "MK-CF-M-070  $5,000"
  ],
  "after_a_cloud_sync": {
   "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
   "entered_unchanged": {
    "assetAccounts": true,
    "liabilities": true,
    "transactions": true,
    "expenses": true,
    "onboardingProfile": false,
    "incomes": true,
    "retirementAssumptions": true
   },
   "figures_printed_by_identifier": [
    "MK-CF-M-047  $7,200",
    "MK-CF-M-048  $3,750",
    "MK-CF-M-049  $3,450",
    "MK-CF-M-070  $5,000"
   ],
   "whole_screen_the_same": true
  }
 },
 "HOME": {
  "screen": "HomeScreen",
  "day": "2026-09-28",
  "taps": "none — the screen as it opens",
  "screen_parameters": {},
  "how_the_measurer_rendered_it": "shoot('home', H_CF, '2026-09-28')",
  "stored_before_opening": {
   "assetAccounts": [
    {
     "asset_id": "a1",
     "label": "Checking",
     "kind": "checking",
     "tax_bucket": "TAXABLE",
     "balance": 5000,
     "asset_class": "cash"
    }
   ],
   "liabilities": [
    {
     "debt_id": "d1",
     "label": "Mortgage",
     "debt_type": "MORTGAGE",
     "remaining_balance": 228000,
     "interest_rate_apr": 0.0625,
     "minimum_monthly_payment": 2400,
     "payment_type": "installment"
    },
    {
     "debt_id": "d2",
     "label": "Car loan",
     "debt_type": "AUTO",
     "remaining_balance": 14000,
     "interest_rate_apr": 0.069,
     "minimum_monthly_payment": 250,
     "payment_type": "installment"
    }
   ],
   "transactions": [],
   "expenses": [
    {
     "id": "e1",
     "amount": 2300,
     "category": "Rent / Mortgage",
     "store": "Rent",
     "date": "2026-09-01",
     "createdAt": "2026-09-01"
    },
    {
     "id": "e2",
     "amount": 512,
     "category": "Groceries",
     "store": "Grocer",
     "date": "2026-09-07",
     "createdAt": "2026-09-07"
    },
    {
     "id": "e3",
     "amount": 186,
     "category": "Eating out",
     "store": "Diner",
     "date": "2026-09-12",
     "createdAt": "2026-09-12"
    },
    {
     "id": "e4",
     "amount": 250,
     "category": "Debt payment",
     "store": "Car loan",
     "date": "2026-09-12",
     "createdAt": "2026-09-12"
    }
   ],
   "onboardingProfile": {
    "status": "employed",
    "incomeSources": [
     "employment"
    ],
    "birthYear": "1975",
    "baseSalary": "7200",
    "salaryMode": "takehome",
    "salaryFreq": "monthly",
    "taxMode": "manual",
    "manualTaxRate": "0",
    "monthlySpending": "3400",
    "spendCats": [
     {
      "id": "rent",
      "label": "Rent / Mortgage",
      "amount": 2300,
      "bucket": "fixed",
      "tier": "need"
     },
     {
      "id": "groceries",
      "label": "Groceries",
      "amount": 700,
      "bucket": "flexible",
      "tier": "need"
     },
     {
      "id": "dining",
      "label": "Eating out",
      "amount": 400,
      "bucket": "flexible",
      "tier": "flex"
     }
    ]
   },
   "incomes": [],
   "retirementAssumptions": {
    "commitments": [
     {
      "label": "Emergency fund",
      "monthlyAmount": 300
     }
    ]
   }
  },
  "other_stored_values_the_household_sets": {
   "nwSetupChoice": "self"
  },
  "stored_after": {
   "assetAccounts": "the same as before",
   "liabilities": "the same as before",
   "transactions": "the same as before",
   "expenses": "the same as before",
   "onboardingProfile": "the same as before",
   "incomes": "the same as before",
   "retirementAssumptions": "the same as before"
  },
  "any_stored_value_changed_by_opening": [
   "monthlySnapshots",
   "nwDaily",
   "invDaily",
   "snapshotDays",
   "lastRetireChance",
   "milestoneHighSeen"
  ],
  "lines": [
   "001  Good afternoon",
   "002  there",
   "003  YOUR INVESTMENTS",
   "004  ⓘ",
   "005  $0",
   "006  Nothing entered yet. Add your accounts ›",
   "007  nothing invested yet — connect or add an account to start",
   "008  as of Sep 28",
   "009  See your growth ›",
   "010  Net worth",
   "011  ⓘ",
   "012  −$237,000",
   "013  ›",
   "014  CHIEF OF STAFF — WHAT NEEDS YOU (3)",
   "015  1◆",
   "016  Build your emergency fund",
   "017  Your cash covers about 1.5 months of expenses — most planners' range is 3–6.",
   "018  ›",
   "019  2·",
   "020  Your retirement plan needs attention",
   "021  Only a 0% odds it lasts — adjust savings, age, or expenses in the scenario.",
   "022  ›",
   "023  3·",
   "024  Room left in your 401(k)",
   "025  About $32,500 of this year’s tax-advantaged room looks unused — an estimate from what you entered you contribute, not from your payroll.",
   "026  ›",
   "027  WILL MY MONEY LAST?",
   "028  0% odds of lasting to age 90 — estimate",
   "029  ⓘ",
   "030  See the full picture ›",
   "031  THIS MONTH’S CASH FLOW",
   "032  ✓ On pace",
   "033  45% spent · day 28 of 30",
   "034  Income",
   "035  $7,200",
   "036  Outflow (expenses + debt)",
   "037  $3,248",
   "038  Left",
   "039  $3,952",
   "040  Estimates for guidance only — not financial, investment, or tax advice, and projections aren’t guaranteed. See Settings for the full disclaimer."
  ],
  "figures_printed_by_identifier": [
   "MK-XS-M-002  0% odds of lasting to age 90",
   "MK-CF-M-051  $7,200",
   "MK-CF-M-052  $3,248",
   "MK-CF-M-053  $3,952"
  ],
  "after_a_cloud_sync": {
   "how": "the same household handed to the store's loadFromCloud (what a sync from the cloud does) instead of set directly; then the same screen, day and taps",
   "entered_unchanged": {
    "assetAccounts": true,
    "liabilities": true,
    "transactions": true,
    "expenses": true,
    "onboardingProfile": false,
    "incomes": true,
    "retirementAssumptions": true
   },
   "figures_printed_by_identifier": [
    "MK-XS-M-002  0% odds of lasting to age 90",
    "MK-CF-M-051  $7,200",
    "MK-CF-M-052  $3,248",
    "MK-CF-M-053  $3,952"
   ],
   "whole_screen_the_same": true
  }
 }
}
```

## The design record — which approved design each screen here is built from

Rows of `MoneyKeel/documents/standards/moneykeel_pres_spec_design-each-screen-was-built-from_v01.md`, the one record of which design each screen was built from, as written today.

```json
{
 "Cash flow": "`MoneyKeel/documents/cashflow/moneykeel_pres_mock_cash-flow_v01.html` **frame 1, This month — APPROVED 2026-09-28** (*\"Approved\"*, DEC-0440: the four-tab architecture from v02 with This month and Expenses revised in v07; v02 and v07 are dated and archived). The folder also holds `income-end-to-end_v07`, `look-ahead_v04` and `filing-status-question_v03`, each with a \"What changed from vNN, and why\" block; where the architecture file and a detail file disagree, the detail file wins. **Traced 2026-09-27**; the per-screen rows below were added 2026-10-02 so step 1.a reads one row per screen. **BUILT 2026-10-03, This month only (frames A and B):** compared word for word and rebuilt — a Planned card and an Actual card, every row spelled out; `src/screens/__tests__/cashflow_matches_v01.test.tsx` holds it. Three differences are named in that test: the words under the planned inflow show in both frames, the ＋ Expense button stays, and the future-paycheck card stays (he ruled on its arithmetic on 2026-09-08). **Expenses, Income and Debts (frames C to F) built the same day**, each held word for word by the same test, which lists every named difference (fourteen across the four tabs — the future-paycheck card, the payoff plan with the mortgage comparison he moved here in DEC-0157, and the doors a person needs that the drawing does not draw). **2026-10-24, eight READ THIS FIRST rows (the phones not redrawn):** rows add up to the total printed under them (DEC-7937); the month's take-home is Your base pay's, after the 401(k) (DEC-7938); one-time income has its own choice and lands once (DEC-7940); the budget editor's card is this month's plan (DEC-7939); Log a payment to the cent (DEC-7943); a past or future month's card words, the spoken rows (DEC-7946, DEC-7950); a late entry on a past month's list and the info dot beside its sentence (DEC-7949, DEC-7948); a dated bill on top of the typed budget (DEC-7951). Held by `cashflow_matches_v01.test.tsx`, 7 of 7, and the Cash flow journeys, 14 of 14 and 15 of 15, on 2026-10-24. **2026-10-25/26, 32 dated READ THIS FIRST rows on cash-flow v01 (the phones not redrawn).** By decision: DEC-8355, DEC-8356, DEC-8357, DEC-8358, DEC-8359, DEC-8360, DEC-8361, DEC-8362, DEC-8363, DEC-8364, DEC-8365, DEC-8366, DEC-8367, DEC-8368, DEC-8369, DEC-8370, DEC-8375, DEC-8378, DEC-8379 (CF-MMFIX-A); DEC-8392, DEC-8412, DEC-8413 (the draw sheet, the mortgage comparison, the paycheck's return); DEC-8344, DEC-8455, DEC-8457, DEC-8458, DEC-8459, DEC-8460, DEC-8461, DEC-8462, DEC-8463, DEC-8464, DEC-8422 (FIX-MONTH and NW-MMFIX); DEC-8443, DEC-8449, DEC-8453 (FIX-INCOME-B); the article before the return (CLEANUP-TESTS, 2026-10-26). CF-MMFIX-A wrote its 15 rows of 2026-10-25 after the code, not before (mock-first not kept in order). **The register's September household moved (DEC-8459):** planned surplus $1,150 → $3,450, free after the goal $850 → $3,150, October's outflow $6,050 → $3,750, planned expenses $3,400 → $1,100, actual expenses $2,998 → $698; the outflow, the surplus and Home's $7,200 / $3,248 / $3,952 do not move. **2026-10-27/30, fifteen dated READ THIS FIRST rows on cash-flow v01 (the phones not redrawn), all written before the code:** rows rounded once and totals to the cent, $400.80 (DEC-8922); a mortgage counted once, rows 44 and 56, +$2,950 (DEC-8919); nothing ranked on a rate not entered (DEC-8923); a month before tracking (DEC-8955); the surplus with its sign (DEC-8956); /year (DEC-8957); the budget editor's shares to two decimals (DEC-8958); the paycheck to the cent, bold (DEC-8954); the Debts total line (DEC-8959); the month switcher's sizes (DEC-8960); Log an expense (DEC-8964); every box title on a bar (DEC-8915); the tab bar and the dot (DEC-8927, DEC-8926); the logo row of 2026-10-30 (his DEC-8914), the phones not redrawn. | —"
}
```

## The drawing — `MoneyKeel/documents/cashflow/moneykeel_pres_mock_cash-flow_v01.html`

**READ THIS FIRST — ADDED AFTER THIS MOCKUP · BUILD 54. Each row says whose decision it is: his, in his own words with the day he gave them, or the lead’s, made without asking him under his order of 2026-09-30. (Corrected 2026-10-31: this line said every row was his ruling and approved, which was untrue of the lead’s rows.)** These were ruled after this drawing was approved, during work on Build 54 (the build on TestFlight). They are in the app’s code unless a line says ‘Not built yet’, and reach a phone with the next build cut. The phones below are not redrawn: where a line here and a phone disagree, this line is the design.

Its dated rows, every one, as written on the drawing (83):

```json
[
 {
  "Ruled": "2026-10-04",
  "What changed, against the phones below": "Kept as built though not drawn below: the ‘＋ Expense’ button on every tab; ‘Import a statement ›’ at the foot of Expenses; rows under ‘Show all N’ open in the full list; ‘Your income, all of it — Open ›’ under Income; on Debts, PAYOFF PLAN with the mortgage comparison, each debt’s monthly payment and interest on its line, and ‘+ Add debt account’ under the list.",
  "His words, or where it came from": "“Rest - keep it.”",
  "Record": "DEC-1560 · DEC-0157",
  "State": "In the code"
 },
 {
  "Ruled": "2026-10-04",
  "What changed, against the phones below": "Planned: every debt is taken from Debts (as drawn), and the Rent / Mortgage budget line is not counted when the home’s mortgage is in Debts. Where that happens, This month and Expenses say: ‘Your Rent / Mortgage budget line is not counted here: your home’s mortgage, …, is in Debts and is counted from there.’ Actual: unchanged — a debt counts when its payment is logged.",
  "His words, or where it came from": "“Once user enters mortgage or any debt - the app deduct it directly … Actual expenses - we wait for debt to be paid, and not assume it is paid, similar to mock up.”",
  "Record": "DEC-1923",
  "State": "In the code"
 },
 {
  "Ruled": "2026-10-04",
  "What changed, against the phones below": "Debts: a mortgage says which property it is on.",
  "His words, or where it came from": "“Properties, mortgages, and debt we should ask user to name. … no mortgage without property.”",
  "Record": "DEC-1925",
  "State": "In the code"
 },
 {
  "Ruled": "2026-10-10",
  "What changed, against the phones below": "Every count written in words takes its plural from one list of words and plurals, so it is right for 0, 1 and many — Expenses: ‘Entered by hand · 1 item’, ‘Imported · 12 purchases’; Debts: ‘across 1 debt’.",
  "His words, or where it came from": "“15 - why not go ahead and make a list of words and plurals.”",
  "Record": "DEC-4082",
  "State": "In the code"
 },
 {
  "Ruled": "2026-10-10",
  "What changed, against the phones below": "Cash flow when retired (not drawn below): under DRAW COMES FROM, an account with no tax type gets one line naming it — ‘Brokerage — tax type not stated; counted as taxable until you choose.’ — and a tap opens that account’s editor. The draw-steer sheet says the same. No line when every account has a tax type.",
  "His words, or where it came from": "“…An account with no tax type would be counted as taxable for the plan, with a line naming it: “Brokerage — tax type not stated; counted as taxable until you choose.” … approved”",
  "Record": "DEC-4105",
  "State": "In the code"
 },
 {
  "Ruled": "2026-10-21",
  "What changed, against the phones below": "DRAWING ERROR, every frame — the top bar’s menu button is drawn with semicircle ends (border-radius 19px on a button 30px tall), copied from the code. His ruling of 2026-09-25 is rounded corners, not semicircle ends, for the buttons on every screen: the corner is corrected to 12 , the one corner of a button and of a choice in the app. Its size, colours and words do not change. The round icon buttons at the right of the bar stay circles: a circle has no ends. The phones are not redrawn. Line added 2026-10-21.",
  "His words, or where it came from": "“make the buttons same as all radio buttons across all screens — rounded corners not semicircle ends”",
  "Record": "DEC-0231 · DEC-4529",
  "State": "Drawing corrected by this line — in the code since 2026-10-21"
 },
 {
  "Ruled": "2026-10-23",
  "What changed, against the phones below": "This month, PLANNED (not drawn below): a debt whose monthly payment was never entered keeps its row, and the row reads ‘payment not entered’ where the amount would be. There is then no planned surplus: the band reads —, and under the rows: ‘Car loan’s payment is not entered, so there is no planned surplus — we won’t guess one.’ It read ‘+No budget set — …’ with a budget set, and the debt’s row printed a sentence written for the master file. ACTUAL: unchanged. Home’s THIS MONTH’S CASH FLOW box now prints this tab’s own ACTUAL · SO FAR figures (Income, Outflow (expenses + debt), Left = ‘= Actual surplus so far’). Line added 2026-10-23.",
  "His words, or where it came from": "Not a decision of his: made under his tenet 3 (approved 2026-10-09: ‘Something never entered shows as ‘not entered’ and the reason, never as $0 or a default that looks like an answer.’, DEC-3523) without asking him; found by the outside re-run of Performance (OpenAI), screen check MK-CF-M-002 tenet 3. One word from him reverses it. To reverse: give the debt’s row and the surplus their earlier words.",
  "Record": "DEC-3523 (tenet 3) · DEC-0345",
  "State": "In the code"
 },
 {
  "Ruled": "2026-10-23",
  "What changed, against the phones below": "Expenses (frames C and D), PLANNED EXPENSES: each group is what is planned for this month , the same figure This month’s Expenses row deducts. A once-a-year bill counts in the month it falls, never as a twelfth: with a $700 everyday budget and a $1,200 bill in December, September reads Everyday expenses $700 · = Total $700 and no Once in a while row (it read Once in a while $100 · = Total $800 while This month read Expenses −$700); December reads Once in a while $1,200 · = Total $1,900. A group with nothing planned this month is not drawn. When a budget is set but nothing in it falls this month, the band reads $0 — not ‘—’ and ‘You haven’t set your budget yet’. The words and the layout do not change. The phones are not redrawn. Line added 2026-10-23.",
  "His words, or where it came from": "His rules: big bills that come once get their own list (DEC-0002, 2026-07-19, “cashflow. Approve.”) and his rule that money which comes once counts in its own month, not spread across twelve (DEC-0447); his correction of 2026-09-28 that Expenses is the detail behind This month’s Expenses row, not a second answer. Applied without asking him; one word from him reverses it. To reverse: read the budget’s monthly average on Expenses again.",
  "Record": "DEC-0002 · DEC-0447 · DEC-3523 (tenet 4) · MK-CF-M-001 · MK-CF-M-015",
  "State": "In the code"
 },
 {
  "Ruled": "2026-10-24",
  "What changed, against the phones below": "A past or future month on This month (not drawn below; last drawn in the archived this-month-and-spending v02, ‘MAY — WHAT ACTUALLY HAPPENED’, ‘NOVEMBER — THE PLAN (AN ESTIMATE)’, ‘usual $4,500 + property tax $2,400’). The band names the month once: ‘SEPTEMBER 2026 — WHAT ACTUALLY HAPPENED’, ‘DECEMBER 2026 — THE PLAN (AN ESTIMATE)’; it read ‘SEPTEMBER 2026 — FINAL — WHAT ACTUALLY HAPPENED’ under a switcher already saying ‘— final’. A future month’s outflow names a dated bill only (‘· incl. Car insurance’), never the everyday budget left over or a debt’s monthly payment (it read ‘· incl. Everyday expenses’). ‘Nothing entered yet. Add your bills ›’ shows only when the month plans $0; it showed in every month without a dated bill, a budget entered. Every screen-reader label on the four tabs now says its row in words — ‘hidden’, never the dots. Line added 2026-10-24.",
  "His words, or where it came from": "Not a decision of his: made under tenets 1 and 3 (DEC-3523; Q48 is for a $0 with nothing behind it) without asking him; found by the Cash flow journeys E2E-76, E2E-78 and E2E-80. One word from him reverses it. To reverse: give the band, the outflow’s line and the note their earlier words.",
  "Record": "DEC-3523 (tenets 1, 3) · DEC-0440 · MK-CF-M-048 · MK-CF-M-053",
  "State": "In the code"
 },
 {
  "Ruled": "2026-10-24",
  "What changed, against the phones below": "This month (frames A and B), and everywhere a month is shown as rows over a total — Home’s THIS MONTH’S CASH FLOW box, a past or a future month, and the lists on Expenses: the rows as printed add up to the total printed under them . Each total is rounded to the dollar as before; the rows share it, each rounded down, and the dollars still missing go to the rows with the most cents left over, so no row is more than a dollar from its exact value and a whole-dollar row never moves. A surplus is the inflow printed less the outflow printed. Frame A’s household with a $6.50 coffee: Expenses entered by hand −$507 and ‘= Actual surplus so far +$893’ (it read +$894 under rows that make $893); Home: Income $5,000 · Outflow (expenses + debt) $4,107 · Left $893 (it read Left $894). The words and the layout do not change. The phones are not redrawn. Line added 2026-10-24.",
  "His words, or where it came from": "Not a decision of his: made under tenet 2 (approved 2026-10-09, ‘the rows under a total add up to it’, DEC-3523) and his precision ruling (whole dollars for totals, DEC-0264), by the method the Performance walk already uses; found by the Cash flow journey E2E-69. One word from him reverses it. To reverse: round every row and every total on its own again.",
  "Record": "DEC-3523 (tenet 2) · DEC-0264 · MK-CF-M-002 · MK-CF-M-003 · MK-CF-M-004 · MK-CF-M-051 · MK-CF-M-052 · MK-CF-M-053",
  "State": "In the code"
 },
 {
  "Ruled": "2026-10-24",
  "What changed, against the phones below": "The inflow on This month, ‘THIS MONTH … expected take-home’ on Income, Home’s Income and the Bill calendar’s In are the take-home Your base pay and the Income summary print: after tax and the 401(k) ; a take-home the person typed, as typed; a rate the person gave not laid on rent; interest and dividends that are reinvested not counted as arriving. $9,000 a month with $1,000 into a 401(k), single: $6,976 (it read $7,976 here while Your base pay read $6,976); a take-home typed as $6,200 reads $6,200 (it read $7,200). The words do not change: they already said ‘after tax and 401(k)’. Line added 2026-10-24.",
  "His words, or where it came from": "Not a decision of his: the drawing’s own words (‘after tax and 401(k)’, frame A), his ruling that income before tax is gross less the 401(k) (DEC-0283) and the income drawing’s rule that the take-home someone enters is the take-home (income-end-to-end_v07, rule 5), under tenets 1 and 4; found by the Cash flow journey E2E-71. To reverse: take the tax off the wage and leave the 401(k) in again.",
  "Record": "DEC-0283 · DEC-0440 · DEC-3523 (tenets 1, 4) · MK-CF-M-047 · MK-CF-M-051",
  "State": "In the code"
 },
 {
  "Ruled": "2026-10-24",
  "What changed, against the phones below": "Income (frame 5): ‘Add your income ›’ offers Bonus and One-time income as two choices; it offered ‘Bonus / one-time’, which opened the bonus editor, where a bonus is paid every year, so a one-time $2,000 came back the next September. One-time income opens the ‘Something else’ question (One time, the month it lands); the month is kept with its year, so the money lands once and is not in another year’s taxed income. YOUR SOURCES lists it under its name: ‘Bonus · one-time · lands in September · $2,000 ›’ (it was in THIS MONTH’s figure with no row saying why). Line added 2026-10-24.",
  "His words, or where it came from": "Not a decision of his: his rule that one-time money ‘lands in its own month, rather than being spread across twelve’ (DEC-0447), and the rule under YOUR SOURCES that every stored source is visible (pre-48 audit A3); found by the Cash flow journey E2E-70. To reverse: one choice, ‘Bonus / one-time’, to the bonus editor, and no row for other income.",
  "Record": "DEC-0447 · DEC-3523 (tenets 2, 4) · MK-CF-M-027 · MK-CF-M-047",
  "State": "In the code"
 },
 {
  "Ruled": "2026-10-24",
  "What changed, against the phones below": "The budget editor, ‘Your budget’ (opened by ‘Set your budget’ and by the planned rows; not drawn below): its card is this month’s plan , the figures This month’s PLANNED prints. With nothing set it reads ‘− Expenses (plan) — not set’ and ‘= Planned surplus —’ (it read $0 and $2,350 beside This month’s ‘— not set’); with a $1,200 bill in December, September’s card reads without it (it read $100 a month of it); the Rent / Mortgage line is not counted when the home’s mortgage is in Debts. A screen reader names each box under ‘Monthly limits’ by its category (‘Groceries, monthly limit’); it heard ‘No limit’ fifteen times. Line added 2026-10-24.",
  "His words, or where it came from": "Not a decision of his: made under tenets 3 and 4 (DEC-3523) and his rulings DEC-0002, DEC-0447 and DEC-1923; found by the Cash flow journey E2E-73. To reverse: give the card its own typical month again.",
  "Record": "DEC-3523 (tenets 3, 4) · DEC-0002 · DEC-0447 · DEC-1923 · MK-CF-M-001 · MK-CF-M-002",
  "State": "In the code"
 },
 {
  "Ruled": "2026-10-24",
  "What changed, against the phones below": "Debts (frame 6), ‘Log a payment ›’ (the sheet is not drawn): the amount it offers is the payment to the cent — a $386.42 car payment is offered as 386.42; it was offered as ‘386’, so Log recorded $386 and left the balance 42¢ too high. Line added 2026-10-24.",
  "His words, or where it came from": "Not a decision of his: his precision ruling (an expense at two decimals, DEC-0264) under tenet 1; found by the Cash flow journey E2E-74. To reverse: offer the payment rounded to the dollar again.",
  "Record": "DEC-0264 · DEC-3523 (tenet 1) · MK-NW-M-010",
  "State": "In the code"
 },
 {
  "Ruled": "2026-10-24",
  "What changed, against the phones below": "Expenses, for a past month (not drawn below): an expense dated in that month but entered after the month’s record was saved — a statement imported later — is listed, and says so under its name: ‘Groceries · added after September closed — not in September’s figures’. Under ‘= Actual expenses, all sources’: ‘$150 of it was added after September closed — not in September’s figures.’ The month’s card on This month stays as it was (‘Frozen — past months never change under you.’), so the list and the card never disagree without saying why. Debts: the mortgage comparison’s ‘ⓘ’ sits beside its last sentence rather than at its end, and a screen reader says it as ‘About How we calculate your odds’. Line added 2026-10-24.",
  "His words, or where it came from": "The lead’s rulings of 2026-10-24 on the Cash flow journeys E2E-76 and E2E-78: keep his frozen rule and say on the row that the figures leave it out; say every info dot in words. Not a decision of his; one word from him reverses it. To reverse: drop the two lines, and put the dot back inside the sentence.",
  "Record": "DEC-3523 (tenets 1, 4) · MK-CF-M-013 · MK-CF-M-052",
  "State": "In the code"
 },
 {
  "Ruled": "2026-10-24",
  "What changed, against the phones below": "Expenses (frames C and D), This month’s Expenses row, Home’s THIS MONTH’S CASH FLOW box and the Bill calendar: the monthly budget the person typed is what is spent every month , and a bill with its own month is added in that month only. With the budget typed as $2,000/month ($1,100 bills & fixed, $900 everyday) and $1,200 of car insurance added for December, every other month reads Bills & fixed $1,100 · Everyday expenses $900 · = Total $2,000, and December $3,200. It read Everyday expenses $1,900 · = Total $1,900 in every month: the typed $2,000 was taken to hold $100/month of the bill, and the $1,100 / $900 split was dropped. Where a figure is the planned expenses for a whole year shown by the month — the emergency fund’s months at your planned spend on Net worth, the retirement draw, sign-up’s cash-flow recap — the bill counts once in the year: 2,000 + 1,200 ÷ 12 = $2,100 (it read $2,000). The must-pay figure is the typed $2,000 (it read $1,900). The words and the layout do not change. The phones are not redrawn. Line added 2026-10-24.",
  "His words, or where it came from": "Not a decision of his: made under his rules DEC-0002 (big bills that come once get their own list, so a bill that lands once a year is not lost inside a monthly average) and DEC-0447 (money that comes once counts in its own month), and tenet 1 (DEC-3523). No ruling of his says a typed budget already holds such a bill. Found by the Cash flow journeys’ test H4. Applied without asking him; one word from him reverses it. To reverse: read the typed budget as holding a twelfth of each dated bill again.",
  "Record": "DEC-0002 · DEC-0447 · DEC-3523 (tenet 1) · B-24 · MK-CF-M-001 · MK-CF-F-221 · MK-CF-F-008 · MK-CF-F-002 · MK-CF-F-009",
  "State": "In the code"
 },
 {
  "Ruled": "2026-10-24",
  "What changed, against the phones below": "This month (frames A and B), Expenses (frames C and D) and Home’s due-soon reminder: a debt counts in a month only if a payment falls in that month — from its first payment to its payoff, and a balance due in full once, in the month it is due, at its balance — the rule a later month’s plan card and the Bill calendar already read. With a $7,200 take-home, a $3,400 budget, the $2,400 mortgage, a $250 car loan whose first payment is Oct 28, a $300 loan paid off in August and a $1,000 tax bill due in full Sep 20, September’s PLANNED reads Mortgage −$2,400 · Expenses −$3,400 · Tax bill — due in full −$1,000 · = Planned surplus +$400, the figure the Bill calendar’s September holds (it read +$850, with the car loan and the paid-off loan and without the tax bill). The car loan is not under ACTUAL as ‘due 28th · $0’ in September; MONTHLY RECURRING EXPENSES reads Mortgage $2,400 (it read $2,650); the tax bill is on the BIG-TICKET RADAR at $1,000; one debt there reads ‘Your mortgage never appears here. It is the same every month, …’ (it read ‘never appear … They are’). October’s plan card is unchanged: $1,150. The phones are not redrawn. Line added 2026-10-24.",
  "His words, or where it came from": "Not a decision of his: made under tenets 1 and 4 (DEC-3523) and his rule that every debt is taken from Debts (DEC-1923); found by PF-TOOLS while it settled MK-CF-M-001 to 004. Applied without asking him; one word from him reverses it. To reverse: count every debt’s payment in this month again, whatever its dates.",
  "Record": "DEC-3523 (tenets 1, 4) · DEC-1923 · MK-CF-M-002 · MK-CF-M-004 · MK-CF-M-016 · MK-CF-M-049 · MK-CF-F-156 · MK-CF-F-005 · MK-XS-F-004",
  "State": "In the code"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "Debts (frame 4), not a drawn state: a debt whose monthly payment was never entered — say a mortgage added with its property and its payment left blank. Its row reads ‘payment not entered’ where ‘$X/month min’ stands; under the total a line names it in Net worth’s words: ‘Lake house mortgage · payment not entered, so it is not included. Enter it to include.’; and the payoff plan gives no debt-free date: ‘Lake house mortgage’s payment is not entered, so there is no payoff date — we won’t guess one.’ It read ‘never at this rate’ and ‘At this payment your balance grows faster than you pay it down’, as if the payment were $0, and the row printed a sentence about debts due in full before ‘/month min’. The total owed counts its balance; the monthly payments leave its payment out.",
  "His words, or where it came from": "Tenet 3, approved 2026-10-09 (DEC-3523): Unknown is not zero. Something never entered shows as ‘not entered’ and the reason, never as $0 or a default that looks like an answer. Found by the Cash flow measurer on 2026-10-25. The refusal is This month’s, in the same words (2026-10-23). The lead’s decision, made without asking him; to reverse it, count a payment never entered as $0 again.",
  "Record": "DEC-3523 · MK-CF-M-071 · MK-CF-M-073 · MK-CF-M-058",
  "State": "In the code since 2026-10-25"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "The budget editor, ‘Your budget’ (opened by ‘Set your budget’ and by the planned rows; not drawn below): under each bucket the rows are that bucket’s own expenses this month and add up to it , and the buckets’ plans add up to ‘− Expenses (plan)’. An expense dated the 1st stays in its month in a US time zone, and a debt payment is not an expense row (it is under Debt this month). Frame C’s household: Fixed $22 / $200 · Utilities $22 / $200; Flexible $1,678 / $1,800 · Other $1,075 / $700 · Grocery $418 / $900 · Gas $185 / $200. The same expenses with the budget typed as $1,100 bills & fixed and $900 everyday: Fixed $22 / $1,100 · Utilities $22; Flexible $1,678 / $900 · Other $1,075 · Grocery $418 · Gas $185 — it read Fixed $22 over Debt payment $400 · Utilities $22, and Flexible $1,678 over Other $653 · Grocery $418 · Gas $185: sixteen purchases dated Aug 1 were read as Jul 31. The card says ‘Your budget’ once, under the editor’s own title, and ‘= Planned surplus +$350’ as This month prints it (it read $350). With no budget set there is no bar and no ‘$0 spent so far · $0 left · of $0 plan’. Line added 2026-10-25.",
  "His words, or where it came from": "Not a decision of his: made without asking him, as his order of 2026-09-30 says; found by the Cash flow drawing match (MM-CF, 2026-10-24) and built by CF-MMFIX-A. One word from him reverses it. Made under tenets 2 and 3 (DEC-3523) and this drawing’s rule 6, ‘Nothing is guessed. No plan set → ‘not set’, never $0 dressed as an answer.’ (CF-20, CF-21, CF-22). To reverse: read the rows from the categories’ own sums again, and print the bar and its two lines with no budget.",
  "Record": "DEC-3523 (tenets 2, 3) · MK-CF-F-014 · MK-CF-F-221 · MK-CF-M-001 · MK-CF-M-002 · MK-CF-M-013 · MK-CF-M-015",
  "State": "In the code since 2026-10-25"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "Every tab, Home’s THIS MONTH’S CASH FLOW box and the budget editor read the day of an expense or an income where the person is . A day picked or typed (‘2026-08-01’) is that day: the budget editor and the Expenses screen read it as Jul 31 in a US time zone, and the Expenses screen saved an edited Aug 1 expense back as Jul 31. A purchase an older build stamped as an instant is the day it was on the person’s clock: 6:30pm on Aug 31 in California is August’s (it was filed under September). The Expenses screen saves the day and time as typed, and a repeating bill or income lands on its own day (one due on a calendar day landed the evening before). The words and the layout do not change. Line added 2026-10-25.",
  "His words, or where it came from": "Not a decision of his: made without asking him, as his order of 2026-09-30 says; found by the Cash flow drawing match (MM-CF, 2026-10-24) and built by CF-MMFIX-A. One word from him reverses it. Made under tenets 1 and 4 (DEC-3523) (CF-21, the whole class: twelve readers in nine files). To reverse: read each date as a moment in London again.",
  "Record": "DEC-3523 (tenets 1, 4) · MK-CF-F-148 · MK-CF-F-014 · MK-CF-F-212 · MK-CF-F-220 · MK-CF-F-189 · MK-XS-F-176 · MK-XS-F-177",
  "State": "In the code since 2026-10-25"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "Expenses (frame C), PLANNED EXPENSES: the budget is listed the way it was entered, as frame C draws it — each category given an amount, in the order entered, then what is left of the monthly total as Other: Gas $200 · Grocery $900 · Utilities $200 · Other $700 · = Total $2,000 (it read Bills & fixed $200 · Everyday expenses $1,800). A once-a-year category is a row in its own month only: with Groceries $700 and Car insurance $1,200 in December, September reads Groceries $700 · = Total $700 and December Groceries $700 · Car insurance $1,200 · = Total $1,900. For a budget entered by category this line replaces the group names in the lines of 2026-10-23 and 2026-10-24 above (Everyday expenses, Once in a while); a budget typed only as bills & fixed and everyday expenses still reads Bills & fixed · Everyday expenses, as they say. The total does not change: it is This month’s Expenses row. Line added 2026-10-25.",
  "His words, or where it came from": "Not a decision of his: made without asking him, as his order of 2026-09-30 says; found by the Cash flow drawing match (MM-CF, 2026-10-24) and built by CF-MMFIX-A. One word from him reverses it. Made under this drawing’s frame C (DEC-0440) and his rules DEC-0002 and DEC-0447; no ruling of his names the groups (CF-09). To reverse: list the budget’s three groups again.",
  "Record": "DEC-0440 · DEC-0002 · DEC-0447 · MK-CF-M-001 · MK-CF-M-015 · MK-CF-F-227",
  "State": "In the code since 2026-10-25"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "This month (frame B) and Expenses (frame D) — an account with no budget set: no ‘after tax and 401(k)’ under the inflow and no ‘same every month’ under the recurring debts, as drawn. With a budget set (frames A and C) both print, as drawn. Line added 2026-10-25.",
  "His words, or where it came from": "Not a decision of his: made without asking him, as his order of 2026-09-30 says; found by the Cash flow drawing match (MM-CF, 2026-10-24) and built by CF-MMFIX-A. One word from him reverses it. Made under this drawing’s frames B and D (CF-11). To reverse: print both lines in every state.",
  "Record": "DEC-0440 · MK-CF-F-156",
  "State": "In the code since 2026-10-25"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "Income (frame 5), YOUR SOURCES: every source the household has is listed under the drawing’s names, at $0 or with no value yet — two rentals that cover their costs read ‘Rental income · 2 properties · $0 ›’, and RSU grants with no value entered ‘Equity comp · RSU grants · — ›’ (both were listed only once worth more than $0, as ‘Rental property · net’ and ‘Stock vesting (equity)’). DRAWING ERROR: the grey line under ‘Add your income ›’ — ‘opens the steady-or-varies pop-up — variable earners fine-tune month by month’ — is set in this drawing’s own note style and describes a pop-up that became the Your base pay screen on 2026-08-27; it is not printed. Line added 2026-10-25.",
  "His words, or where it came from": "Not a decision of his: made without asking him, as his order of 2026-09-30 says; found by the Cash flow drawing match (MM-CF, 2026-10-24) and built by CF-MMFIX-A. One word from him reverses it. Made under this drawing’s frame 5 and tenet 1 (DEC-3523) (CF-12). To reverse: list a source only once it is worth more than $0, under its old names.",
  "Record": "DEC-0440 · DEC-3523 (tenet 1) · MK-CF-M-009 · MK-CF-M-010",
  "State": "In the code since 2026-10-25"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "A person who has entered nothing yet (not drawn below). Each section shows its figure, says why, and offers ONE door: This month — the two set-up steps sit under a quiet grey label, ‘SET UP YOUR MONTH — 2 STEPS’ (it was a dark-green bar with no total); Income — THIS MONTH $0, then ‘Nothing entered yet. Add your income ›’ once, which opens the same chooser (the door was printed twice in a row); Expenses — MONTHLY RECURRING EXPENSES $0 with ‘Nothing entered yet. Add your debts ›’ under it, opening Debts (it had nothing under it); Debts — YOUR DEBT $0 and ‘Nothing entered yet. Add your debts ›’, opening the debt editor (it read ‘across 0 debts · $0/month in payments · ~$0/month interest’, ‘No debts tracked — if that's true, it's all yours. 🎉’, ‘+ Add debt account’ as a second door, and ‘Tap a debt to edit • Hold to delete’ with nothing to tap). Line added 2026-10-25.",
  "His words, or where it came from": "Not a decision of his: made without asking him, as his order of 2026-09-30 says; found by the Cash flow drawing match (MM-CF, 2026-10-24) and built by CF-MMFIX-A. One word from him reverses it. Made under his rulings DEC-0260 and DEC-0431 (a fresh account keeps its shape, the figure reads $0, ‘Nothing entered yet.’ says why, and the door sits beneath) and tenet 3 (DEC-3523) (CF-16 to CF-19). To reverse: give the four tabs their earlier first-day words.",
  "Record": "DEC-0260 · DEC-0431 · DEC-3523 (tenet 3) · MK-CF-M-037",
  "State": "In the code since 2026-10-25"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "Debts (frame 6): each debt is a row in one card, as drawn, with no icon before its name; its line reads ‘· ’ with the space; a time left is said for a loan paid in fixed payments only — a card’s minimum floats with its balance, so the Visa reads ‘22.90% — the costliest · $110/month min · ~$61/month interest’ (it added ‘· 3 years left’) and the car loan ‘6.40% · 3 years left · $300/month min · ~$52/month interest’. A mortgage names the property it is on — ‘5.00% · on Lake house · 15 years left · …’ — and one on no property reads, in amber, Net worth’s own sentence: ‘Your mortgage “Chase” is not on a property. A mortgage is always on a property — open it and say which one.’ (the line of 2026-10-04 above said this was in the code; it was not on this tab). PROGRESS draws its bar, filled to the share paid down: 4,100 ÷ 17,100 = 24%. Line added 2026-10-25.",
  "His words, or where it came from": "Not a decision of his: made without asking him, as his order of 2026-09-30 says; found by the Cash flow drawing match (MM-CF, 2026-10-24) and built by CF-MMFIX-A. One word from him reverses it. Made under this drawing’s frame 6 (DEC-0440) and his rule DEC-1925, “Properties, mortgages, and debt we should ask user to name. … no mortgage without property.” (CF-03, CF-05, CF-06, CF-07, CF-23). To reverse: give each debt its own card and icon again, and say a card’s time left.",
  "Record": "DEC-0440 · DEC-1925 · MK-CF-O-018 · MK-NW-F-106 · MK-CF-M-074 · MK-CF-M-075",
  "State": "In the code since 2026-10-25"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "This month’s inflow, the Income tab’s THIS MONTH, a later month’s Planned inflow and Home’s Income wear ≈ when the take-home is the app’s calculation, as Your base pay prints it: $8,000 a month with $1,000 into a 401(k), single, reads ‘≈$6,196’ (it read $6,196 beside the source line’s ‘≈ $6,196’). A take-home the person typed has none: ‘$5,000’. The mark is written one way, ‘≈$6,196’, with no space. Line added 2026-10-25.",
  "His words, or where it came from": "Not a decision of his: made without asking him, as his order of 2026-09-30 says; found by the Cash flow drawing match (MM-CF, 2026-10-24) and built by CF-MMFIX-A. One word from him reverses it. Made under the income drawing’s rule 9 (income-end-to-end_v07: ‘Every estimate is prefixed ≈’) and tenet 1 (DEC-3523) (CF-24). To reverse: print the take-home without ≈ on these four.",
  "Record": "DEC-3523 (tenet 1) · MK-CF-M-047 · MK-CF-M-051 · MK-CF-M-031",
  "State": "In the code since 2026-10-25"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "Appearance, every frame, built to the drawing: each card runs edge to edge with square corners, and every band total sits on the rows’ one right edge (it sat 12 points left of them); the Income and Debts sections are named by quiet grey labels — THIS MONTH, YOUR SOURCES, RECEIVED THIS MONTH, YOUR DEBT, YOUR DEBTS, PROGRESS (they were dark-green bars with no total); the IMPORTED tag is grey; ‘pay first’ has no fill; ‘Show all …’ is dark green at 800; ‘Log a payment ›’ is bold; a row’s figure is bold (700) and a total heavier (800); the date under the title is the drawing’s lighter grey. DRAWING ERROR: the sub-tab chips are drawn with square corners; a choice’s corner is 12 (DEC-0231). DRAWING ERROR: the type sizes are off the app’s one scale (13.5, 12.5, 12, 11.5, 10.5, 9); they are built at its steps — rows and every money figure 15, totals bold (DEC-0093), sub-lines, bands and tags 11, sub-tabs, empty-state lines and the date 13. Line added 2026-10-25.",
  "His words, or where it came from": "Not a decision of his: made without asking him, as his order of 2026-09-30 says; found by the Cash flow drawing match (MM-CF, 2026-10-24) and built by CF-MMFIX-A. One word from him reverses it. Made under this drawing (DEC-0440), his rulings DEC-0093 (every money figure one size, totals bold, one right edge) and DEC-0231, and the screen standard 2.3 (a group with no total is a quiet label) (CF-01, CF-02, CF-13, CF-14, CF-15). To reverse: give the cards their rounded corners and the bands their earlier padding.",
  "Record": "DEC-0440 · DEC-0093 · DEC-0231",
  "State": "In the code since 2026-10-25"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "DRAWING ERRORS, kept as built: Debts (frame 6) reads ‘across 2 debts · $410/month in payments’ — $110 for the Visa and $300 for the car loan (the drawn $310 leaves $10 for the Visa). An expense row and a payment received print to the cent — ‘$100.00’, ‘+$3,100.00’ (his precision ruling, an expense at two decimals, DEC-0264); totals stay whole dollars. The radar row for a connected card (frame C’s first radar row) cannot occur: no card can be connected yet, so it is not printed, and rule 3 below still holds. Line added 2026-10-25.",
  "His words, or where it came from": "Not a decision of his: made without asking him, as his order of 2026-09-30 says; found by the Cash flow drawing match (MM-CF, 2026-10-24) and built by CF-MMFIX-A. One word from him reverses it. The app is right under DEC-0264 and tenet 1 (DEC-3523) (CF-04, CF-08, CF-10). To reverse: nothing to undo in the app; the phones are not redrawn.",
  "Record": "DEC-0264 · DEC-3523 (tenet 1) · DEC-4529 · MK-CF-M-014 · MK-CF-M-012 · MK-CF-M-071",
  "State": "In the code since 2026-10-25"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "Debts, PAYOFF PLAN, the mortgage comparison (not drawn below; kept by DEC-0157): after federal tax when the person’s federal tax bracket is known — the bracket the Income summary shows. 4.10% mortgage, 4.30% Treasury, 24% bracket, $173,111 owed: ‘Your mortgage costs 4.1%. A ten-year Treasury pays 4.3% today — 3.27% after your 24% federal tax bracket.’ then ‘So a dollar into your mortgage saves you more than the same dollar would earn sitting in Treasuries — about $1,440/year at your balance.’ It read ‘They are close enough that neither choice is clearly better …’ (−0.20 points before tax). The last sentence’s second half reads ‘The Treasury is shown after federal tax (it pays no state tax), the mortgage without any interest deduction.’ With no bracket known (no income entered) the rates line ends ‘… pays 4.3% today, before tax.’ and the second half reads ‘Before tax: a Treasury’s interest is taxed, so after tax it pays less than this.’ Both replace ‘Tax usually widens this gap rather than closing it, but that depends on your own return.’, which is not always so. A payment that never clears the loan , with an extra typed: ‘At this payment the loan never clears, so there is no lifetime figure.’ where the lifetime sentence was silently left out; and a loan that clears after 1,200 months is run to the month it clears ($100,000 at 6% with $501/month: 1,247 months; it stopped at 1,200 with about $20,700 still owed). Line added 2026-10-25.",
  "His words, or where it came from": "Not a decision of his: the lead’s ruling of 2026-10-25 on MK-CF-F-043 (CFR-3) under tenet 7 (DEC-3523) and his DEC-0160 (“what would be the net saving or cost?”); the 1,247 months under tenets 1 and 2. Same sentence shape whichever way it falls (DEC-0161). To reverse: compare before tax again and drop the two halves; the 1,200-month stop is not to be restored.",
  "Record": "DEC-0160 · DEC-0161 · DEC-3523 (tenets 1, 2, 7) · MK-CF-F-043 · MK-CF-F-125 · MK-CF-O-004 (the bracket)",
  "State": "In the code"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "A later month (not drawn below) with no budget set: ‘Planned outflow (expenses + debt) — not set’, then This month’s own sentence and its door — ‘Your debts are here, but you haven’t set your budget. Until you do there is no planned surplus — we won’t guess one.’ · Set your budget — and no planned surplus. October read ‘Planned outflow $2,650 · = Planned surplus $4,550’, the take-home less the debts, as if nothing were spent. Line added 2026-10-25.",
  "His words, or where it came from": "Not a decision of his: made without asking him, as his order of 2026-09-30 says; found by the outside measurement of Cash flow’s screens (OpenAI, measured by CFR-5) and built by CF-MMFIX-A. One word from him reverses it. Made under DEC-7939 and tenet 3 (DEC-3523) (MK-CF-M-049). To reverse: work the later month’s surplus without a budget again.",
  "Record": "DEC-7939 · DEC-3523 (tenet 3) · MK-CF-M-048 · MK-CF-M-049",
  "State": "In the code since 2026-10-25"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "Debts (frame 6): a payment the person set above the minimum reads as theirs — ‘24.00% — the costliest · $300/month · your payment’ (it read ‘$300/month min’) — and the total line adds up what is paid: a $300 card payment and a $250 car loan read ‘across 2 debts · $550/month in payments’ (it read $450, the minimums). A payment set below the minimum reads ‘$200/month min · the payment you set is below it’. Each debt’s interest a month prints under the interest’s own figure. This line does not change the payoff plan’s figures. Line added 2026-10-25.",
  "His words, or where it came from": "Not a decision of his: made without asking him, as his order of 2026-09-30 says; found by the outside measurement of Cash flow’s screens (OpenAI, measured by CFR-5) and built by CF-MMFIX-A. One word from him reverses it. Made under tenets 1 and 5 (DEC-3523) (MK-CF-M-073; F1). To reverse: call every payment the minimum, and add up the minimums.",
  "Record": "DEC-3523 (tenets 1, 5) · MK-CF-M-073 · MK-NW-M-012 · MK-CF-M-057",
  "State": "In the code since 2026-10-25"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "Income (frame 5): ‘Social Security · pension · guaranteed income’ is what arrives now from outside your savings — Social Security, a pension, an annuity, another — and only once you said you receive it: $2,400 of Social Security with $1,500/month taken from a 401(k) reads $2,400/month (it read $3,900 — a withdrawal is a draw on savings), and a Social Security estimate typed in the Plan is not listed as received (it read $2,900/month). Self-employment entered per month reads ‘net · monthly’ (it read ‘net · yearly’ when the question’s ‘Per month’ was left as it was). Line added 2026-10-25.",
  "His words, or where it came from": "Not a decision of his: made without asking him, as his order of 2026-09-30 says; found by the outside measurement of Cash flow’s screens (OpenAI, measured by CFR-5) and built by CF-MMFIX-A. One word from him reverses it. Made under his rule DEC-0244 (the guaranteed income is the outside sources) and tenets 1 and 4 (DEC-3523) (MK-CF-M-011, MK-CF-M-007). To reverse: add the withdrawals back into the row and read a period not stored as yearly.",
  "Record": "DEC-0244 · DEC-3523 (tenets 1, 4) · MK-CF-M-011 · MK-CF-M-007 · MK-CF-F-076",
  "State": "In the code since 2026-10-25"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "This month’s YOUR FUTURE PAYCHECK card (not drawn below) says, under its figure, what its dollars are and what it assumes, from the projection itself: ‘In today’s dollars · assumes a 6.00% return and 2.40% inflation a year’ (the household’s own rates). Cash flow when retired (not drawn below): the card that read ‘SURPLUS — OCT’ reads ‘YOUR PAYCHECK — OCT’, and its pace line ‘Spent $X of your $Y paycheck this month’ — it is what everyday expenses and debt payments are paid from, and Surplus is the one word for what is left after everything out (the canon’s row 26, added the same day). Line added 2026-10-25.",
  "His words, or where it came from": "Not a decision of his: made without asking him, as his order of 2026-09-30 says; found by the outside measurement of Cash flow’s screens (OpenAI, measured by CFR-5) and built by CF-MMFIX-A. One word from him reverses it. Made under his rulings DEC-2164 (the figure is what it buys today) and DEC-0088 (an explanation names every figure it assumes), and his one-term order (DEC-0382; canon row 1) (MK-CF-M-022, MK-CF-M-023, MK-CF-M-078). To reverse: drop the line, and call the retired card a surplus again.",
  "Record": "DEC-2164 · DEC-0088 · MK-CF-M-022 · MK-CF-M-023 · MK-CF-M-078",
  "State": "In the code since 2026-10-25"
 },
 {
  "Ruled": "2026-10-26",
  "What changed, against the phones below": "YOUR FUTURE PAYCHECK’s line of 2026-10-25 (not drawn below): the ‘a’ or ‘an’ before the return is chosen by the app’s one article rule, so an 8.00% return reads ‘assumes an 8.00% return and 2.40% inflation a year’ (it read ‘assumes a 8.00% return’). A 6.00% return reads as the line above says. Line added 2026-10-26.",
  "His words, or where it came from": "Not a decision of his: made without asking him, as his order of 2026-09-30 says; built by CLEANUP-TESTS, held by the article guard (src/domain/_shared/article.test.ts). Made under the article rule (DEC-7306) and the one list of words (DEC-4082). One word from him reverses it. To reverse: type ‘a’ before the return again.",
  "Record": "DEC-7306 · DEC-4082 · MK-CF-M-022",
  "State": "In the code since 2026-10-26"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "The budget editor with no budget set: a bucket reads ‘Fixed $2,300 · no limit’, as its categories do (it read ‘$2,300 / $0’, a limit nobody set). Line added 2026-10-25.",
  "His words, or where it came from": "Not a decision of his: made without asking him, as his order of 2026-09-30 says; found by the outside measurement of Cash flow’s screens (OpenAI, measured by CFR-5) and built by CF-MMFIX-A. One word from him reverses it. Made under tenet 3 (DEC-3523) (F5). To reverse: print the bucket’s $0 plan again.",
  "Record": "DEC-3523 (tenet 3) · MK-CF-M-015",
  "State": "In the code since 2026-10-25"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "Where the draw comes from (the draw-order sheet, opened from Cash flow when retired; not drawn): a gain drawn from taxable accounts is taxed stacked on the year’s income, across the 0%, 15% and 20% bands, as the IRS Schedule D worksheet does — single, $48,111.17 of taxable income and a $3,311.43 gain: $1,338.83 at 0% and $1,972.60 at 15%, $295.89 (it read $0, the whole gain at the 0% of the first dollar). The pre-tax money drawn the same year sits under the gains too. The rates line reads ‘Rates used — yours, calculated: 12% on pre-tax draws · on gains, 0% until your taxable income passes $49,450, then 15% · gains are 33% of your taxable holdings’ value.’ (it read ‘· 0% on gains ·’); above the 15% band’s top it reads ‘20% on gains’. The same line then states the growth the money is run on: ‘Growth used: 6.00% a year — the typical return, with nothing set aside for retirement, less 2.50% inflation.’ — the Retirement cockpit’s own return (a return set on the Plan, else the blended benchmark of the retirement accounts, e.g. ‘7.00% a year — the blended benchmark’, else the typical 6%), less the one inflation rate; it ran a flat 5.5% stand-in, never said (the lead’s ruling of 2026-10-25 on the measurer’s second question).",
  "His words, or where it came from": "Not a decision of his: the lead’s, on the outside audit of 2026-10-24 (OpenAI, Cash flow part 16 and the source checks), made without asking him, under tenets 1 and 7 (DEC-3523) and the published rule (IRS Rev. Proc. 2025-32 §4.03; Schedule D Tax Worksheet). One word from him reverses it. To reverse: tax every dollar of gain at the rate of the first.",
  "Record": "DEC-3523 (tenets 1, 7) · MK-CF-F-104 · MK-PL-F-010",
  "State": "In the code"
 },
 {
  "Ruled": "2026-10-26",
  "What changed, against the phones below": "Debts, PAYOFF PLAN (not drawn below; DEC-1560): a plan whose payments do get ahead of the interest but are still owing after a thousand years reads in words, with what is still owed, and never a date — debt-free ‘not within 1,000 years’, total interest ‘—’, and under them ‘Not paid off within 1,000 years at this rate — $X still owed then. Add extra to make progress.’, the Goals tab’s own sentence. ‘never at this rate’ stays for payments that cannot beat the interest. Line added 2026-10-26.",
  "His words, or where it came from": "Not a decision of his: the lead’s rulings of 2026-10-26 on FIX-BILLS’ findings, made without asking him, as his order of 2026-09-30 says; built by CF-MMFIX-A. One word from him reverses it. Made under tenet 1 (DEC-3523) on FIX-BILLS’ payoff walk (MK-CF-F-034). To reverse: print the month the walk stopped as the debt-free date.",
  "Record": "DEC-3523 (tenet 1) · DEC-1560 · MK-CF-M-058 · MK-CF-M-059 · MK-CF-F-034",
  "State": "In the code since 2026-10-26"
 },
 {
  "Ruled": "2026-10-26",
  "What changed, against the phones below": "A month’s dated bills are read one way on every card (datedBillsIn): a later month’s ‘Planned outflow (expenses + debt) · incl. …’ and the retired paycheck card’s ‘− Big bills this month (…)’ name only bills that fall on a date of their own — never the month’s everyday expenses and never a debt: a balance due in full is a debt, counted from Debts, and a later month’s outflow no longer names it (September read ‘· incl. Tax bill — due in full’). The figures do not change. Line added 2026-10-26.",
  "His words, or where it came from": "Not a decision of his: the lead’s rulings of 2026-10-26 on FIX-BILLS’ findings, made without asking him, as his order of 2026-09-30 says; built by CF-MMFIX-A. One word from him reverses it. Made under his rule DEC-0002 (big one-time bills get their own list) and tenet 4 (DEC-3523). To reverse: give each card its own reading of the month’s bills again.",
  "Record": "DEC-0002 · DEC-3523 (tenet 4) · MK-CF-M-048 · MK-CF-M-078 · MK-CF-F-107",
  "State": "In the code since 2026-10-26"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "This month (frames A and B), Expenses (frames C and D), the budget editor and Home’s THIS MONTH’S CASH FLOW box: a debt in Debts is counted once, from Debts, even when the budget also has a line for it . A mortgage in Debts that is on no property yet, beside a Rent / Mortgage budget line, is taken as that line: the line is not counted, and the screen says ‘Your Rent / Mortgage budget line is not counted here: your mortgage, Mortgage, is in Debts and is counted from there. Place it on your home in Net worth, so we know they are the same.’ The budget’s own ‘Debt payment’ line, and a line named as a debt is (‘Car loan’), are not counted either: ‘Your Car loan budget line is not counted here: Car loan is in Debts and is counted from there.’ With a $7,200 take-home, a $3,400 budget ($2,300 of it Rent / Mortgage), a $2,400 mortgage on no property and a $250 car loan, September’s PLANNED reads Mortgage −$2,400 · Car loan −$250 · Expenses −$1,100 · = Planned surplus +$3,450 (it read +$1,150: the mortgage counted twice); a $250 Car loan budget line beside the $250 car loan plans $250 of outflow, not $500. Placing the mortgage on a property that is not the home puts the Rent / Mortgage line back. It moves the figures of the 2026-10-24 line on a debt counting in a month only if a payment falls in it, for its household (the $3,400 budget has a $2,300 Rent / Mortgage line and the mortgage is on no property): September’s PLANNED reads Mortgage −$2,400 · Expenses −$1,100 · Tax bill — due in full −$1,000 · = Planned surplus +$2,700 (it read +$400), and October’s plan card $3,450 (it read $1,150). Line added 2026-10-26.",
  "His words, or where it came from": "Not a decision of his: the lead’s ruling of 2026-10-25, made without asking him, as his order of 2026-09-30 says; built by FIX-MONTH. One word from him reverses it. Made under his rules DEC-1923 (“the app deduct it directly … instead of leaving it for user to add it to planned expenses”) and DEC-2440, on CFR-5’s open question and CFR-2’s MK-CF-O-020-C05. To reverse: count the Rent / Mortgage line as rent until a home is placed, and count every budget line however it is named.",
  "Record": "DEC-1923 · DEC-2440 · MK-CF-O-020 · MK-CF-M-001 · MK-CF-M-002 · MK-CF-M-048",
  "State": "In the code since 2026-10-26"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "Debts (frame 6), PAYOFF PLAN: the plan pays what the person pays — each debt at the payment they set, never less than its minimum — plus the extra a month. A $9,000 card at 24% with a $200 minimum paid at $300, and a $14,000 car loan at 6.9% at $250, on Oct 1, 2026: ‘$550 /month total’, debt-free Jun 2031, $7,647 total interest (it read $450 /month total, Oct 2033, $14,787 — the minimums). This replaces the words ‘This line does not change the payoff plan’s figures’ in the 2026-10-25 line on a payment set above the minimum. Line added 2026-10-26.",
  "His words, or where it came from": "Not a decision of his: the lead’s ruling of 2026-10-25, made without asking him, as his order of 2026-09-30 says; built by FIX-MONTH. One word from him reverses it. Made under his ruling DEC-0641 (Q53, “what actually leaves”) and tenet 1 (DEC-3523), on CFR-5’s MK-CF-M-073 (tenets 1 and 5). To reverse: run the plan on the minimums again.",
  "Record": "DEC-0641 · DEC-3523 (tenet 1) · MK-CF-M-072 · MK-CF-M-058 · MK-CF-M-059 · MK-CF-M-073 · MK-CF-F-034 · MK-CF-O-018",
  "State": "In the code since 2026-10-26"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "Debts (frame 6), and wherever a debt’s rate is shown: a rate never entered reads ‘rate not entered’, never 0.00% — a mortgage added with its property (the form does not ask its rate) or a rate box left blank in the debt editor; a typed 0 is 0.00%. The row has no ‘/month interest’: ‘rate not entered · on Lake house · $1,900/month min’. The line under YOUR DEBT reads ‘across 2 debts · $2,150/month in payments’, and under it ‘Lake house mortgage’s rate is not entered, so there is no interest figure — we won’t guess one.’ PAYOFF PLAN: ‘Lake house mortgage’s rate is not entered, so there is no payoff date — we won’t guess one.’ (a payment not entered already reads so). Line added 2026-10-26.",
  "His words, or where it came from": "Not a decision of his: the lead’s ruling of 2026-10-25, made without asking him, as his order of 2026-09-30 says; built by FIX-MONTH. One word from him reverses it. Made under tenet 3 (DEC-3523, unknown is not zero) and his ruling DEC-0296 (“an unknown input produces no number and a reason — never a default”), on NW-MMFIX’s follow-up finding (a mortgage’s rate is never asked and was saved as 0). To reverse: save a blank rate as 0% again.",
  "Record": "DEC-3523 (tenet 3) · DEC-0296 · MK-CF-M-057 · MK-CF-M-058 · MK-CF-M-059 · MK-CF-O-018 · MK-CF-F-034",
  "State": "In the code since 2026-10-26"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "Debts (frame 6), PAYOFF PLAN, a debt whose payment was never entered: the plan gives no date and no ‘never’, from the plan itself — ‘Car loan’s payment is not entered, so there is no payoff date — we won’t guess one.’ (it was the screen that held the words back; the plan said ‘never’, and the Goals tab printed ‘⚠ Minimum payments don’t cover the interest’). Line added 2026-10-26.",
  "His words, or where it came from": "Not a decision of his: the lead’s ruling of 2026-10-25, made without asking him, as his order of 2026-09-30 says; built by FIX-MONTH. One word from him reverses it. Made under tenet 3 (DEC-3523) and DEC-0296, on CFR-3’s MK-CF-O-018-C03. To reverse: let the plan call an unentered payment ‘never’ again.",
  "Record": "DEC-3523 (tenet 3) · DEC-0296 · MK-CF-O-018 · MK-CF-F-034 · MK-CF-M-058",
  "State": "In the code since 2026-10-26"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "Cash flow when retired, YOUR PAYCHECK (not drawn below), and Home’s paycheck card: the draw is worked out at the Plan’s own return — the return set on the Plan, else the blended benchmark of the accounts set aside for retirement, else 6.00% — the figure the Retirement cockpit runs (it was a flat 5.50% whenever no return was set). Under ‘This year ~…’ a line says it: ‘The draw assumes 6.00% a year — the typical return, with nothing set aside for retirement.’ With no birth year entered there is no paycheck to work out: under ‘YOUR PAYCHECK’ the card reads ‘Your birth year is not entered, so there is no paycheck to work out — we won’t guess one.’ (it worked one out at age 68). Line added 2026-10-26.",
  "His words, or where it came from": "Not a decision of his: the lead’s ruling of 2026-10-25, made without asking him, as his order of 2026-09-30 says; built by FIX-MONTH. One word from him reverses it. Made under tenet 4 (DEC-3523, one plan, one return) and his ruling DEC-0296, on CFR-4’s MK-CF-F-225 (its case C05 and its open question). To reverse: run the paycheck at 5.50% and at 68 again.",
  "Record": "DEC-3523 (tenets 3, 4) · DEC-0296 · MK-CF-F-225 · MK-CF-M-078",
  "State": "In the code since 2026-10-26"
 },
 {
  "Ruled": "2026-10-26",
  "What changed, against the phones below": "Cash flow when retired, DRAW COMES FROM (not drawn below), its ‘Why this order?’ card and the draw-steer sheet: with no birth year entered, nothing that depends on age is calculated . The order of the kinds of account still shows — Cash, Taxable / brokerage, Pre-tax, Roth does not depend on age — but whether the required withdrawal comes first, and its amount, does: with pre-tax money held, under the order the card reads ‘Your birth year is not entered, so there is no required withdrawal to work out — we won’t guess one.’, in the paycheck card’s words. The steer sheet draws no required-withdrawal row, and its comparison reads ‘Your birth year is not entered, so there is no comparison to work out — we won’t guess one.’ in place of ‘lasts to … · taxes over the plan …’. All three calculated them at age 68, a made-up age. With a birth year entered nothing changes. Line added 2026-10-26.",
  "His words, or where it came from": "Not a decision of his: the lead’s, made without asking him, as his order of 2026-09-30 says; built by CLEANUP-LEFT. One word from him reverses it. Made under tenet 3 (DEC-3523, unknown is not zero) and his ruling DEC-0296 (an unknown input gives no number and a reason, never a default) — the same class as the paycheck card’s line above. To reverse: work the order at 68 again.",
  "Record": "DEC-3523 (tenet 3) · DEC-0296 · MK-PL-F-004 withdrawalOrder · MK-PL-F-010 drawOrderOutcome · MK-CF-M-070",
  "State": "In the code since 2026-10-26"
 },
 {
  "Ruled": "2026-10-26",
  "What changed, against the phones below": "Cash flow when retired, YOUR PAYCHECK (not drawn below), Home’s paycheck card, the draw-steer sheet, Roth and Required withdrawals: the return the draw runs on is written the canon’s way, with ‘/year’ — ‘The draw assumes 6.00%/year — the typical return, with nothing set aside for retirement.’ and ‘Growth used: 6.00%/year — the typical return, with nothing set aside for retirement, less 2.50% inflation.’ (it was ‘6.00% a year’); a screen reader still hears ‘6.00% a year’. The figures are unchanged. Each now prints under its own number: the return MK-CF-M-082, the inflation MK-CF-M-083, the sheet’s rates MK-CF-M-084 to 088 (they printed under MK-CF-M-078 and MK-CF-M-022, or with none). Line added 2026-10-26.",
  "His words, or where it came from": "Not a decision of his and not a new one: his canon row 14 (2026-09-12) — a label says per year as ‘/year’ in printed copy, and ‘a year’ stays in spoken labels (the canon’s own words). The old wording slipped past the canon guard because a ‘%’ stood between the figure and ‘a year’; printing the figure through its declaration showed it. Applied by PF-TOOLS. To reverse: write ‘a year’ again — which the canon guard will then report.",
  "Record": "Canon row 14 · MK-CF-M-082 · MK-CF-M-083 · MK-CF-M-084 · MK-CF-M-085 · MK-CF-M-086 · MK-CF-M-087 · MK-CF-M-088 · MK-CF-F-279",
  "State": "In the code since 2026-10-26"
 },
 {
  "Ruled": "2026-10-26",
  "What changed, against the phones below": "Debts (frame 6), the mortgage comparison under a mortgage: its rates are written to two decimals , as every percent is — ‘Your mortgage costs 4.10%. A ten-year Treasury pays 4.30% today — 3.27% after your 24% federal tax bracket.’ and, with no income entered, ‘Your mortgage costs 5.50%. A ten-year Treasury pays 4.63% today, before tax.’ (it read ‘4.1%’, ‘4.3%’ and ‘5.5%’, the digits each rate happened to have). Nothing else on the card changes. Each figure prints under its own number: MK-CF-M-090 to 095, the bracket under the Income summary’s MK-CF-M-043. Line added 2026-10-26.",
  "His words, or where it came from": "Not a decision of his and not a new one: his precision standard (master question Q49, 2026-09-09) — percents to two decimals, rounded once at display. Applied by PF-TOOLS while giving the card’s figures their identifiers. To reverse: write each rate with the digits it has, and state that precision on its row.",
  "Record": "Q49 · MK-CF-F-043 · MK-CF-M-043 · MK-CF-M-090 · MK-CF-M-091 · MK-CF-M-092 · MK-CF-M-093 · MK-CF-M-094 · MK-CF-M-095",
  "State": "In the code since 2026-10-26"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "A past month on This month (not drawn below): ‘Frozen — past months never change under you.’ is said only when the month’s record was saved. A month with no record is added up from what is logged in it, and says so: ‘Added up from what is logged for this month — it changes if more is logged.’ Line added 2026-10-26.",
  "His words, or where it came from": "Not a decision of his: the lead’s ruling of 2026-10-25, made without asking him, as his order of 2026-09-30 says; built by FIX-MONTH. One word from him reverses it. Made under tenets 2 and 7 (DEC-3523), on CFR-4’s formula check of MK-CF-F-220 (a month never saved read ‘Frozen’ while it moved from $500 to $600 as purchases were imported). To reverse: print ‘Frozen —’ under every past month.",
  "Record": "DEC-3523 (tenets 2, 7) · MK-CF-F-220 · MK-CF-M-052",
  "State": "In the code since 2026-10-26"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "Expenses, for a past month whose record does not say when it was saved (an older record): under ‘= Actual expenses, all sources’, when the list holds more than the month’s record: ‘August’s record does not say when it was saved, so it may leave out later entries — this list holds $150 more than August’s figures.’ A record that says when it was saved names each late entry, as the 2026-10-24 line says. Line added 2026-10-26.",
  "His words, or where it came from": "Not a decision of his: the lead’s ruling of 2026-10-25, made without asking him, as his order of 2026-09-30 says; built by FIX-MONTH. One word from him reverses it. Made under tenet 2 (DEC-3523), on CFR-5’s rule check DEC-7949 (the card read $1,360 and the list $1,510 with nothing said). To reverse: say nothing when a record has no saved time.",
  "Record": "DEC-7949 · DEC-3523 (tenet 2) · MK-CF-F-231 · MK-CF-M-013 · MK-CF-M-052",
  "State": "In the code since 2026-10-26"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "Expenses (frame C), BIG-TICKET RADAR: a bill of $500 or more with its own month is on the radar in that month only — $1,200 of car insurance due Dec 15 reads, in December, ‘Car insurance · due Dec 15 · $1,200’; October’s radar has nothing for it. It is the month’s dated bill the Bill calendar and a later month’s plan card name (datedBillsIn); the radar never deducts it again. Line added 2026-10-26.",
  "His words, or where it came from": "Not a decision of his: the lead’s ruling of 2026-10-25, made without asking him, as his order of 2026-09-30 says; built by FIX-MONTH. One word from him reverses it. Made under his rule DEC-0002 (big one-time bills get their own list) and tenet 4 (DEC-3523), on CFR-2’s MK-CF-F-153-C05 (reading A). To reverse: hand the radar no bills.",
  "Record": "DEC-0002 · DEC-3523 (tenet 4) · MK-CF-F-153 · MK-CF-M-016 · MK-XS-F-004",
  "State": "In the code since 2026-10-26"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "This month, ACTUAL (frames A and B), and Expenses’ DEBT PAYMENTS COUNTED AS EXPENSES and BIG-TICKET RADAR: a payment is matched to the debt it was logged against by the debt itself, never by its name — ‘Log a payment’ now records which debt. A payment logged before this, under a name two debts share, is given to neither: ACTUAL reads ‘Other debt payments −$250 · logged as “Loan” — two of your debts have that name, so it is given to neither’, and Expenses lists it once, ‘Loan payment $250 · two of your debts have that name — counted once’. With one debt of that name it is that debt’s, as before. Line added 2026-10-26.",
  "His words, or where it came from": "Not a decision of his: the lead’s ruling of 2026-10-25, made without asking him, as his order of 2026-09-30 says; built by FIX-MONTH. One word from him reverses it. Made under his rule DEC-1923 (on the actual side nothing is assumed paid) and tenet 1 (DEC-3523), on CFR-2 and CFR-4’s MK-CF-F-157-C05 and MK-CF-F-150-C05 (one $250 given to the second ‘Loan’, or to both). To reverse: match a payment by its name again.",
  "Record": "DEC-1923 · DEC-3523 (tenet 1) · MK-CF-F-157 · MK-CF-F-150 · MK-CF-F-153 · MK-CF-M-054",
  "State": "In the code since 2026-10-26"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "Income tab (frame 5), YOUR SOURCES: a one-time payment with no year reads ‘Gift · one-time · year not entered · $2,000 ›’ — it is counted in no month and no year until its year is known (it read ‘lands in January’ and landed again every year). This month (frames A and B): a rental that loses money is a row of the inflow, ‘Rental (after costs) −$500’, so $7,200 of take-home and a rental losing $500/month read $6,700 in and a planned surplus of +$650 (it read $7,200 and +$1,150). Shares that vest are not money in their month unless sold when they vest; Social Security lands whole except the tax on the part IRS Publication 915 taxes; unemployment pay is a row after tax.",
  "His words, or where it came from": "Not a decision of his: the lead’s, on the outside Cash flow audit of 2026-10-24 (OpenAI), made without asking him, under his DEC-0447 and DEC-7940 (lands once), DEC-0012, the same shape as DEC-0179 for vests kept as shares, and tenets 1 and 4. To reverse: drop rows below $0 from the month; land a yearless one-time payment in its next month.",
  "Record": "DEC-0447 · DEC-7940 · DEC-0012 · DEC-0179 · MK-XS-F-004 · MK-CF-M-002 · MK-CF-M-027",
  "State": "In the code"
 },
 {
  "Ruled": "2026-10-25",
  "What changed, against the phones below": "Income (frame 5), YOUR SOURCES: the list is the one function every income screen reads (incomeSources, MK-CF-O-016), so a source entered anywhere has its row here, in its own period, under the drawn names and in the drawn order — Salary, Self-employment, Bonus, Other income, Rental income, Equity comp, Social Security · pension — then, when entered, Benefits (‘every month’ or ‘6 months of the year’ · $731/month ›), Child support or alimony (‘not taxed’ · $511/month ›) and Interest & dividends (‘reinvested’ or ‘paid to your bank’ · $1,831/year ›). A rental losing money reads ‘Rental income · 1 property · −$500 ›’; grants with no vest date ‘Equity comp · RSU grants · vest date not entered · — ›’. Each row is the figure the Income summary and Your income print for the same source.",
  "His words, or where it came from": "Not a decision of his: the lead’s follow-up on the outside Cash flow audit of 2026-10-24 (OpenAI), made without asking him, under tenets 1 and 4 (one thing, one number) and his DEC-0181 (no two functions doing the same thing). To reverse: build the list on the screen again.",
  "Record": "DEC-0181 · DEC-3523 (tenets 1, 4) · MK-CF-O-016 · MK-CF-M-006 to 011 · MK-CF-M-027",
  "State": "In the code"
 },
 {
  "Ruled": "2026-10-27",
  "What changed, against the phones below": "Expenses (frames C and D), ACTUAL EXPENSES and BIG-TICKET RADAR, and Income (frame 5), RECEIVED THIS MONTH: every row is printed once, from its full value, and the rows under a total add up to that total as printed . An expense, a payment logged and a payment received are written to the cent (the 2026-10-25 line of drawing errors), so each total over them is written to the cent too: ‘= Entered by hand’, ‘= Imported’, the three source bars, ‘Show all N · $X more’, ‘= Actual expenses, all sources’ and the ACTUAL EXPENSES bar. Frame A’s household with a $6.50 coffee and its HELOC and card payments logged as $200.40 each: ENTERED BY HAND $300.00 + $6.50 + $200.00 = $506.50 (it read $506); DEBT PAYMENTS COUNTED AS EXPENSES $200.40 + $200.40 = $400.80 (it read $200 + $200 under $401); ‘= Actual expenses, all sources’ $506.50 + $1,200.00 + $400.80 = $2,107.30 (it read $2,107); each payment on the radar $200.40 (it read $200). A paycheck of $3,100.40 received reads ‘+$3,100.40’ (it read +$3,100.00: rounded to the dollar first, then given cents). Frame C’s own figures, all whole, read $500.00 · $1,200.00 · $400.00 · $2,100.00, ‘Show all 9 · $195.00 more ›’ and ‘Show all 23 · $560.00 more ›’, its radar payments $200.00; frame D’s ACTUAL EXPENSES reads $0.00. A bill on the radar (‘Car insurance · due Dec 15 · $1,200’) stays in whole dollars, as PLANNED EXPENSES and the Bill calendar print it; This month keeps whole dollars that add up to its surplus (the 2026-10-24 line). For these totals this replaces ‘totals stay whole dollars’ in the 2026-10-25 line of drawing errors.",
  "His words, or where it came from": "Not a decision of his: the lead’s ruling R5 of 2026-10-27 on the round-2 drawing match (CF2-06), made without asking him, as his order of 2026-09-30 says. Made under tenet 2 (DEC-3523, the rows under a total add up to it), which stands above tenet 4 (one form) where the two pull apart, and his precision ruling (an expense at two decimals, DEC-0264). One word from him reverses it. To reverse: print every Expenses total in whole dollars again.",
  "Record": "DEC-3523 (tenets 2, 4) · DEC-0264 · MK-CF-M-014 · MK-CF-M-012 · MK-CF-M-101 (new) · MK-CF-M-016",
  "State": "In the code since 2026-10-27 — row written before the code"
 },
 {
  "Ruled": "2026-10-27",
  "What changed, against the phones below": "This month (frames A and B), the household of the 2026-10-25 line on a rental that loses money: a $7,200 take-home, a $3,400 budget ($2,300 of it Rent / Mortgage), a $2,400 mortgage the person never placed on a property, a $250 car loan and a rental house losing $500/month. The mortgage is counted once, from Debts, and the Rent / Mortgage line stands down , as the 2026-10-25 line on a debt counted once says for a mortgage on no property: September’s PLANNED reads Inflow $6,700 · Mortgage −$2,400 · Car loan −$250 · Expenses −$1,100 · = Planned surplus +$2,950 (6,700 − 2,400 − 250 − 1,100). It read Expenses −$3,400 and +$650: with one property and one mortgage on none, the app had put the mortgage on the rental by itself, so the line came back and the same $2,300–$2,400 of housing was counted twice. ACTUAL: the $2,300 logged under Rent / Mortgage is the mortgage’s payment, ‘Mortgage −$2,300’, and Expenses entered by hand −$698; = Actual surplus so far +$3,452, as before. The mortgage counts as the rental’s only when the person places it there (the mortgage’s own property, or a name that begins with the property’s, ‘Rental house mortgage’); then the line is rent again and +$650 is right. This corrects the +$650 of the 2026-10-25 line on a rental that loses money; the two lines now read the same.",
  "His words, or where it came from": "Not a decision of his: the lead’s ruling R3 of 2026-10-27 (CF2-13), worked by hand from what the person entered, made without asking him. Made under his rule DEC-1923 (“the app deduct it directly … instead of leaving it for user to add it to planned expenses”), DEC-2440, tenet 1 and tenet 5 (DEC-3523: the person’s word outranks the app’s guess — the placement was the app’s guess). One word from him reverses it. To reverse: count a mortgage the app placed by itself as the person’s placing again.",
  "Record": "DEC-1923 · DEC-2440 · DEC-3523 (tenets 1, 5) · MK-CF-O-020 · MK-CF-M-002 · MK-CF-M-003",
  "State": "In the code since 2026-10-27 — row written before the code"
 },
 {
  "Ruled": "2026-10-27",
  "What changed, against the phones below": "Debts (frame 6), YOUR DEBTS: nothing is ranked on a rate that is not entered . Under ‘Highest interest rate first’ the debts with a rate come first, highest first, then each debt whose rate is not entered; and while any rate is not entered no debt reads ‘pay first’ and none ‘— the costliest’, because both answers turn on the rate nobody gave. The household of the 2026-10-25 line on a rate never entered (a Lake house mortgage, rate not entered, $1,900/month; a $14,000 car loan at 6.90%, $250/month): Car loan ‘6.90% · $250/month min · ~$81/month interest’ (14,000 × 6.90% ÷ 12 = $80.50), then Lake house mortgage ‘rate not entered · on Lake house · $1,900/month min’. It read the mortgage first with ‘pay first’, and the car loan ‘6.90% — the costliest’. ‘Smallest balance first’ ranks on the balances, which are entered: the car loan reads ‘pay first’, still without ‘— the costliest’.",
  "His words, or where it came from": "Not a decision of his: the lead’s ruling R6 of 2026-10-27 (CF2-12), made without asking him. Made under tenet 3 (DEC-3523, unknown is not zero) and his ruling DEC-0296 (an unknown input produces no number and a reason — never a default). One word from him reverses it. To reverse: rank a rate not entered as 0% again.",
  "Record": "DEC-3523 (tenet 3) · DEC-0296 · MK-CF-O-018 · MK-CF-M-057",
  "State": "In the code since 2026-10-27 — row written before the code"
 },
 {
  "Ruled": "2026-10-27",
  "What changed, against the phones below": "A past month on This month (not drawn below) with no saved record: one line says what the figures are, never two that disagree . Before anything was logged at all — frame A’s household in July, its first expense logged in August — the card reads Actual inflow $0 · Outflow (expenses + debt) $0 · = Surplus +$0 and ‘Nothing recorded for this month — it predates your tracking.’, and no more; it also printed ‘Added up from what is logged for this month — it changes if more is logged.’, which says the month was added up. A month after the first thing logged, with no saved record, reads only ‘Added up from what is logged …’; a month with its record saved only ‘Frozen — past months never change under you.’",
  "His words, or where it came from": "Not a decision of his: made without asking him, as his order of 2026-09-30 says; found by the round-2 drawing match (CF2-08). Made under the 2026-10-25 line on a past month (DEC-3523 tenets 2 and 7) and tenet 1 (two lines that contradict). One word from him reverses it. To reverse: print both lines again.",
  "Record": "DEC-3523 (tenets 1, 2, 7) · MK-CF-F-220 · MK-CF-M-051 · MK-CF-M-052 · MK-CF-M-053",
  "State": "In the code since 2026-10-27 — row written before the code"
 },
 {
  "Ruled": "2026-10-27",
  "What changed, against the phones below": "A later month and a past month on This month (not drawn below): the surplus carries its sign , as This month prints it (‘+$350’). The register household’s October: ‘= Planned surplus +$3,450’ (7,200 − 3,750; it read $3,450, no sign); a past month’s ‘= Surplus’ the same way; a month that comes out short reads ‘−$…’. Nothing else moves.",
  "His words, or where it came from": "Not a decision of his: made without asking him; found by the round-2 drawing match (CF2-07). Made under tenet 4 (DEC-3523: one thing, one number, one form) — the class the budget editor’s line of 2026-10-25 fixed. One word from him reverses it. To reverse: print a later and a past month’s surplus without its sign.",
  "Record": "DEC-3523 (tenet 4) · MK-CF-M-049 · MK-CF-M-053",
  "State": "In the code since 2026-10-27 — row written before the code"
 },
 {
  "Ruled": "2026-10-27",
  "What changed, against the phones below": "This month’s YOUR FUTURE PAYCHECK card (not drawn below): the line under its figure writes each rate the canon’s way, with ‘/year’ — ‘In today’s dollars · assumes a 6.00%/year return and 2.40%/year inflation’ (it read ‘… assumes a 6.00% return and 2.40% inflation a year’, the words of the 2026-10-25 and 2026-10-26 lines, which this replaces). The figures and the article rule do not change: an 8.00% return reads ‘an 8.00%/year return’.",
  "His words, or where it came from": "Not a decision of his and not a new one: his canon row 14 (2026-09-12) — a label says per year as ‘/year’ in printed copy — as the 2026-10-26 line already applied to the retired paycheck and the draw sheet; found by the round-2 drawing match (CF2-09). To reverse: write ‘a year’ again.",
  "Record": "Canon row 14 · MK-CF-M-082 · MK-CF-M-083 · MK-CF-M-022",
  "State": "In the code since 2026-10-27 — row written before the code"
 },
 {
  "Ruled": "2026-10-27",
  "What changed, against the phones below": "The budget editor, ‘Your budget’ (not drawn below): its share of take-home is written to two decimals — frame A’s household ‘Your expense budget is 40.00% of take-home pay.’ (2,000 ÷ 5,000; it read 40%), the register household’s 15.28% (1,100 ÷ 7,200 = 15.277…%; it read 15%); its doors end in ‘›’ , as every Cash flow door does — ‘Set your budget ›’, ‘Manage ›’, ‘+ Add ›’ (they ended in ‘→’); and its quotes and apostrophes are the typographic ones the drawings use — the marks around ‘+ Add’ in the empty list’s line and around a category’s name in the delete question, and the ’ in ‘plan what you’ll spend’.",
  "His words, or where it came from": "Not a decision of his: made without asking him; found by the round-2 drawing match (CF2-11). Made under his precision ruling (Q49: percents to two decimals), the one door glyph (DEC-0440, the drawing’s ‘›’) and tenet 4 (DEC-3523). One word from him reverses it. To reverse: write the share whole and the doors with ‘→’ again.",
  "Record": "Q49 · DEC-0440 · DEC-3523 (tenet 4) · MK-CF-M-001 · MK-CF-M-031",
  "State": "In the code since 2026-10-27 — row written before the code"
 },
 {
  "Ruled": "2026-10-27",
  "What changed, against the phones below": "Every Cash flow tab, the budget editor and the Bill calendar: an apostrophe inside a word is ’ , as the drawings write it — ‘Based on your plan’s odds …’, ‘No zeros shown until they’re real.’, ‘plan what you’ll spend’, ‘we’ll import it’, ‘make sure it’s a valid CSV’, ‘e.g. Trader Joe’s’, and on the Bill calendar ‘it’s built from …’, ‘it’s in that month’s Out column.’, ‘IF YOU CAN’T PAY EVERYTHING …’, the marks around essential in ‘Mark bills … to see them here.’. One sentence was spelled two ways on one screen. A guard reads Cash flow’s own files and fails on a straight ' inside a word.",
  "His words, or where it came from": "Not a decision of his: made without asking him; found by the round-2 drawing match (CF2-10). The class DEC-8336 fixed on Net worth, under tenet 4 (DEC-3523). The sign-up’s words are FX-CF-B’s and the shared parts FX-SHARED’s. To reverse: nothing to undo in the figures; write ' again.",
  "Record": "DEC-8336 · DEC-3523 (tenet 4)",
  "State": "In the code since 2026-10-27 — row written before the code"
 },
 {
  "Ruled": "2026-10-27",
  "What changed, against the phones below": "DRAWING ERROR, frames 5 and 6 — the links ‘Add your income ›’ and ‘Log a payment ›’ are drawn at 14 (the drawing’s .link style), a size off the app’s one scale like the six the 2026-10-25 appearance line names (13.5, 12.5, 12, 11.5, 10.5, 9). They are built at 13, the scale’s step for a link and an empty-state line; this line adds 14 to that list. The phones are not redrawn.",
  "His words, or where it came from": "Not a decision of his: the record the round-2 drawing match asked for (REC2-06), under the 2026-10-25 appearance line (DEC-0093, the type scale). Nothing changes in the app. To reverse: nothing to undo.",
  "Record": "DEC-0093 · DEC-4529",
  "State": "Drawing corrected by this line — nothing in the app changes"
 },
 {
  "Ruled": "2026-10-27",
  "What changed, against the phones below": "Every tab: the door to add an expense yourself is ‘Log an expense’ (Expenses, frame D), and the corner button that opens the same sheet reads ‘＋ Expense’ (kept by DEC-1560). ‘Add by hand’ is the account door’s (Home, Net worth, Sharpen your plan, src/constants/doors.ts) and no Cash flow tab prints it: Cash flow’s ‘Add an expense by hand’ door left the tab on 2026-10-03, when Expenses was built to frame C. ‘Entered by hand’ stays: it names where an expense came from (frame C), not a door. The canon carries it as row 27.",
  "His words, or where it came from": "Not a decision of his: the lead’s ruling of 2026-10-27 on workplan row 106 (his two word collisions, 2026-09-14), made without asking him. Made under his one-term order (DEC-0382) and tenet 4 (DEC-3523). The sheet the two open is titled ‘Add expense’ in the shared sheet file; it reads ‘Log an expense’ once FX-SHARED changes it. One word from him reverses it. To reverse: give the expense door other words, on this row and canon row 27.",
  "Record": "DEC-0382 · DEC-1560 · DEC-3523 (tenet 4) · canon row 27",
  "State": "In the code — the door left the tab on 2026-10-03; canon row 27 since 2026-10-27"
 },
 {
  "Ruled": "2026-10-27",
  "What changed, against the phones below": "Approved before: Cash flow v01, 2026-09-28 (DEC-0440: “Approved”). Every phone draws the tab bar with letter shapes above the names (⌂ ◈ ▤ ⇄ ▲), the names 9.5 points; and the top bar 11 points in from each side and 8 above the page, its button 30 points tall with 12.5-point words. His feedback: His words, 2026-08-04 (DEC-0059): “make sure font size and color and overall design are same across all screens.” His UX review of 2026-07-16, as the code records it: ‘it is hard to link menu to button bar’. His words, 2026-09-14 (DEC-0354): “you did not have ‘MoneyKeel’ at the top which every other screen has”; 2026-08-04 (DEC-0059): “make sure font size and color and overall design are same across all screens.” New: The tab bar is the one the app draws: each tab an icon above its name — the same five icons the Menu’s top strip shows, filled on the picked tab, outlined on the others; the picked tab brand green #178F6B with a short green bar (22 × 3 points) above its icon; the other four grey #76766F; names weight 700. One thing changes in the app: the names are 11 points, where they were 10.5 — the one size in the app off the scale (11 · 13 · 15 · 17 · 20 · 24 · 30 · 38). The MoneyKeel top bar starts 4 points below the status bar (the app started it 6 down until today), sits 20 points in from each side and 10 above the page; its button and two round icons are 38 points tall, the button’s words 13 points. The phones are not redrawn.",
  "His words, or where it came from": "Why the app’s bar: Net worth v08, approved 2026-10-01 (DEC-0644), draws its names, colours and green bar; Cash flow v01 (DEC-0440) draws the picked tab #178F6B; the UX design v1.2 says ‘active = brand teal + label bold’; the screen standard says ‘Brand green #178F6B is for buttons and the active tab’; and the Menu mirrors the bar from one list, so a drawn emoji or letter would break the pair. Why 4 · 20 · 10: the account page v01, approved 2026-10-19 (DEC-6457), the newest approved drawing with this bar, and Net worth v08 (DEC-0644) both draw it. Not a decision of his: the lead’s ruling of 2026-10-27, made without asking him, as his order of 2026-09-30 says. To reverse: the names at 10.5 again. To reverse: start the bar 6 points down again.",
  "Record": "DEC-0059 · DEC-0644 · DEC-0440 · DEC-4529 · DEC-0354 · DEC-6457",
  "State": "In the code since 2026-10-27"
 },
 {
  "Ruled": "2026-10-27",
  "What changed, against the phones below": "Every frame, and the screens they open (the budget editor, the import sheet, Cash flow when retired): every box title sits on a dark-green bar and every sub-title on a light-green bar , edge to edge with square corners (white capitals 11 points, weight 800, on #085041; deep green on #DFF2E9). What moves: This month’s first day, ‘SET UP YOUR MONTH — 2 STEPS’ (the 2026-10-25 line on a person who has entered nothing had made it a quiet grey label); Income (frame 5), THIS MONTH, YOUR SOURCES and RECEIVED THIS MONTH; Debts (frame 6), YOUR DEBT, PAYOFF PLAN, YOUR DEBTS and PROGRESS (the 2026-10-25 appearance line had made them quiet grey labels, as this drawing draws them); Cash flow when retired, DRAW COMES FROM, its two doors ‘Steer it ›’ and ‘Why? ›’ on the line under the bar; the budget editor, YOUR BUDGET, EXPENSES BY BUCKET with each bucket on a light bar that carries its spend and plan (‘FIXED $22 / $200’), DEBT THIS MONTH and CUSTOM CATEGORIES, each door (‘Set your budget ›’, ‘Manage ›’, ‘+ Add ›’) on the line under its bar, and each bucket of the Monthly limits sheet on a light bar; the import sheet, IMPORT FROM EXCEL OR CSV and EXAMPLE CSV FORMAT. The words, the figures and the order do not change. This replaces the quiet labels of the 2026-10-25 lines named. The phones are not redrawn.",
  "His words, or where it came from": "His words: “ContributionRoom, Stress Test screens - both are not standard app design as the standard design says box titles in dark green bar, and sub-titles in light green bar.” (DEC-8839, 2026-10-27). The lead’s ruling R1 of 2026-10-27 makes it app-wide, and the screen-design standard carries it (section 2.3). Applied to Cash flow by FX-CF-A without asking him again. To reverse: give these titles their quiet grey labels again.",
  "Record": "DEC-8839 · DEC-0440 · DEC-3523 (tenet 6)",
  "State": "In the code since 2026-10-27 — row written before the code"
 },
 {
  "Ruled": "2026-10-27",
  "What changed, against the phones below": "Approved before: Cash flow v01, 2026-09-28 (DEC-0440: “Approved”). The expense, payment and budget boxes print a typed figure plain. His feedback: None on these boxes. He approved the income drawing on 2026-08-27 (DEC-0177: “yes”), which draws a money box with its figure as money, ‘$7,000’. New: Every money box on this screen shows its figure the way a figure is printed, while it is typed — ‘$1,000’ where a box was drawn ‘1000’, ‘$192.50’ where ‘192.5’; where the screen prints its own $ just before the box, the box reads ‘1,000’, so the $ is printed once — and it stores the plain amount, so no figure moves. The box keeps its look. A typed letter is refused whole (DEC-3768c). Shares, contracts, rates, days and years keep their plain digits. The phones are not redrawn.",
  "His words, or where it came from": "One figure, one form (tenet 4, DEC-3523): the money boxes of the income screens already show ‘$7,000’ (DEC-8385), and one component, MoneyBox, now draws every money box in the app — src/__tests__/every_money_box_is_moneybox.test.tsx counts them all. Not a decision of his: the lead’s ruling of 2026-10-27, made without asking him, as his order of 2026-09-30 says. To reverse: print the plain figure in the box again.",
  "Record": "DEC-8385 · DEC-0177 · DEC-3768c · DEC-3523",
  "State": "In the code since 2026-10-27"
 },
 {
  "Ruled": "2026-10-27",
  "What changed, against the phones below": "Approved before: Cash flow v01, 2026-09-28 (DEC-0440: “Approved”). The sheet that ＋ Expense and Log an expense open is not drawn; it was titled ‘Add expense’ with its four group names (EVERYDAY · ONCE IN A WHILE · BILLS & FIXED · MORE) in 11-point grey capitals. Home’s sheet that splits a surplus named GOALS and ACCOUNTS / INVESTING the same way. His feedback: His words, 2026-10-27 (DEC-8839): “the standard design says box titles in dark green bar, and sub-titles in light green bar”. New: Not a drawn state: the expense sheet is titled ‘Log an expense’ (canon row 27, the line above of this date), and the expense sheet’s four group names stand on light-green bars, deep-green capitals 11 points weight 800, edge to edge across the sheet; on Home’s split sheet GOALS and ACCOUNTS / INVESTING stand on the same bars. No figure changes. The phones are not redrawn.",
  "His words, or where it came from": "Not a decision of his beyond those words: the lead’s ruling R1 of 2026-10-27 makes them app-wide, applied without asking him, as his order of 2026-09-30 says. To reverse: the group names back to grey capitals, and the title to Add expense.",
  "Record": "DEC-8839 · canon row 27",
  "State": "In the code since 2026-10-27"
 },
 {
  "Ruled": "2026-10-30",
  "What changed, against the phones below": "Approved before: this drawing, 2026-09-28 (DEC-0440); Home’s THIS MONTH’S CASH FLOW box is not drawn below. His feedback: His words, 2026-08-04 (DEC-0059): “make sure font size and color and overall design are same across all screens.” New: Home’s box prints its title ‘THIS MONTH’S CASH FLOW’ and says ‘This month’s cash flow’ to a screen reader with ’, as this drawing writes it; both had a straight '. No word and no figure moves. The phones are not redrawn.",
  "His words, or where it came from": "One sentence, spelled one way (tenet 4, DEC-3523): the lead’s rule of 2026-10-25 (DEC-8336), carried to every screen on 2026-10-27 and held by src/__tests__/curly_apostrophe_everywhere.test.ts, which now carries no debt for Home. Not a decision of his: the lead’s ruling of 2026-10-30, made without asking him, as his order of 2026-09-30 says; built by CLEANUP-TESTS. One word from him reverses it. To reverse: type a straight ' in these strings again.",
  "Record": "DEC-8336 · DEC-3523 · DEC-0059 · DEC-0440",
  "State": "In the code since 2026-10-30"
 },
 {
  "Ruled": "2026-10-30",
  "What changed, against the phones below": "Approved before: Cash flow v01, 2026-09-28 (DEC-0440: “Approved”). Its top bar draws the name typed in two colours, ‘Money’ green and ‘Keel’ navy, as the app drew it until 2026-10-30. No logo decision of his is on record before this one. His feedback: his instruction of 2026-10-30, with his three logo files: “change the logo to attached”. New: The lettering in the top bar is now his logo of 2026-10-30, his dark-green ‘MoneyKeel’ lettering at 84 × 17.1 points, as ‘MoneyKeel/documents/other/moneykeel_pres_mock_brand-wordmark_v02.html’ draws it. Nothing else on the phones moves. The phones are not redrawn.",
  "His words, or where it came from": "His instruction, carried to this drawing by the lead’s row of 2026-10-30, made without asking him, as his order of 2026-09-30 says. To reverse: the old lettering is kept in ‘assets/brand/archive-2026-10-30/’.",
  "Record": "His instruction of 2026-10-30 · ‘moneykeel_pres_mock_brand-wordmark_v02.html’ · DEC-8891",
  "State": "In the code since 2026-10-30"
 },
 {
  "Ruled": "2026-10-31",
  "What changed, against the phones below": "Approved before: Cash flow v01, 2026-09-28 (DEC-0440: “Approved”). The budget editor is not drawn; its lines of 2026-10-24, 10-25 and 10-27 describe it. His feedback: His words, 2026-10-27 (DEC-8839): “the standard design says box titles in dark green bar, and sub-titles in light green bar”; and 2026-08-04 (DEC-0059): “make sure font size and color and overall design are same across all screens.” New: the editor’s card stands under the bar This month’s planned card carries — ‘PLANNED · AUGUST +$350’ in frame A’s household — because the sheet’s own title already reads ‘Your budget’ and the card says it once (the 2026-10-25 line); this corrects ‘YOUR BUDGET’ in the 2026-10-27 line on bars. Its ‘= Planned surplus +$350’ is printed as This month prints it, 15 points weight 800 in the gain green #006300 (it was 20 points weight 700 in the brand green #178F6B, which is kept for buttons and the picked tab), and ‘$300 left · of $2,000 plan’ is in the gain green too, red when over (2,000 − 500 − 1,200 = 300). With the register household’s $2,300 Rent / Mortgage line beside a mortgage on no property, the card says what This month says, under ‘− Expenses (plan) $1,100’: ‘Your Rent / Mortgage budget line is not counted here: your mortgage, Mortgage, is in Debts and is counted from there. Place it on your home in Net worth, so we know they are the same.’ (the $2,300 left the plan with nothing said; the 2026-10-25 line on a debt counted once names this editor). DEBT THIS MONTH writes ‘$2,000/month min’ with no space before /month, as Debts does (it read ‘$2,000 /month min’).",
  "His words, or where it came from": "Not a decision of his: the lead’s round-3 items CF3-01, CF3-02, CF3-03 and CF3-08 (2026-10-31), made under his words above without asking him; under DEC-9228 he judges the built screens on TestFlight. Tenets 1 and 4 (DEC-3523). To reverse: the ‘YOUR BUDGET’ bar, the brand green at 20, no sentence, and the space before /month.",
  "Record": "DEC-8839 · DEC-0059 · DEC-1923 · DEC-3523 (tenets 1, 4) · MK-CF-M-002 · MK-CF-M-056 · MK-NW-M-011",
  "State": "In the code since 2026-10-31 — row written before the code"
 },
 {
  "Ruled": "2026-10-31",
  "What changed, against the phones below": "Approved before: Cash flow v01, 2026-09-28 (DEC-0440: “Approved”). The expense sheet is not drawn; the 2026-10-27 lines title it ‘Log an expense’. His feedback: His words, 2026-08-20 (DEC-0296): “an unknown input produces no number and a reason — never a default”. New: the amount box opens empty — no grey ‘0’ inside it, which reads as an amount entered — and the button says the door’s own words: ‘Log an expense’ while nothing is typed, and ‘Log $6.50’ once $6.50 is (it read ‘Add expense’ and ‘Add $6.50’ under the title ‘Log an expense’). Canon row 27.",
  "His words, or where it came from": "Not a decision of his: the lead’s round-3 items CF3-04 and CF3-05 (2026-10-31), made under his words above without asking him; under DEC-9228 he judges the built screens on TestFlight. The lead’s ruling R16 (empty means empty) and tenet 4 (DEC-3523). To reverse: the grey ‘0’ and the words ‘Add expense’.",
  "Record": "DEC-0296 · DEC-3523 (tenet 4) · canon row 27",
  "State": "In the code since 2026-10-31 — row written before the code"
 },
 {
  "Ruled": "2026-10-31",
  "What changed, against the phones below": "Approved before: Cash flow v01, 2026-09-28 (DEC-0440: “Approved”). The budget editor’s sheets are not drawn. His feedback: His words, 2026-08-04 (DEC-0059): “make sure font size and color and overall design are same across all screens.” New: every sheet the budget editor opens is titled at the sheet-title size, 20 points weight 800 — ‘Monthly limits’, ‘New category’, ‘Log payment’, ‘Recurring’ and the add or edit sheet (they read 17 points weight 600). The words do not change.",
  "His words, or where it came from": "Not a decision of his: the lead’s round-3 item CF3-06 (2026-10-31), made under his words above without asking him; under DEC-9228 he judges the built screens on TestFlight. The sheet-title size is the lead’s DEC-8931 (2026-10-30). To reverse: the titles at 17/600.",
  "Record": "DEC-0059 · DEC-8931",
  "State": "In the code since 2026-10-31 — row written before the code"
 },
 {
  "Ruled": "2026-10-31",
  "What changed, against the phones below": "Approved before: Cash flow v01, 2026-09-28 (DEC-0440: “Approved”). The YOUR FUTURE PAYCHECK card is not drawn (its lines of 2026-10-25 to 10-27). His feedback: His words, 2026-08-04 (DEC-0059): “make sure font size and color and overall design are same across all screens.” New: its figure line reads ‘At 65 (ours until you change it): ~$10/month’ for the register household, with one space after the colon (it had two). No figure changes. (Corrected 2026-11-01: this row’s example read ‘At 67: ~$15/month’, which the row of 2026-10-31 below and the app replaced: with no retirement age entered the card retires the person at 65, the plan’s one age. CF4-07.)",
  "His words, or where it came from": "Not a decision of his: the lead’s round-3 item CF3-07 (2026-10-31), made under his words above without asking him; under DEC-9228 he judges the built screens on TestFlight. Tenet 4 (DEC-3523). To reverse: two spaces.",
  "Record": "DEC-0059 · MK-CF-M-022",
  "State": "In the code since 2026-10-31 — row written before the code"
 },
 {
  "Ruled": "2026-10-31",
  "What changed, against the phones below": "Approved before: Cash flow v01, 2026-09-28 (DEC-0440: “Approved”). It draws its four sub-tabs (This month · Income · Expenses · Debts) as 10-point words with a line under the picked one; the app built them as boxes 40 points tall. His feedback: None on the height of these choices. His standing rule is the 44-point tap (DEC-0141, 2026-08-13: a tap target raised to the 44-point minimum); and DEC-9228 (2026-10-31): he judges the built screens on TestFlight. New: the four sub-tab boxes are 44 points tall (Tap.min), their words centred; the words, the order and the picked tab’s mark do not change. The phones are not redrawn.",
  "His words, or where it came from": "One floor for every choice (tenet 4), held by src/__tests__/every_choice_is_44_points.test.tsx. Not a decision of his: the lead’s, made without asking him. To reverse: the boxes back to 40.",
  "Record": "DEC-0141 · DEC-9228 · NW3-16",
  "State": "In the code since 2026-10-31"
 },
 {
  "Ruled": "2026-11-01",
  "What changed, against the phones below": "CORRECTION of the 44-point row of 2026-10-31 above: it said the drawing draws the sub-tabs 40 points tall; the drawing draws them as words with a line under the picked one, and 40 was the built height. The row now says both.",
  "His words, or where it came from": "A drawing row must be true (found by FX-PLAN on Goals v03, 2026-11-01, and checked on every drawing FX-SHARED wrote on). The row had been written from the code’s styles, not from this drawing.",
  "Record": "NW3-16 · NW3-18",
  "State": "Row corrected 2026-11-01"
 },
 {
  "Ruled": "2026-10-31",
  "What changed, against the phones below": "YOUR FUTURE PAYCHECK (not drawn on this drawing; the card his ruling of 2026-09-08 keeps): with no retirement age entered, the card states the age the plan retires you at, 65, and says it is ours: ‘At 65 (ours until you change it): ~$X/month’ . It read ‘At 67’ — the card’s own fallback, while the odds beside it retire the person at 65 — so the two figures on one card stood on two ages. With an age entered the line is unchanged (‘At 67: ~$X/month’ for a person who typed 67). Line added 2026-10-31, before the code.",
  "His words, or where it came from": "The lead’s ruling R10 of 2026-10-31, made without asking him, under tenet 2 (DEC-3523): one age for the plan, read by one function (planRetireAgeOf). One word from him reverses it. To reverse: ‘67’ and no mark.",
  "Record": "R10 · NW3-01 · MK-CF-M-022 · DEC-3523",
  "State": "Drawn 2026-10-31, before the code"
 },
 {
  "Ruled": "2026-10-31",
  "What changed, against the phones below": "Approved before: Cash flow v01, 2026-09-28 (DEC-0440: “Approved”). The expense and split sheets (not drawn) used a handle 40 by 4 in the border grey. His feedback: None on the sheets’ frame. He approved Net worth v08, frames A to G, on 2026-10-01 (DEC-0644: “Quite Instrument v08 - approved all screens from A to G”), whose sheets have corners of 24 and a handle 36 by 4 in the light grey; and DEC-9228 (2026-10-31): he judges the built screens on TestFlight. New: the sheet takes the app’s one sheet frame: grey #F6F7F5, top corners 24, a handle 36 by 4 points in #EEEEE9 with 10 points below it. What is on the sheet does not change. The phones are not redrawn.",
  "His words, or where it came from": "One sheet frame (tenet 4, DEC-3523; NW3-18): every sheet takes SHEET_FRAME and SHEET_HANDLE (src/components/sheetFrame.ts), held by src/__tests__/one_sheet_frame.test.tsx. Not a decision of his: the lead’s, made without asking him, as his order of 2026-09-30 says. To reverse: each sheet back to its own frame.",
  "Record": "DEC-0644 · DEC-9228 · NW3-18",
  "State": "In the code since 2026-10-31"
 },
 {
  "Ruled": "2026-11-01",
  "What changed, against the phones below": "Approved before: Cash flow v01, 2026-09-28 (DEC-0440: “Approved”); Debts is frame 6, and its payoff plan is kept by DEC-1560. The two sections below were drawn on Goals (plan/moneykeel_pres_mock_goals_v01.html, from the build), which Goals v03 (2026-10-31) moves to Cash flow, under Debts. His feedback: His words, 2026-10-04 (DEC-1560): “Rest - keep it.”; and 2026-09-30 (DEC-0641): “Q53 - what actually leaves.” — the record of that decision keeps the minimum for debt-to-income, ‘because debt-to-income is measured on the obligation and not on what someone chooses to pay’. New: Debts carries, under PROGRESS, two boxes each on its dark-green bar, with the figures and words the Goals screen printed, unchanged. DEBT-TO-INCOME — what the debts oblige each month against income before tax, measured on the minimums (DEC-0641), never what someone chooses to pay: frame 6’s household, $110 + $300 = $410 of minimums on $60,000 a year ($5,000 a month), reads ‘8.20%’ · ‘Healthy’ · ‘$410/month in minimum debt payments ÷ $5,000/month income’ · ‘Aim for 20% or less (renters; rent isn’t counted). You’re in good shape.’ (410 ÷ 5,000 = 8.20%; a household with a mortgage is measured against 36%). With no income entered the box says ‘Your income is not entered, so there is no debt-to-income figure — we won’t guess one.’ STUDENT LOAN OUTLOOK — only when a student loan is entered in setup: $30,000 at 5.50% over 10 years reads ‘$30,000 borrowed’ · ‘≈ $326/month once you’re repaying · $9,069 total interest’ · ‘That’s ~6.51% of today’s income — keeping total debt under 20% keeps you comfortable.’ (30,000 × 0.4583% ÷ (1 − 1.004583^−120) = $325.58; 120 × 325.58 − 30,000 = $9,069.46; 325.58 ÷ 5,000 = 6.51%). A loan with no rate or term reads ‘Add an interest rate and term to each loan (in setup) to see the monthly repayment.’ A door that opens Cash flow on Debts — Goals’ ‘Your debts … are on Cash flow, under Debts ›’ — lands on the Debts tab, not on This month. A screen reader hears the corner button as ‘Log an expense from any tab’, so it is never taken for the Expenses tab’s own ‘Log an expense’ door. The phones are not redrawn.",
  "His words, or where it came from": "Not a decision of his: the lead’s ruling of 2026-11-01 (a feature reachable from nowhere once Goals v03 sent every Goals door to Plan · Goals), applied without asking him; under DEC-9228 he judges the built screens on TestFlight. The functions are the ones the Goals screen ran, unchanged: MK-CF-F-033 debtToIncome on MK-CF-F-025 minimumDebtService, and MK-CF-F-028 loanPayment. To reverse: take the two boxes off Debts and open Cash flow on This month.",
  "Record": "DEC-0641 · DEC-1560 · DEC-8839 · MK-CF-F-033 · MK-CF-F-025 · MK-CF-F-028 · MK-CF-M-102 to MK-CF-M-108 (new)",
  "State": "In the code since 2026-11-01 — row written before the code"
 },
 {
  "Ruled": "2026-11-01",
  "What changed, against the phones below": "Approved before: Cash flow v01, 2026-09-28 (DEC-0440: “Approved”). Every phone draws the top bar’s ‘Menu’ button with its words 11 points in from each side. The account page’s drawing, approved 2026-10-19 (DEC-6457), the newest approved drawing with this bar, draws them 13 points in. His feedback: None on the button’s inset. His words on which drawing holds: “If I approved mock up post build - that the latest approval.” (DEC-0808, 2026-09-27). New: DRAWING ERROR, every phone — the button’s words sit 13 points in from each side, as the account page’s drawing draws them and the app draws them; this drawing’s 11 is 2 points short on each side. Its words, height, corner and colours do not change. The phones are not redrawn. Line added 2026-11-01.",
  "His words, or where it came from": "The top bar is the one bar every screen carries (DEC-0354), and its ‘Menu’ and ‘‹ Back’ buttons share one style (src/components/TopBar.tsx, menuBtn). No row named the inset until the drawing match of 2026-10-31 (NW3-14, on Net worth v08). The lead’s reading under DEC-4529: the drawing is left, a dated line corrects it. To reverse: the buttons’ side inset set to 11 in menuBtn, and this line removed.",
  "Record": "DEC-0440 · DEC-6457 · DEC-0354 · DEC-0808 · DEC-4529 · NW3-14",
  "State": "Drawing corrected by this line — the app already shows it"
 },
 {
  "Ruled": "2026-11-01",
  "What changed, against the phones below": "Approved before: Cash flow v01, 2026-09-28 (DEC-0440: “Approved”). No phone draws these three boxes empty: Debts’ ‘Extra / month’, the ‘Log payment’ sheet’s ‘Amount’, and the ‘Amount’ on the ‘Log an expense’ sheet and on the income sheet’s ‘Add income’ tab. (Corrected 2026-11-01: this called the first ‘Add expense’; the rows of 2026-10-27 and 2026-10-31 above and the app title it ‘Log an expense’. CF4-08.) His feedback: His words, 2026-08-20 (DEC-0296): “an unknown input produces no number and a reason — never a default”; 2026-10-31 (DEC-9228): “I will review the screens in testflight”. New: each of the three boxes opens empty, with no grey ‘0’ in it; the ‘$’ beside it stays. The two sheet boxes that had no name of their own are named ‘Amount’, the word above them, so a screen reader no longer reads the grey ‘0’ as the name. Nothing else moves. The phones are not redrawn.",
  "His words, or where it came from": "Empty means empty (the lead’s ruling R16 of 2026-10-31, under DEC-0296 and tenet 3, DEC-3523: unknown is not zero): a box nobody filled shows no figure that could be read as an entry. Not a decision of his: the lead’s, made without asking him, as his order of 2026-09-30 says. To reverse: the grey ‘0’ in the empty boxes again. Row written before the code.",
  "Record": "DEC-0296 · DEC-3523 · DEC-9228 · R16",
  "State": "In the code since 2026-11-01"
 },
 {
  "Ruled": "2026-11-01",
  "What changed, against the phones below": "Approved before: Cash flow v01, 2026-09-28 (DEC-0440: “Approved”). No phone draws the allocation boxes of the money sheets empty. His feedback: His words, 2026-08-20 (DEC-0296): “an unknown input produces no number and a reason — never a default”; 2026-10-31 (DEC-9228): “I will review the screens in testflight”. New: the money sheets’ allocation boxes open empty — the grey ‘$0’ and ‘0%’ are gone; the ‘%’ or ‘$’ unit beside a box stays. Nothing else moves. The phones are not redrawn.",
  "His words, or where it came from": "Empty means empty (the lead’s ruling R16 of 2026-10-31, under DEC-0296 and tenet 3, DEC-3523: unknown is not zero): a box nobody filled shows no figure that could be read as an entry. Not a decision of his: the lead’s, made without asking him, as his order of 2026-09-30 says. To reverse: the grey examples in the empty boxes again. Row written before the code.",
  "Record": "DEC-0296 · DEC-3523 · DEC-9228 · R16",
  "State": "In the code since 2026-11-01"
 },
 {
  "Ruled": "2026-11-01",
  "What changed, against the phones below": "Approved before: Cash flow v01, 2026-09-28 (DEC-0440: “Approved”); Debts is frame 6. The DEBT-TO-INCOME and STUDENT LOAN OUTLOOK boxes are the 2026-11-01 line’s, not drawn on a phone. His feedback: His words, 2026-08-20 (DEC-0296): “an unknown input produces no number and a reason — never a default”. New: (1) The sum in DEBT-TO-INCOME works as printed: the minimum payments are a payment, written to the cent, so a $386.42 minimum reads ‘$386.42/month in minimum debt payments ÷ $5,000/month income’ beside ‘7.73%’ (386.42 ÷ 5,000 = 7.7284%; it read ‘$386’, and 386 ÷ 5,000 = 7.72%). Frame 6’s household reads ‘$410.00/month …’ beside ‘8.20%’; this corrects ‘$410/month’ in the 2026-11-01 line. (2) The approximately mark is written one way, against the figure, ‘≈$326/month’, as the 2026-10-25 line on ≈ and 40 of the 45 marks on the live drawings write it (it read ‘≈ $326/month’, and the 2026-11-01 line wrote it so too, which this corrects). (3) A student loan entered in setup is a debt: YOUR DEBT counts it, and never says ‘Nothing entered yet’ above it. With only a $30,000 setup loan, YOUR DEBT reads ‘$30,000’ and under it ‘Includes $30,000 of student loans entered in setup — repayment starts after you graduate.’ (it read ‘$0 · Nothing entered yet. Add your debts ›’ above ‘$30,000 borrowed’). With a $3,200 Visa and a $9,800 car loan beside it: 3,200 + 9,800 + 30,000 = $43,000. (4) A YOUR DEBT of $0 is printed in the grey this drawing gives a $0 with nothing behind it (frame A’s ‘Car loan due 28th $0’, #6B6B66), never in the brand green #178F6B, which is for buttons and the picked tab; a debt above $0 stays red, as drawn. The phones are not redrawn.",
  "His words, or where it came from": "Not a decision of his: the lead’s rulings R21 (a printed sum works as printed) and R22 (one debt total), and round-4 items CF4-02 and CF4-04, made under his words above and tenets 1, 2 and 4 (DEC-3523) without asking him; under DEC-9228 he judges the built screen on TestFlight. To reverse: the payment in whole dollars, ‘≈ ’ with a space, the setup loan left out of YOUR DEBT, and $0 in brand green.",
  "Record": "DEC-0296 · DEC-3523 (tenets 1, 2, 4) · Q49 · MK-CF-M-103 · MK-CF-M-106 · MK-NW-M-009",
  "State": "In the code since 2026-11-01 — row written before the code"
 },
 {
  "Ruled": "2026-11-01",
  "What changed, against the phones below": "Not a drawn state: A student loan entered in setup is owed from the month it is first paid out. One whose first month is still ahead is not owed today: it is not counted in DEBTS on Net worth or YOUR DEBT on Debts, and the screen says so in words — ‘A $30,000 student loan starts in Sep 2027, not counted until then.’ From Sep 2027 it counts. A loan entered with no month counts as owed today, and the screen says ‘The $30,000 student loan has no start month entered, so it counts as owed today.’ Example, on Nov 1, 2026: a $30,000 loan starting Sep 2027, a $3,200 Visa and a $9,800 car loan give DEBTS −$13,000 on Net worth and YOUR DEBT $13,000 on Debts (3,200 + 9,800); the same loan first paid out in Sep 2026 gives $43,000 on both. The phones are not redrawn. Line added 2026-11-01.",
  "His words, or where it came from": "Nothing is owed before the money is lent (the lead’s ruling R22a of 2026-11-01, tenet 2, DEC-3523). One rule for both screens: setupStudentLoans and setupLoanDebts (src/domain/debt). Held by src/screens/__tests__/one_debt_total_r22_2026_11_01.test.tsx. Not a decision of his. To reverse: count every setup loan from the day it is entered.",
  "Record": "R22a · R22 · MK-NW-M-009 · DEC-3523",
  "State": "Drawn 2026-11-01, before the code"
 },
 {
  "Ruled": "2026-11-01",
  "What changed, against the phones below": "Approved before: Cash flow v01, 2026-09-28 (DEC-0440: “Approved”). It draws ‘Steer it’, ‘Why this order?’, ‘Show all’ and ‘Import a statement’ at the size of their words, under 44 points tall to the touch. His feedback: None on these taps. His standing rule is the 44-point tap (DEC-0141, 2026-08-13: a tap target raised to the 44-point minimum); and DEC-9228 (2026-10-31): he judges the built screens on TestFlight. New: each keeps its drawn size, words and place and takes a touch area 16 points above and below it (Tap.slop), so a finger lands on it across at least 44 points; that does not show on the phone. Nothing on the phones moves. The phones are not redrawn. Line added 2026-11-01.",
  "His words, or where it came from": "One floor for every tap (tenet 4, DEC-3523): Tap.slop, held by src/__tests__/every_choice_is_44_points.test.tsx, whose count of short lines and links in the app is now 0 of 488 (99 that morning, FX-NW’s count, NW4-04). Not a decision of his: the lead’s, made without asking him, as his order of 2026-09-30 says. To reverse: take hitSlop={Tap.slop} off each of these buttons.",
  "Record": "DEC-0440 · DEC-0141 · DEC-9228 · DEC-3523 · NW4-04 · NW3-16 · NW3-17",
  "State": "In the code since 2026-11-01 — row written after the code"
 }
]
```

Its phones that hold the screens in this part (1, 2, 3, 4, 5, 6), every line in order, as the match tests read them.

```json
{
 "phone 1": [
  "Cash flow",
  "August 2026",
  "‹",
  "August 2026",
  "›",
  "This month",
  "Income",
  "Expenses",
  "Debts",
  "Planned · August",
  "+$350",
  "Inflow (income (take-home))",
  "after tax and 401(k)",
  "$5,000",
  "Mortgage",
  "debt",
  "−$2,000",
  "Car loan",
  "debt",
  "−$250",
  "Expenses",
  "your budget",
  "−$2,000",
  "HELOC",
  "from big-ticket radar",
  "−$200",
  "Credit card debt payment",
  "from big-ticket radar",
  "−$200",
  "= Planned surplus",
  "+$350",
  "Actual · so far",
  "+$900",
  "Actual inflow (income (take-home))",
  "$5,000",
  "Mortgage",
  "paid",
  "−$2,000",
  "Car loan",
  "due 28th",
  "$0",
  "Expenses entered by hand",
  "−$500",
  "Expenses imported from your card",
  "imported",
  "−$1,200",
  "HELOC",
  "from big-ticket radar",
  "−$200",
  "Credit card debt payment",
  "from big-ticket radar",
  "−$200",
  "= Actual surplus so far",
  "+$900"
 ],
 "phone 2": [
  "Cash flow",
  "August 2026",
  "‹",
  "August 2026",
  "›",
  "This month",
  "Income",
  "Expenses",
  "Debts",
  "Planned · August",
  "—",
  "Inflow (income (take-home))",
  "$5,000",
  "Mortgage",
  "debt",
  "−$2,000",
  "Car loan",
  "debt",
  "−$250",
  "Expenses",
  "— not set",
  "Your debts are here, but you haven’t set your budget. Until you do there is no planned surplus — we won’t guess one.",
  "Set your budget",
  "Actual · so far",
  "+$3,000",
  "Actual inflow (income (take-home))",
  "$5,000",
  "Mortgage",
  "paid",
  "−$2,000",
  "Car loan",
  "due 28th",
  "$0",
  "Expenses entered by hand",
  "$0",
  "= Actual surplus so far",
  "+$3,000",
  "Nothing logged yet, and no card connected. Connect a card and your purchases arrive here on their own."
 ],
 "phone 3": [
  "Cash flow",
  "August 2026",
  "‹",
  "August 2026",
  "›",
  "This month",
  "Income",
  "Expenses",
  "Debts",
  "Monthly recurring expenses",
  "$2,250",
  "Mortgage",
  "same every month",
  "$2,000",
  "Car loan",
  "same every month",
  "$250",
  "Planned expenses",
  "$2,000",
  "Gas",
  "$200",
  "Grocery",
  "$900",
  "Utilities",
  "$200",
  "Other",
  "$700",
  "= Total",
  "$2,000",
  "Actual expenses",
  "$2,100",
  "Entered by hand",
  "$500",
  "18 Aug · Amazon",
  "Other · typed",
  "$100",
  "16 Aug · Trader Joe’s",
  "Grocery · receipt",
  "$65",
  "14 Aug · Shell",
  "Gas · typed",
  "$60",
  "11 Aug · CVS",
  "Other · receipt",
  "$42",
  "9 Aug · Starbucks",
  "Other · receipt",
  "$38",
  "Show all 9 · $195 more ›",
  "7 Aug · Costco",
  "Grocery · receipt",
  "$88",
  "6 Aug · Chevron",
  "Gas · typed",
  "$55",
  "4 Aug · Walgreens",
  "Other · receipt",
  "$30",
  "2 Aug · PG&E",
  "Utilities · typed",
  "$22",
  "= Entered by hand · 9 items",
  "$500",
  "Imported from your card",
  "$1,200",
  "19 Aug · Target",
  "Other",
  "$15",
  "16 Aug · Home Depot",
  "Other",
  "$315",
  "11 Aug · Chevron",
  "Gas",
  "$70",
  "8 Aug · Local Kitchen",
  "Other",
  "$95",
  "3 Aug · Whole Foods",
  "Grocery",
  "$145",
  "Show all 23 · $560 more ›",
  "2 Aug · Safeway",
  "Grocery",
  "$120",
  "2 Aug · Netflix",
  "Other",
  "$18",
  "… 16 more purchases",
  "$422",
  "= Imported · 23 purchases",
  "$1,200",
  "Debt payments counted as expenses",
  "$400",
  "HELOC payment",
  "entered on the Debts tab",
  "$200",
  "Credit card debt payment",
  "entered on the Debts tab",
  "$200",
  "= Actual expenses, all sources",
  "$2,100",
  "Big-ticket radar",
  "Credit card debt payment",
  "debt",
  "connected card · NOT counted as an expense — the $1,200 of purchases is",
  "$1,200",
  "HELOC payment",
  "debt",
  "entered on the Debts tab · counted as an expense",
  "$200",
  "Credit card debt payment",
  "debt",
  "entered on the Debts tab · counted as an expense — no receipts to match it to",
  "$200",
  "Your mortgage and car loan never appear here. They are the same every month, and a warning you see every month stops being a warning."
 ],
 "phone 4": [
  "Cash flow",
  "August 2026",
  "‹",
  "August 2026",
  "›",
  "This month",
  "Income",
  "Expenses",
  "Debts",
  "Monthly recurring expenses",
  "$2,250",
  "Mortgage",
  "$2,000",
  "Car loan",
  "$250",
  "Planned expenses",
  "—",
  "You haven’t set your budget yet. This is what every “of $X planned” on any screen is measured against.",
  "Set your budget",
  "Actual expenses",
  "$0",
  "Nothing logged this month. Connect a card and purchases arrive on their own, or add a receipt by hand.",
  "Log an expense",
  "Big-ticket radar",
  "Nothing unusual. Regular debt payments never appear here — only a card or HELOC payment, or a bill well above its usual size."
 ],
 "phone 5": [
  "Cash flow",
  "August 2026",
  "‹",
  "August 2026",
  "›",
  "This month",
  "Income",
  "Expenses",
  "Debts",
  "THIS MONTH",
  "$6,200",
  "expected take-home",
  "YOUR SOURCES",
  "Salary — steady",
  "take-home · monthly",
  "$6,200 ›",
  "Rental income",
  "2 properties",
  "$0 ›",
  "Equity comp",
  "RSU grants",
  "— ›",
  "Add your income ›",
  "opens the steady-or-varies pop-up — variable earners fine-tune month by month",
  "RECEIVED THIS MONTH",
  "Aug 15 · Paycheck",
  "+$3,100",
  "Aug 1 · Paycheck",
  "+$3,100"
 ],
 "phone 6": [
  "Cash flow",
  "August 2026",
  "‹",
  "August 2026",
  "›",
  "This month",
  "Income",
  "Expenses",
  "Debts",
  "YOUR DEBT",
  "$13,000",
  "across 2 debts · $310/month in payments",
  "YOUR DEBTS",
  "Visa card",
  "pay first",
  "22.90% — the costliest",
  "−$3,200 ›",
  "Car loan",
  "6.40% · 3 years left",
  "−$9,800 ›",
  "Log a payment ›",
  "PROGRESS",
  "$4,100 paid down since January — 24% of where you started"
 ]
}
```

The same phones as the match test holds the screen to them: the drawn phone with each dated row and kept item applied by name — the test's own expected lines:

```json
{
 "phone 1 (frame A)": [
  "Cash flow",
  "August 2026",
  "‹",
  "August 2026",
  "›",
  "This month",
  "Income",
  "Expenses",
  "Debts",
  "Planned · August",
  "+$350",
  "Inflow (income (take-home))",
  "after tax and 401(k)",
  "$5,000",
  "Mortgage",
  "debt",
  "−$2,000",
  "Car loan",
  "debt",
  "−$250",
  "Expenses",
  "your budget",
  "−$2,000",
  "HELOC",
  "from big-ticket radar",
  "−$200",
  "Credit card debt payment",
  "from big-ticket radar",
  "−$200",
  "= Planned surplus",
  "+$350",
  "Actual · so far",
  "+$900",
  "Actual inflow (income (take-home))",
  "$5,000",
  "Mortgage",
  "paid",
  "−$2,000",
  "Car loan",
  "due 28th",
  "$0",
  "Expenses entered by hand",
  "−$500",
  "Expenses imported from your card",
  "imported",
  "−$1,200",
  "HELOC",
  "from big-ticket radar",
  "−$200",
  "Credit card debt payment",
  "from big-ticket radar",
  "−$200",
  "= Actual surplus so far",
  "+$900",
  "＋ Expense"
 ],
 "phone 2 (frame B)": [
  "Cash flow",
  "August 2026",
  "‹",
  "August 2026",
  "›",
  "This month",
  "Income",
  "Expenses",
  "Debts",
  "Planned · August",
  "—",
  "Inflow (income (take-home))",
  "$5,000",
  "Mortgage",
  "debt",
  "−$2,000",
  "Car loan",
  "debt",
  "−$250",
  "Expenses",
  "— not set",
  "Your debts are here, but you haven’t set your budget. Until you do there is no planned surplus — we won’t guess one.",
  "Set your budget",
  "Actual · so far",
  "+$3,000",
  "Actual inflow (income (take-home))",
  "$5,000",
  "Mortgage",
  "paid",
  "−$2,000",
  "Car loan",
  "due 28th",
  "$0",
  "Expenses entered by hand",
  "$0",
  "= Actual surplus so far",
  "+$3,000",
  "Nothing logged yet, and no card connected. Connect a card and your purchases arrive here on their own.",
  "＋ Expense"
 ],
 "phone 3 (frame C)": [
  "Cash flow",
  "August 2026",
  "‹",
  "August 2026",
  "›",
  "This month",
  "Income",
  "Expenses",
  "Debts",
  "Monthly recurring expenses",
  "$2,250",
  "Mortgage",
  "same every month",
  "$2,000",
  "Car loan",
  "same every month",
  "$250",
  "Planned expenses",
  "$2,000",
  "Gas",
  "$200",
  "Grocery",
  "$900",
  "Utilities",
  "$200",
  "Other",
  "$700",
  "= Total",
  "$2,000",
  "Actual expenses",
  "$2,100.00",
  "Entered by hand",
  "$500.00",
  "18 Aug · Amazon",
  "Other · typed",
  "$100.00",
  "16 Aug · Trader Joe’s",
  "Grocery · receipt",
  "$65.00",
  "14 Aug · Shell",
  "Gas · typed",
  "$60.00",
  "11 Aug · CVS",
  "Other · receipt",
  "$42.00",
  "9 Aug · Starbucks",
  "Other · receipt",
  "$38.00",
  "Show all 9 · $195.00 more ›",
  "= Entered by hand · 9 items",
  "$500.00",
  "Imported from your card",
  "$1,200.00",
  "19 Aug · Target",
  "Other",
  "$15.00",
  "16 Aug · Home Depot",
  "Other",
  "$315.00",
  "11 Aug · Chevron",
  "Gas",
  "$70.00",
  "8 Aug · Local Kitchen",
  "Other",
  "$95.00",
  "3 Aug · Whole Foods",
  "Grocery",
  "$145.00",
  "Show all 23 · $560.00 more ›",
  "= Imported · 23 purchases",
  "$1,200.00",
  "Debt payments counted as expenses",
  "$400.00",
  "HELOC payment",
  "entered on the Debts tab",
  "$200.00",
  "Credit card debt payment",
  "entered on the Debts tab",
  "$200.00",
  "= Actual expenses, all sources",
  "$2,100.00",
  "Big-ticket radar",
  "HELOC payment",
  "debt",
  "entered on the Debts tab · counted as an expense",
  "$200.00",
  "Credit card debt payment",
  "debt",
  "entered on the Debts tab · counted as an expense — no receipts to match it to",
  "$200.00",
  "Your mortgage and car loan never appear here. They are the same every month, and a warning you see every month stops being a warning.",
  "Import a statement ›",
  "＋ Expense"
 ],
 "phone 4 (frame D)": [
  "Cash flow",
  "August 2026",
  "‹",
  "August 2026",
  "›",
  "This month",
  "Income",
  "Expenses",
  "Debts",
  "Monthly recurring expenses",
  "$2,250",
  "Mortgage",
  "$2,000",
  "Car loan",
  "$250",
  "Planned expenses",
  "—",
  "You haven’t set your budget yet. This is what every “of $X planned” on any screen is measured against.",
  "Set your budget",
  "Actual expenses",
  "$0.00",
  "Nothing logged this month. Connect a card and purchases arrive on their own, or add a receipt by hand.",
  "Log an expense",
  "Big-ticket radar",
  "Nothing unusual. Regular debt payments never appear here — only a card or HELOC payment, or a bill well above its usual size.",
  "Import a statement ›",
  "＋ Expense"
 ],
 "phone 5 (frame E)": [
  "Cash flow",
  "August 2026",
  "‹",
  "August 2026",
  "›",
  "This month",
  "Income",
  "Expenses",
  "Debts",
  "THIS MONTH",
  "$6,200",
  "expected take-home",
  "YOUR SOURCES",
  "Salary — steady",
  "take-home · monthly",
  "$6,200 ›",
  "Rental income",
  "2 properties",
  "$0 ›",
  "Equity comp",
  "RSU grants",
  "— ›",
  "Add your income ›",
  "RECEIVED THIS MONTH",
  "Aug 15 · Paycheck",
  "+$3,100.00",
  "Aug 1 · Paycheck",
  "+$3,100.00",
  "Your income, all of it",
  "the take-home, and what it is taxed on",
  "Open ›",
  "＋ Expense"
 ],
 "phone 6 (frame F)": [
  "Cash flow",
  "August 2026",
  "‹",
  "August 2026",
  "›",
  "This month",
  "Income",
  "Expenses",
  "Debts",
  "YOUR DEBT",
  "$13,000",
  "across 2 debts · $410/month in payments",
  "PAYOFF PLAN",
  "Avalanche",
  "Snowball",
  "Highest interest rate first — saves the most interest.",
  "Extra / month",
  "$",
  "<the month it ends>",
  "debt-free",
  "$410",
  "/month total",
  "<its interest>",
  "total interest",
  "YOUR DEBTS",
  "Visa card",
  "pay first",
  "22.90% — the costliest · $110/month min · ~$61/month interest",
  "−$3,200 ›",
  "Car loan",
  "6.40% · 3 years left · $300/month min · ~$52/month interest",
  "−$9,800 ›",
  "Log a payment ›",
  "+ Add debt account",
  "PROGRESS",
  "$4,100 paid down since January — 24% of where you started",
  "DEBT-TO-INCOME",
  "8.20%",
  "Healthy",
  "$410.00/month in minimum debt payments ÷ $5,000/month income",
  "Aim for 20% or less (renters; rent isn’t counted). You’re in good shape.",
  "＋ Expense"
 ]
}
```

And the screen rendered in the drawing's own household on the drawing's own day, as that test renders it:

```json
{
 "phone 1 (frame A)": {
  "phone": 1,
  "day": "2026-08-20",
  "tab": null,
  "lines": [
   "Cash flow",
   "August 2026",
   "‹",
   "August 2026",
   "›",
   "This month",
   "Income",
   "Expenses",
   "Debts",
   "PLANNED · AUGUST",
   "+$350",
   "Inflow (income (take-home))",
   "after tax and 401(k)",
   "$5,000",
   "Mortgage",
   "debt",
   "−$2,000",
   "Car loan",
   "debt",
   "−$250",
   "Expenses",
   "your budget",
   "−$2,000",
   "HELOC",
   "from big-ticket radar",
   "−$200",
   "Credit card debt payment",
   "from big-ticket radar",
   "−$200",
   "= Planned surplus",
   "+$350",
   "ACTUAL · SO FAR",
   "+$900",
   "Actual inflow (income (take-home))",
   "$5,000",
   "Mortgage",
   "paid",
   "−$2,000",
   "Car loan",
   "due 28th",
   "$0",
   "Expenses entered by hand",
   "−$500",
   "Expenses imported from your card",
   "imported",
   "−$1,200",
   "HELOC",
   "from big-ticket radar",
   "−$200",
   "Credit card debt payment",
   "from big-ticket radar",
   "−$200",
   "= Actual surplus so far",
   "+$900",
   "＋ Expense"
  ]
 },
 "phone 2 (frame B)": {
  "phone": 2,
  "day": "2026-08-20",
  "tab": null,
  "lines": [
   "Cash flow",
   "August 2026",
   "‹",
   "August 2026",
   "›",
   "This month",
   "Income",
   "Expenses",
   "Debts",
   "PLANNED · AUGUST",
   "—",
   "Inflow (income (take-home))",
   "$5,000",
   "Mortgage",
   "debt",
   "−$2,000",
   "Car loan",
   "debt",
   "−$250",
   "Expenses",
   "— not set",
   "Your debts are here, but you haven’t set your budget. Until you do there is no planned surplus — we won’t guess one.",
   "Set your budget",
   "ACTUAL · SO FAR",
   "+$3,000",
   "Actual inflow (income (take-home))",
   "$5,000",
   "Mortgage",
   "paid",
   "−$2,000",
   "Car loan",
   "due 28th",
   "$0",
   "Expenses entered by hand",
   "$0",
   "= Actual surplus so far",
   "+$3,000",
   "Nothing logged yet, and no card connected. Connect a card and your purchases arrive here on their own.",
   "＋ Expense"
  ]
 },
 "phone 3 (frame C)": {
  "phone": 3,
  "day": "2026-08-20",
  "tab": "Expenses",
  "lines": [
   "Cash flow",
   "August 2026",
   "‹",
   "August 2026",
   "›",
   "This month",
   "Income",
   "Expenses",
   "Debts",
   "MONTHLY RECURRING EXPENSES",
   "$2,250",
   "Mortgage",
   "same every month",
   "$2,000",
   "Car loan",
   "same every month",
   "$250",
   "PLANNED EXPENSES",
   "$2,000",
   "Gas",
   "$200",
   "Grocery",
   "$900",
   "Utilities",
   "$200",
   "Other",
   "$700",
   "= Total",
   "$2,000",
   "ACTUAL EXPENSES",
   "$2,100.00",
   "ENTERED BY HAND",
   "$500.00",
   "18 Aug · Amazon",
   "Other · typed",
   "$100.00",
   "16 Aug · Trader Joe’s",
   "Grocery · receipt",
   "$65.00",
   "14 Aug · Shell",
   "Gas · typed",
   "$60.00",
   "11 Aug · CVS",
   "Other · receipt",
   "$42.00",
   "9 Aug · Starbucks",
   "Other · receipt",
   "$38.00",
   "Show all 9 · $195.00 more ›",
   "= Entered by hand · 9 items",
   "$500.00",
   "IMPORTED FROM YOUR CARD",
   "$1,200.00",
   "19 Aug · Target",
   "Other",
   "$15.00",
   "16 Aug · Home Depot",
   "Other",
   "$315.00",
   "11 Aug · Chevron",
   "Gas",
   "$70.00",
   "8 Aug · Local Kitchen",
   "Other",
   "$95.00",
   "3 Aug · Whole Foods",
   "Grocery",
   "$145.00",
   "Show all 23 · $560.00 more ›",
   "= Imported · 23 purchases",
   "$1,200.00",
   "DEBT PAYMENTS COUNTED AS EXPENSES",
   "$400.00",
   "HELOC payment",
   "entered on the Debts tab",
   "$200.00",
   "Credit card debt payment",
   "entered on the Debts tab",
   "$200.00",
   "= Actual expenses, all sources",
   "$2,100.00",
   "BIG-TICKET RADAR",
   "HELOC payment",
   "debt",
   "entered on the Debts tab · counted as an expense",
   "$200.00",
   "Credit card debt payment",
   "debt",
   "entered on the Debts tab · counted as an expense — no receipts to match it to",
   "$200.00",
   "Your mortgage and car loan never appear here. They are the same every month, and a warning you see every month stops being a warning.",
   "Import a statement ›",
   "＋ Expense"
  ]
 },
 "phone 4 (frame D)": {
  "phone": 4,
  "day": "2026-08-20",
  "tab": "Expenses",
  "lines": [
   "Cash flow",
   "August 2026",
   "‹",
   "August 2026",
   "›",
   "This month",
   "Income",
   "Expenses",
   "Debts",
   "MONTHLY RECURRING EXPENSES",
   "$2,250",
   "Mortgage",
   "$2,000",
   "Car loan",
   "$250",
   "PLANNED EXPENSES",
   "—",
   "You haven’t set your budget yet. This is what every “of $X planned” on any screen is measured against.",
   "Set your budget",
   "ACTUAL EXPENSES",
   "$0.00",
   "Nothing logged this month. Connect a card and purchases arrive on their own, or add a receipt by hand.",
   "Log an expense",
   "BIG-TICKET RADAR",
   "Nothing unusual. Regular debt payments never appear here — only a card or HELOC payment, or a bill well above its usual size.",
   "Import a statement ›",
   "＋ Expense"
  ]
 },
 "phone 5 (frame E)": {
  "phone": 5,
  "day": "2026-08-20",
  "tab": "Income",
  "lines": [
   "Cash flow",
   "August 2026",
   "‹",
   "August 2026",
   "›",
   "This month",
   "Income",
   "Expenses",
   "Debts",
   "THIS MONTH",
   "$6,200",
   "expected take-home",
   "YOUR SOURCES",
   "Salary — steady",
   "take-home · monthly",
   "$6,200 ›",
   "Rental income",
   "2 properties",
   "$0 ›",
   "Equity comp",
   "RSU grants",
   "— ›",
   "Add your income ›",
   "RECEIVED THIS MONTH",
   "Aug 15 · Paycheck",
   "+$3,100.00",
   "Aug 1 · Paycheck",
   "+$3,100.00",
   "Your income, all of it",
   "the take-home, and what it is taxed on",
   "Open ›",
   "＋ Expense"
  ]
 },
 "phone 6 (frame F)": {
  "phone": 6,
  "day": "2026-08-20",
  "tab": "Debts",
  "lines": [
   "Cash flow",
   "August 2026",
   "‹",
   "August 2026",
   "›",
   "This month",
   "Income",
   "Expenses",
   "Debts",
   "YOUR DEBT",
   "$13,000",
   "across 2 debts · $410/month in payments",
   "PAYOFF PLAN",
   "Avalanche",
   "Snowball",
   "Highest interest rate first — saves the most interest.",
   "Extra / month",
   "$",
   "Oct 2029",
   "debt-free",
   "$410",
   "/month total",
   "$2,476",
   "total interest",
   "YOUR DEBTS",
   "Visa card",
   "pay first",
   "22.90% — the costliest · $110/month min · ~$61/month interest",
   "−$3,200 ›",
   "Car loan",
   "6.40% · 3 years left · $300/month min · ~$52/month interest",
   "−$9,800 ›",
   "Log a payment ›",
   "+ Add debt account",
   "PROGRESS",
   "$4,100 paid down since January — 24% of where you started",
   "DEBT-TO-INCOME",
   "8.20%",
   "Healthy",
   "$410.00/month in minimum debt payments ÷ $5,000/month income",
   "Aim for 20% or less (renters; rent isn’t counted). You’re in good shape.",
   "＋ Expense"
  ]
 }
}
```

## The match tests — each test that holds one of these screens to a drawing phone, its code and its result at this build

**A · This month, with data — Planned +$350 and Actual so far +$900, every row deducted, figure for figure** — `src/screens/__tests__/cashflow_matches_v01.test.tsx`, lines 55–59, phones 1: **passed**

```ts
test('A · This month, with data — Planned +$350 and Actual so far +$900, every row deducted, figure for figure', () => {
  H.householdWithData();
  render(<CashFlowScreen />);
  check(H.AS_BUILT.A(), builtLines(screen.toJSON()), 40);
})
```

**B · This month, a fresh account — no budget, so no planned surplus and no guess; Actual so far +$3,000** — `src/screens/__tests__/cashflow_matches_v01.test.tsx`, lines 61–65, phones 2: **passed**

```ts
test('B · This month, a fresh account — no budget, so no planned surplus and no guess; Actual so far +$3,000', () => {
  H.householdFreshB();
  render(<CashFlowScreen />);
  check(H.AS_BUILT.B(), builtLines(screen.toJSON()), 40);
})
```

## The decisions these cases name — quoted from the decision log

```json
[
 {
  "id": "DEC-0002",
  "decided": "2026-07-19",
  "in_use": "IN USE",
  "whose": "his",
  "his_words": "cashflow. Approve.",
  "the_log_records": "Cash flow becomes ONE screen with four tabs, replacing the two separate Cash flow and Budget screens. Four decisions:\n1. The Budget screen is RETIRED; its job moves onto the cash-flow surface.\n2. Income is entered through a pop-up that asks whether your pay is steady or varies.\n3. You can move between past and future months.\n4. Big one-off bills get their own list, so a bill that lands once a year is not lost inside a monthly average.\nSTILL IN FORCE: his approval of the combined cash-flow mock (2026-09-28) carries this architecture forward by name — 'the four-tab architecture from v02'. Only the NAME of the third tab changed; see the row beside this one."
 },
 {
  "id": "DEC-0199",
  "decided": "2026-08-28",
  "in_use": "IN USE",
  "whose": "his",
  "his_words": "for a brokerage, an IRA and a 401(k) — so a check for",
  "the_log_records": "What each account pays you is worked out once, per account, with the working shown line by line — so the coupons you received are no longer ADDED to the coupons you were expecting."
 },
 {
  "id": "DEC-0200",
  "decided": "2026-08-28",
  "in_use": "IN USE",
  "whose": "his",
  "his_words": "takehome",
  "the_log_records": "When you type your take-home instead of your gross, it is converted ONCE on the way in and stored. The old code re-ran the tax schedule backwards on EVERY read to find a gross that would produce your figure — a guess laid on top of an estimate."
 },
 {
  "id": "DEC-0260",
  "decided": "2026-09-09",
  "in_use": "IN USE",
  "whose": "his",
  "his_words": "the screen shows $0 with a sentence explaining nothing is entered, and the door; the sentence approved; one mock of the pattern on one screen",
  "the_log_records": "“the screen shows $0 with a sentence explaining nothing is entered, and the door.” On a fresh account a screen keeps its shape, shows $0, says plainly that nothing is entered, and offers the way to enter it — rather than a blank space or a dash."
 },
 {
  "id": "DEC-0292",
  "decided": "2026-08-27",
  "in_use": "IN USE",
  "whose": "his",
  "his_words": "This-month screen, Planned: In (take-home) 5,000 · mortgage 2,000 · car 250 · expenses 2,000 · HELOC from the big-ticket radar 200 · credit-card payment entered by hand 200 · surplus 750. Actual: 5,000 · mortgage paid 2,000 · car paid 0 · expenses entered 500 · expenses imported from the card 1,200 · HELOC 200 · card payment 200 · surplus 1,300. Spending: recurring (mortgage 2,000, car 250), planned expenses (gas 200, grocery 900, utilities 200, other 700 = 2,000), radar: card payment 1,200 NOT counted as an expense, HELOC 200 counted, card payment entered by hand 200 counted.",
  "the_log_records": "A worked example of the This-month screen in his own numbers: take-home 5,000, mortgage 2,000, car 250, expenses 2,000, a HELOC payment of 200 from the big-ticket list and a 200 card payment entered by hand, leaving a surplus of 750 — with the actual column beside it. The rows have to add up to the surplus, which is what the example pins."
 },
 {
  "id": "DEC-0333",
  "decided": "2026-09-12",
  "in_use": "IN USE",
  "whose": "his",
  "his_words": "agree; ensure compliance with the synonym ruling",
  "the_log_records": "“agree; ensure compliance with the synonym ruling.” Agreed, with the condition that the change also obeys the one-word-per-concept rule."
 },
 {
  "id": "DEC-0345",
  "decided": "2026-09-13",
  "in_use": "IN USE",
  "whose": "his",
  "his_words": "inputs assembled once per family — one function builds the person's state for a family and every orchestrator in that family reads it; no orchestrator and no screen assembles its own",
  "the_log_records": "“inputs assembled once per family — one function builds the person’s state for a family and every orchestrator in that family reads it.” The data a group of screens needs is assembled once, so two screens in the same family cannot start from different inputs."
 },
 {
  "id": "DEC-0440",
  "decided": "2026-09-28",
  "in_use": "IN USE",
  "whose": "his",
  "his_words": "Approved",
  "the_log_records": "“Approved.” The cash-flow mocks become ONE file: moneykeel_pres_mock_cash-flow_v01.html. It carries the four-tab architecture from v02 together with the This month and Expenses screens as revised in v07, so there is no longer a choice between two half-current versions. v02 and v07 are dated and archived."
 },
 {
  "id": "DEC-0512",
  "decided": "2026-06-30",
  "in_use": "IN USE",
  "whose": "his",
  "his_words": "Are the month bars cash flows -- inflow / outflow?",
  "the_log_records": "HIS QUESTION: “Are the month bars cash flows — inflow / outflow?”"
 },
 {
  "id": "DEC-3523",
  "decided": "2026-10-09",
  "in_use": "IN USE",
  "whose": "his",
  "his_words": "tenets approved",
  "the_log_records": "The eight tenets are approved, in this order: 1. A wrong number ends trust. 2. Every number shows how it was made. 3. Unknown is not zero. 4. One thing, one number, one word. 5. The person's word outranks the app's guess. 6. His decision is the design. 7. Honest like a fiduciary. 8. Plain words for a reader of 55 to 70. When two pull against each other, the higher one wins."
 },
 {
  "id": "DEC-7606",
  "decided": "2026-10-23",
  "in_use": "IN USE",
  "whose": "the lead's decision under his rulings, recorded in his log — not his own",
  "his_words": "",
  "the_log_records": "NOT A DECISION OF HIS — the lead's decision of 2026-10-23 under his ruling DEC-3523 (tenet 3), made without asking him, as his order of 2026-09-30 says. A household with no income entered: Home's box read a red \"Over\" and Left $0; it now reads Income $0 · Nothing entered yet. Add your income › · Outflow (expenses + debt) $0 · Left —, with no pace word and no share spent, because the Cash flow tab draws no surplus then. With $500 logged and still no income, Left still reads —. To reverse: print $0 again. One word from him reverses it."
 },
 {
  "id": "DEC-7607",
  "decided": "2026-10-23",
  "in_use": "IN USE",
  "whose": "the lead's decision under his rulings, recorded in his log — not his own",
  "his_words": "",
  "the_log_records": "NOT A DECISION OF HIS — the lead's decision of 2026-10-23 under his rulings DEC-0440 and DEC-3523 (tenet 4), made without asking him, as his order of 2026-09-30 says. His approved drawing (DEC-0440, 2026-09-28) is newer than the 2026-08-28 words \"nothing is assumed to have arrived\", and the newest approval wins. With $500 recorded as received, Home read $7,700 against Cash flow's $7,200; both read $7,200. The row's formula now says, in plain words, that the inflow is the month's take-home. This settles screen check MK-CF-M-051#1, which was marked as needing a ruling. To reverse: count only recorded payments; both screens move together. One word from him reverses it."
 },
 {
  "id": "DEC-7609",
  "decided": "2026-10-23",
  "in_use": "IN USE",
  "whose": "the lead's decision under his rulings, recorded in his log — not his own",
  "his_words": "",
  "the_log_records": "NOT A DECISION OF HIS — the lead's decision of 2026-10-23 under his rulings DEC-0269 and DEC-0345, made without asking him, as his order of 2026-09-30 says. Worked September: Home's box label \"Actual expenses so far\" replaced by \"Outflow (expenses + debt)\". The box read Actual expenses so far $2,998 · Left $4,202; it now prints the Cash flow tab's month, Outflow (expenses + debt) $3,248 with the $250 car loan paid, Left $3,952 on both. Home's month-end sheet offers \"$3,952 of $3,952 left to assign\" (it offered $4,202). To reverse the label: put the old label back; the figures stay the Cash flow tab's. One word from him reverses it."
 },
 {
  "id": "DEC-7611",
  "decided": "2026-10-23",
  "in_use": "IN USE",
  "whose": "the lead's decision under his rulings, recorded in his log — not his own",
  "his_words": "",
  "the_log_records": "NOT A DECISION OF HIS — the lead's decision of 2026-10-23 under his rulings DEC-0002, DEC-0447 and DEC-0345, made without asking him, as his order of 2026-09-30 says. September with $700 of groceries and a $1,200 bill in December: This month −$700, the Expenses tab $700 (it read $800, with Once in a while $100), Home's September record $700. December: $1,900 on all three (Once in a while $1,200). A budget whose only line is the December bill reads $0 planned in September on both tabs — set, never \"You haven't set your budget yet\". A once-in-a-while bill with no month set is still a twelfth a month, as before. To reverse: build the Expenses tab's rows from the monthly average again. One word from him reverses it."
 },
 {
  "id": "DEC-7682",
  "decided": "2026-10-23",
  "in_use": "IN USE",
  "whose": "the lead's decision under his rulings, recorded in his log — not his own",
  "his_words": "",
  "the_log_records": "NOT A DECISION OF HIS — the lead's decision of 2026-10-23 under his rulings DEC-3523 (tenet 3) and DEC-0345, made without asking him, as his order of 2026-09-30 says. A car loan with no monthly payment entered, with a budget set: the band read \"+No budget set — …\" and the debt's row printed a sentence written for the master file. The row now reads \"payment not entered\" where the amount would be, the band reads —, and under the rows: \"Car loan's payment is not entered, so there is no planned surplus — we won't guess one.\" ACTUAL is unchanged. To reverse: give the debt's row and the surplus their earlier words. One word from him reverses it."
 },
 {
  "id": "DEC-7937",
  "decided": "2026-10-24",
  "in_use": "IN USE",
  "whose": "the lead's decision under his rulings, recorded in his log — not his own",
  "his_words": "",
  "the_log_records": "NOT A DECISION OF HIS — the lead's decision of 2026-10-24 under his rulings DEC-0264 and DEC-3523 (tenet 2), made without asking him, as his order of 2026-09-30 says. Frame A's household with a $6.50 coffee: the rows made $893 but the surplus read +$894, and Home's Left $894; both read +$893. The rows share the rounded total, each rounded down, the dollars still missing going to the rows with the most cents left over; a whole-dollar row never moves. It is the method the Performance walk already uses. The Bill calendar's rows do the same: each End is the balance rounded to the dollar, and In and Out share the change between two Ends — from $3,000, $5,415.83 in and $1,198.77 out read Sep +$5,416 · −$1,199 · $7,217. To reverse: round every row and every total on its own again. One word from him reverses it."
 },
 {
  "id": "DEC-7938",
  "decided": "2026-10-24",
  "in_use": "IN USE",
  "whose": "the lead's decision under his rulings, recorded in his log — not his own",
  "his_words": "",
  "the_log_records": "NOT A DECISION OF HIS — the lead's decision of 2026-10-24 under his rulings DEC-0283 and DEC-3523 (tenets 1 and 4), made without asking him, as his order of 2026-09-30 says. $9,000 a month with $1,000 into a 401(k), single: the months read $7,976 while Your base pay read $6,976; all read $6,976 (22%), then $7,403 filing jointly (12%) and $6,963 with $1,500 into the 401(k). A take-home typed as $6,200 reads $6,200 (it read $7,200). A rate the person gave is not laid on rent, and reinvested interest and dividends are not counted as arriving. Checked in 10 of 10 households against the Income summary. The drawing's own words already said after tax and 401(k). To reverse: take the tax off the wage and leave the 401(k) in. One word from him reverses it."
 },
 {
  "id": "DEC-7939",
  "decided": "2026-10-24",
  "in_use": "IN USE",
  "whose": "the lead's decision under his rulings, recorded in his log — not his own",
  "his_words": "",
  "the_log_records": "NOT A DECISION OF HIS — the lead's decision of 2026-10-24 under his rulings DEC-0002, DEC-0447, DEC-1923 and DEC-3523 (tenets 3 and 4), made without asking him, as his order of 2026-09-30 says. With nothing set the card read Expenses (plan) $0 and Planned surplus $2,350 beside This month's not set; it now reads — not set and no planned surplus. With a $1,200 bill in December, September's card reads without it (it read $100 a month of it), and a Rent / Mortgage line is not counted when the home's mortgage is in Debts. In the founder's fresh account: $1,200 set reads +$1,550, and Dining out $300 → $450 reads +$1,400, on the card, This month and Expenses alike. A screen reader names each limit box by its category (it heard No limit fifteen times). It amends DEC-7610, which kept the editor on the typical month. To reverse: give the card its own typical month again. One word from him reverses it."
 },
 {
  "id": "DEC-7946",
  "decided": "2026-10-24",
  "in_use": "IN USE",
  "whose": "the lead's decision under his rulings, recorded in his log — not his own",
  "his_words": "",
  "the_log_records": "NOT A DECISION OF HIS — the lead's decision of 2026-10-24 under his rulings DEC-0269 and DEC-3523 (tenets 1 and 3), made without asking him, as his order of 2026-09-30 says. September's band read SEPTEMBER 2026 — FINAL — WHAT ACTUALLY HAPPENED under a switcher already saying final; it reads \"SEPTEMBER 2026 — WHAT ACTUALLY HAPPENED\". November's card named the wrong bill, incl. Everyday expenses, and said Nothing entered yet with a budget entered; it reads \"Planned outflow (expenses + debt) $800\", names a dated bill only, and says nothing is entered only when the month plans $0. The words are those of the last drawing of that card, the archived this-month-and-spending v02. To reverse: give the band, the outflow line and the note their earlier words. One word from him reverses it."
 },
 {
  "id": "DEC-7949",
  "decided": "2026-10-24",
  "in_use": "IN USE",
  "whose": "the lead's decision under his rulings, recorded in his log — not his own",
  "his_words": "",
  "the_log_records": "NOT A DECISION OF HIS — the lead's decision of 2026-10-24 under his rulings DEC-3523 (tenets 1 and 4), made without asking him, as his order of 2026-09-30 says. A $150 grocery purchase dated Sep 25, imported on Oct 3, after September's record was saved: it was listed with nothing said, the card reading $1,510 and the list $1,360. The row now says, under its name, that it was added after September closed and is not in September's figures, and under the total that $150 of it was added after September closed. The card stays $1,510: a past month never changes under the person. To reverse: drop the two lines. One word from him reverses it."
 },
 {
  "id": "DEC-8084",
  "decided": "2026-10-24",
  "in_use": "IN USE",
  "whose": "the lead's decision under his rulings, recorded in his log — not his own",
  "his_words": "",
  "the_log_records": "NOT A DECISION OF HIS — the lead's decision of 2026-10-24 under his rulings DEC-0192 and DEC-3523 (tenet 4), made without asking him, as his order of 2026-09-30 says. Each of the four numbers had two register keys. On 2026-10-02, when the hand-typed rows became declarations, each was handed to another figure: MK-CF-M-001 now Expenses, MK-CF-M-002 = Planned surplus (this month), MK-CF-M-003 = Actual surplus so far, MK-CF-M-004 each row of the month. The four original keys are retired, each with its reason and where its figure lives now: Expected in is MK-CF-M-047, Planned out is MK-CF-M-048, the grid month's = Planned surplus is MK-CF-M-049, and Out (spent + debt) is MK-CF-M-052. Renumbering back would touch about 17 code files, 7 test files and some 60 documents, approved drawings among them. The old anchors follow their figures: G12 (DEC-0333) and the 2026-08-27 worked example (DEC-0292) now name MK-CF-M-052 and MK-CF-M-048, and DEC-0260's $0 rule MK-CF-M-052. DEC-0002, his approval of the whole Cash flow surface, is kept as it is. MK-CF-M-002 and MK-CF-M-049 stay two figures: this month's planned surplus counts every debt's payment this month, the grid's later months count a debt from its first payment (a $250 car loan whose first payment is next month). His words are untouched. To reverse: restore moneykeel_metric_register.json, moneykeel_rulings.json and moneykeel_decisions_anchors.json from the scratchpad backup-1024b/. One word from him reverses it."
 },
 {
  "id": "DEC-8085",
  "decided": "2026-10-24",
  "in_use": "IN USE",
  "whose": "the lead's decision under his rulings, recorded in his log — not his own",
  "his_words": "",
  "the_log_records": "NOT A DECISION OF HIS — the lead's decision of 2026-10-24 under his ruling DEC-0333, made without asking him, as his order of 2026-09-30 says. His ruling DEC-0333 (G12, 2026-09-12): the month's outflow, expenses and debt paid, comes from one function, MK-CF-F-194 monthOutflow, never from the screen. Only a past month used it: this month's outflow was summed inside MK-CF-F-005 actualMonthFlow, and Home added the rows again. Both now hand the month's expenses so far and debt paid so far to monthOutflow, and Home prints the door's inflow and outflow. The dollars do not move: A $3,248 · C $9,248 · D $3,548 · E $3,398, and a past month $2,998 + $250 = $3,248. DEC-0333 stays TESTED, now on eight checks in the agreement test. To reverse: restore this-month.ts from the scratchpad backup-1024b/ and revert the two lines in HomeScreen.tsx. One word from him reverses it."
 },
 {
  "id": "DEC-8152",
  "decided": "2026-09-14",
  "in_use": "IN USE",
  "whose": "his",
  "his_words": "count them",
  "the_log_records": "“count them.” His answer to master question Q50, on his own 2026-08-27 worked example: the HELOC payment of 200 and the card payment of 200, which his spending section counts as expenses, come off the surplus too. His household's planned surplus is 350 and its actual 900, not 750 and 1,300."
 },
 {
  "id": "DEC-8153",
  "decided": "2026-10-24",
  "in_use": "IN USE",
  "whose": "the lead's decision under his rulings, recorded in his log — not his own",
  "his_words": "",
  "the_log_records": "NOT A DECISION OF HIS — the lead's decision of 2026-10-24 under his rulings DEC-1923 and DEC-3523 (tenets 1 and 4), made without asking him, as his order of 2026-09-30 says. One rule for a debt in a month, in two new shared functions, MK-CF-F-235 paysInMonth and MK-CF-F-236 paymentInMonth: from its first payment to its payoff, and a balance due in full once, in its month, at its balance. A $7,200 take-home, a $3,400 budget, the $2,400 mortgage, a $250 car loan whose first payment is Oct 28, a $300 loan paid off in August and a $1,000 tax bill due in full Sep 20: September's planned surplus read +$850, the car loan and the paid-off loan counted and the tax bill left out; it reads +$400 = 7,200 − 3,400 − 2,400 − 1,000, what the Bill calendar's September holds. October's card is unchanged, $1,150. ACTUAL no longer lists the car loan as due the 28th at $0; MONTHLY RECURRING EXPENSES reads $2,400 (it read $2,650); the tax bill is on the BIG-TICKET RADAR at $1,000; Home's due-soon reminder no longer fires for a loan not yet started. MK-CF-M-047, 048 and 049 now say they print on a later month's plan card, from the grid ($7,200 / $6,050 / $1,150), and the retired surplus line and the paycheck card's SURPLUS have their own number, MK-CF-M-078 (it printed under MK-CF-M-049). To reverse: count every debt's payment in this month again, whatever its dates. One word from him reverses it."
 },
 {
  "id": "DEC-8362",
  "decided": "2026-10-25",
  "in_use": "IN USE",
  "whose": "the lead's decision under his rulings, recorded in his log — not his own",
  "his_words": "",
  "the_log_records": "NOT A DECISION OF HIS — the lead's decision of 2026-10-25 under his rulings DEC-0260 (Q48) and DEC-3523 (tenet 3), made without asking him, as his order of 2026-09-30 says. Debts read “across 0 debts · $0/month in payments · ~$0”, a 🎉, an edit hint and two doors; Income printed its door twice; Expenses showed a $0 band with nothing under it. Now Debts reads YOUR DEBT $0 and “Nothing entered yet. Add your debts ›”; Income THIS MONTH $0 and the door once; Expenses $0 with its door; This month's set-up steps sit under a quiet grey label. To reverse: print the old first-day rows. One word from him reverses it."
 },
 {
  "id": "DEC-8366",
  "decided": "2026-10-25",
  "in_use": "IN USE",
  "whose": "the lead's decision under his rulings, recorded in his log — not his own",
  "his_words": "",
  "the_log_records": "NOT A DECISION OF HIS — the lead's decision of 2026-10-25 under his rulings DEC-7939 and DEC-3523 (tenet 3), made without asking him, as his order of 2026-09-30 says. October with no budget read “Planned outflow $2,650 · = Planned surplus $4,550”, the take-home less the debts, as if nothing were spent. It reads “Planned outflow (expenses + debt) — not set”, This month's sentence and “Set your budget”, and no planned surplus. To reverse: print the take-home less the debts again. One word from him reverses it."
 },
 {
  "id": "DEC-8387",
  "decided": "2026-10-25",
  "in_use": "IN USE",
  "whose": "the lead's decision under his rulings, recorded in his log — not his own",
  "his_words": "",
  "the_log_records": "NOT A DECISION OF HIS — the lead's decision of 2026-10-25 under his rulings DEC-7942 and DEC-3523 (tenet 5), made without asking him, as his order of 2026-09-30 says. The founder's $5,000 typed the old way showed $5,000 in the gross box under “Before anything comes out.”, and a profile loaded from the cloud was read as gross, $4,582 where $5,000 lands. The conversion now runs as the profile comes in: “$5,000.00 ≈ Worked back…”, “$0/month · 0%”. To reverse: convert only on save. One word from him reverses it."
 },
 {
  "id": "DEC-8459",
  "decided": "2026-10-25",
  "in_use": "IN USE",
  "whose": "the lead's decision under his rulings, recorded in his log — not his own",
  "his_words": "",
  "the_log_records": "NOT A DECISION OF HIS — the lead's decision of 2026-10-25 under his rulings DEC-1923, DEC-2440 and DEC-0333, made without asking him, as his order of 2026-09-30 says. A $250 Car loan budget line beside a $250 car loan counted $500; it counts $250, with “Your Car loan budget line is not counted here…”. A mortgage on no property beside a Rent / Mortgage line is taken as that line: “…Place it on your home in Net worth, so we know they are the same.” In the register's September household the planned surplus moves $1,150 → $3,450, free after the goal $850 → $3,150, October's outflow $6,050 → $3,750, planned expenses $3,400 → $1,100, actual expenses $2,998 → $698; the outflow, the surplus and Home's $7,200 / $3,248 / $3,952 do not move. To reverse: count every budget line as typed. One word from him reverses it."
 },
 {
  "id": "DEC-8771",
  "decided": "2026-10-27",
  "in_use": "IN USE",
  "whose": "the lead's decision under his rulings, recorded in his log — not his own",
  "his_words": "",
  "the_log_records": "NOT A DECISION OF HIS — the lead's decision of 2026-10-27 under his rulings DEC-7607 and DEC-3523 (tenet 4), made without asking him, as his order of 2026-09-30 says. The label read each received line, against DEC-7607's words for ACTUAL. It reads each line of what has happened so far; the car loan row still reads −$250. An old comment said the label must stay, but the register only reserves the ID and no guard reads its key. To reverse: use the old label. One word from him reverses it."
 }
]
```
